﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using Microsoft.Data.SqlClient;
namespace Security
{
    public partial class AddTypeOfLeaveForm : Form
    {
        SqlConnection con = new SqlConnection(
           "Data Source=DESKTOP-133OPA4\\SQLEXPRESS;" +
           "Initial Catalog=SecureRoster;" +
           "Integrated Security=True;" +
           "Encrypt=False;");
        public AddTypeOfLeaveForm()
        {
            InitializeComponent();
        }

        private void AddTypeOfLeaveForm_Load(object sender, EventArgs e)
        {

        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            try
            {
                con.Open();

                SqlCommand idCmd = new SqlCommand(
                  "SELECT ISNULL(MAX(TypeOfLeaveID),0) + 1 FROM TypeOfLeaves", con);
                int leaveTypeID = Convert.ToInt32(idCmd.ExecuteScalar());

                SqlCommand cmd = new SqlCommand(
                  @"INSERT INTO TypeOfLeaves
      (TypeOfLeaveID, TypeOfLeave, MaxDuration)
    VALUES
      (@id, @type, @max)", con);

                cmd.Parameters.AddWithValue("@id", leaveTypeID);
                cmd.Parameters.AddWithValue("@type", txtTypeOfLeave.Text);
                cmd.Parameters.AddWithValue("@max", txtMaxDuration.Text);

                cmd.ExecuteNonQuery();

                MessageBox.Show("Type of Leave Added Successfully");
                con.Close();
                this.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            this.Close();
        }
        
    }
}
