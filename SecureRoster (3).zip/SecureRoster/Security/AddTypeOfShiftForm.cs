﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using Microsoft.Data.SqlClient;

namespace Security
{
    public partial class AddTypeOfShiftForm : Form
    {
        public AddTypeOfShiftForm()
        {
            InitializeComponent();
        }
        SqlConnection con = new SqlConnection(
          "Data Source=DESKTOP-133OPA4\\SQLEXPRESS;" +
          "Initial Catalog=SecureRoster;" +
          "Integrated Security=True;" +
          "Encrypt=False;");

        private void AddTypeOfShiftForm_Load(object sender, EventArgs e)
        {
         
        }
 

        


        private void btnSave_Click(object sender, EventArgs e)
        { 
            if (string.IsNullOrWhiteSpace(txtTypeOfShift.Text)) { MessageBox.Show("Enter shift type."); return; }
            if (string.IsNullOrWhiteSpace(txtStartTime.Text)) { MessageBox.Show("Enter start time."); return; }
            if (string.IsNullOrWhiteSpace(txtEndTime.Text)) { MessageBox.Show("Enter end time."); return; }

            try
            {
                if (con.State != ConnectionState.Open) con.Open();

                // Check for duplicates
                SqlCommand checkCmd = new SqlCommand("SELECT COUNT(*) FROM TypeOfShifts WHERE TypeOfShift = @name", con);
                checkCmd.Parameters.AddWithValue("@name", txtTypeOfShift.Text);
                int count = Convert.ToInt32(checkCmd.ExecuteScalar());

                if (count > 0)
                {
                    MessageBox.Show("This Type of Shift already exists!");
                    con.Close();
                    return;
                }

                SqlCommand cmd = new SqlCommand(
                    @"INSERT INTO TypeOfShifts (TypeOfShift, StartTime, EndTime)
                      VALUES (@type, @start, @end)", con);

                cmd.Parameters.AddWithValue("@type", txtTypeOfShift.Text);
                cmd.Parameters.AddWithValue("@start", txtStartTime.Text);
                cmd.Parameters.AddWithValue("@end", txtEndTime.Text);

                cmd.ExecuteNonQuery();
                MessageBox.Show("Type of Shift Added");
                con.Close();
                this.Close();
            }
            catch (Exception ex) { MessageBox.Show(ex.Message); }
        }




        private void btnCancel_Click(object sender, EventArgs e)
        {
            this.Close();
        }

     
    }
}

/**/