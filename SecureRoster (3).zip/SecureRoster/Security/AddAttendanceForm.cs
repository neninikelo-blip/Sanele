﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using Microsoft.Data.SqlClient;
namespace Security
{
    public partial class AddAttendanceForm : Form
    {
        SqlConnection con = new SqlConnection(
            "Data Source=DESKTOP-133OPA4\\SQLEXPRESS;" +
            "Initial Catalog=SecureRoster;" +
            "Integrated Security=True;" +
            "Encrypt=False;");

        public AddAttendanceForm()
        {
            InitializeComponent();
        }

        private void AddAttendanceForm_Load(object sender, EventArgs e)
        {
            // Assignments + guard/person info so the supervisor can pick one
            DataTable dt = new DataTable();
            new SqlDataAdapter(
                @"SELECT rsa.AssignmentID,
                         p.FirstName + ' ' + p.LastName + ' | ' + rs.NameOfShift AS Label
                  FROM RegularShiftsAssignments rsa
                  INNER JOIN Guards g ON rsa.GuardID = g.GuardID
                  INNER JOIN Persons p ON g.PersonID = p.PersonID
                  INNER JOIN RegularShifts rs ON rsa.RegularShiftID = rs.RegularShiftID",
                con).Fill(dt);

            cmbAssignment.DataSource = dt;
            cmbAssignment.DisplayMember = "Label";
            cmbAssignment.ValueMember = "AssignmentID";
            string[] times = { "00H00", "06H00", "06H03", "12H00", "18H00", "18H03" };
            cmbCheckIn.Items.Clear(); cmbCheckIn.Items.AddRange(times);
            cmbCheckOut.Items.Clear(); cmbCheckOut.Items.AddRange(times);

            cmbStatus.Items.Clear();
            cmbStatus.Items.AddRange(new object[] { "P", "A", "L" });
            cmbStatus.DropDownStyle = ComboBoxStyle.DropDownList;

        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            if (cmbAssignment.SelectedValue == null ||
                cmbAssignment.SelectedValue is DataRowView) return;

            try
            {
                con.Open();
                SqlCommand cmd = new SqlCommand(
                    @"INSERT INTO Attendances
                        (AttendanceID, CheckInTime, CheckOutTime,
                         AttendanceStatus, AssignmentID)
                      VALUES
                        ((SELECT ISNULL(MAX(AttendanceID),0) + 1 FROM Attendances),
                         @in, @out, @status, @assignment)", con);

                cmd.Parameters.AddWithValue("@in", cmbCheckIn.Text);  
                cmd.Parameters.AddWithValue("@out", cmbCheckOut.Text);  
                cmd.Parameters.AddWithValue("@status", cmbStatus.Text);   
                cmd.Parameters.AddWithValue("@assignment", cmbAssignment.SelectedValue);

                cmd.ExecuteNonQuery();

                MessageBox.Show("Attendance Captured");
                con.Close();
                this.Close();
            }
            catch (Exception ex) { MessageBox.Show(ex.Message); }
        

        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
/**/