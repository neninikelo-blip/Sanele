﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using Microsoft.Data.SqlClient;
namespace Security
{
    public partial class AddSiteForm : Form
    {
        SqlConnection con = new SqlConnection("Data Source=DESKTOP-133OPA4\\SQLEXPRESS;" + "Initial Catalog=SecureRoster;" + "Integrated Security=True;" + "Encrypt=False;");

        public AddSiteForm()
        {
            InitializeComponent();
        }

        private void AddSiteForm_Load(object sender, EventArgs e)
        {

            // CLIENT COMPANIES
            SqlDataAdapter daClient = new SqlDataAdapter(
                @"SELECT cc.ClientCompID, c.CompanyName 
      FROM ClientCompanies cc
      INNER JOIN Companies c ON cc.CompanyID = c.CompanyID", con);

            DataTable dtClient = new DataTable();
            daClient.Fill(dtClient);
            cmbClientCompany.DataSource = dtClient;
            cmbClientCompany.DisplayMember = "CompanyName"; // Show name
            cmbClientCompany.ValueMember = "ClientCompID";  // Save ID

            // SECURITY COMPANIES
            DataTable dtSecurity = new DataTable();

            SqlDataAdapter daSecurity =
                new SqlDataAdapter(
                @"SELECT
        SECURITYCOMP_ID,
        COMPANYNAME
      FROM SecurityCompaniesView",
                con);

            daSecurity.Fill(dtSecurity);

            cmbSecurityCompany.DataSource = dtSecurity;

            cmbSecurityCompany.DisplayMember = "COMPANYNAME";

            cmbSecurityCompany.ValueMember = "SECURITYCOMP_ID";


            // SUBURBS

            DataTable dtSuburb = new DataTable();

            SqlDataAdapter daSuburb =
                new SqlDataAdapter(
                @"SELECT
        SuburbID,
        SuburbName
      FROM Suburbs",
                con);

            daSuburb.Fill(dtSuburb);

            cmbSuburb.DataSource = dtSuburb;

            cmbSuburb.DisplayMember = "SuburbName";

            cmbSuburb.ValueMember = "SuburbID";
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            try
            {
                con.Open();

                // Generate new Site ID

                SqlCommand idCmd =
                    new SqlCommand(
                    "SELECT ISNULL(MAX(SiteID),0)+1 FROM Sites",
                    con);

                int siteID =
                    Convert.ToInt32(
                        idCmd.ExecuteScalar());

                SqlCommand cmd =
                    new SqlCommand(
                    @"INSERT INTO Sites
                    (
                        SiteID,
                        NameOfSite,
                        SiteCapacity,
                        ClientCompID,
                        SecurityCompID,
                        SuburbID
                    )
                    VALUES
                    (
                        @siteid,
                        @name,
                        @capacity,
                        @client,
                        @security,
                        @suburb
                    )",
                    con);

                cmd.Parameters.AddWithValue(
                    "@siteid",
                    siteID);

                cmd.Parameters.AddWithValue(
                    "@name",
                    txtSiteName.Text);

                cmd.Parameters.AddWithValue(
                    "@capacity",
                    txtCapacity.Text);

                cmd.Parameters.AddWithValue(
                    "@client",
                    cmbClientCompany.SelectedValue);

                cmd.Parameters.AddWithValue(
                    "@security",
                    cmbSecurityCompany.SelectedValue);

                cmd.Parameters.AddWithValue(
                    "@suburb",
                    cmbSuburb.SelectedValue);

                cmd.ExecuteNonQuery();

                MessageBox.Show("Site Added Successfully");

                con.Close();

                this.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
        

        private void btnCancel_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    
      

           

           
}
        

    }

