﻿namespace Security
{
    partial class EditProfileForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            label5 = new Label();
            label6 = new Label();
            txtIDNumber = new TextBox();
            label4 = new Label();
            cmbSite = new ComboBox();
            label3 = new Label();
            label2 = new Label();
            label1 = new Label();
            txtCell = new TextBox();
            txtLastName = new TextBox();
            txtFirstName = new TextBox();
            btnCancel = new Button();
            btnSave = new Button();
            label7 = new Label();
            txtEmail = new TextBox();
            label8 = new Label();
            cmbCompany = new ComboBox();
            label9 = new Label();
            cmbSuburb = new ComboBox();
            cmbGender = new ComboBox();
            SuspendLayout();
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Location = new Point(23, 194);
            label5.Name = "label5";
            label5.Size = new Size(45, 15);
            label5.TabIndex = 43;
            label5.Text = "Gender";
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Location = new Point(23, 144);
            label6.Name = "label6";
            label6.Size = new Size(65, 15);
            label6.TabIndex = 42;
            label6.Text = "ID Number";
            // 
            // txtIDNumber
            // 
            txtIDNumber.Location = new Point(164, 144);
            txtIDNumber.Name = "txtIDNumber";
            txtIDNumber.Size = new Size(100, 23);
            txtIDNumber.TabIndex = 40;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new Point(22, 237);
            label4.Name = "label4";
            label4.Size = new Size(26, 15);
            label4.TabIndex = 39;
            label4.Text = "Site";
            // 
            // cmbSite
            // 
            cmbSite.FormattingEnabled = true;
            cmbSite.Items.AddRange(new object[] { "Potsdam Campus", "College Street Campus" });
            cmbSite.Location = new Point(164, 237);
            cmbSite.Name = "cmbSite";
            cmbSite.Size = new Size(121, 23);
            cmbSite.TabIndex = 38;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(22, 106);
            label3.Name = "label3";
            label3.Size = new Size(74, 15);
            label3.TabIndex = 37;
            label3.Text = "Cell Number";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(22, 56);
            label2.Name = "label2";
            label2.Size = new Size(63, 15);
            label2.TabIndex = 36;
            label2.Text = "Last Name";
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(22, 12);
            label1.Name = "label1";
            label1.Size = new Size(62, 15);
            label1.TabIndex = 35;
            label1.Text = "First name";
            // 
            // txtCell
            // 
            txtCell.Location = new Point(164, 103);
            txtCell.Name = "txtCell";
            txtCell.Size = new Size(100, 23);
            txtCell.TabIndex = 34;
            // 
            // txtLastName
            // 
            txtLastName.Location = new Point(164, 56);
            txtLastName.Name = "txtLastName";
            txtLastName.Size = new Size(100, 23);
            txtLastName.TabIndex = 33;
            // 
            // txtFirstName
            // 
            txtFirstName.Location = new Point(164, 12);
            txtFirstName.Name = "txtFirstName";
            txtFirstName.Size = new Size(100, 23);
            txtFirstName.TabIndex = 32;
            // 
            // btnCancel
            // 
            btnCancel.Location = new Point(231, 334);
            btnCancel.Name = "btnCancel";
            btnCancel.Size = new Size(75, 23);
            btnCancel.TabIndex = 31;
            btnCancel.Text = "Cancel";
            btnCancel.UseVisualStyleBackColor = true;
            btnCancel.Click += btnCancel_Click;
            // 
            // btnSave
            // 
            btnSave.Location = new Point(12, 334);
            btnSave.Name = "btnSave";
            btnSave.Size = new Size(75, 23);
            btnSave.TabIndex = 30;
            btnSave.Text = "Save";
            btnSave.UseVisualStyleBackColor = true;
            btnSave.Click += btnSave_Click;
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Location = new Point(326, 15);
            label7.Name = "label7";
            label7.Size = new Size(36, 15);
            label7.TabIndex = 45;
            label7.Text = "Email";
            // 
            // txtEmail
            // 
            txtEmail.Location = new Point(467, 12);
            txtEmail.Name = "txtEmail";
            txtEmail.Size = new Size(100, 23);
            txtEmail.TabIndex = 44;
            // 
            // label8
            // 
            label8.AutoSize = true;
            label8.Location = new Point(325, 66);
            label8.Name = "label8";
            label8.Size = new Size(59, 15);
            label8.TabIndex = 47;
            label8.Text = "Company";
            // 
            // cmbCompany
            // 
            cmbCompany.FormattingEnabled = true;
            cmbCompany.Items.AddRange(new object[] { "Potsdam Campus", "College Street Campus" });
            cmbCompany.Location = new Point(467, 66);
            cmbCompany.Name = "cmbCompany";
            cmbCompany.Size = new Size(121, 23);
            cmbCompany.TabIndex = 46;
            // 
            // label9
            // 
            label9.AutoSize = true;
            label9.Location = new Point(325, 120);
            label9.Name = "label9";
            label9.Size = new Size(45, 15);
            label9.TabIndex = 49;
            label9.Text = "Suburb";
            // 
            // cmbSuburb
            // 
            cmbSuburb.FormattingEnabled = true;
            cmbSuburb.Items.AddRange(new object[] { "Potsdam Campus", "College Street Campus" });
            cmbSuburb.Location = new Point(467, 120);
            cmbSuburb.Name = "cmbSuburb";
            cmbSuburb.Size = new Size(121, 23);
            cmbSuburb.TabIndex = 48;
            // 
            // cmbGender
            // 
            cmbGender.FormattingEnabled = true;
            cmbGender.Items.AddRange(new object[] { "Potsdam Campus", "College Street Campus" });
            cmbGender.Location = new Point(164, 194);
            cmbGender.Name = "cmbGender";
            cmbGender.Size = new Size(100, 23);
            cmbGender.TabIndex = 50;
            // 
            // EditProfileForm
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.FromArgb(31, 45, 61);
            ClientSize = new Size(800, 450);
            Controls.Add(cmbGender);
            Controls.Add(label9);
            Controls.Add(cmbSuburb);
            Controls.Add(label8);
            Controls.Add(cmbCompany);
            Controls.Add(label7);
            Controls.Add(txtEmail);
            Controls.Add(label5);
            Controls.Add(label6);
            Controls.Add(txtIDNumber);
            Controls.Add(label4);
            Controls.Add(cmbSite);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(label1);
            Controls.Add(txtCell);
            Controls.Add(txtLastName);
            Controls.Add(txtFirstName);
            Controls.Add(btnCancel);
            Controls.Add(btnSave);
            Name = "EditProfileForm";
            Text = "EditProfileForm";
            Load += EditProfileForm_Load;
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label5;
        private Label label6;
        private TextBox txtIDNumber;
        private Label label4;
        private ComboBox cmbSite;
        private Label label3;
        private Label label2;
        private Label label1;
        private TextBox txtCell;
        private TextBox txtLastName;
        private TextBox txtFirstName;
        private Button btnCancel;
        private Button btnSave;
        private Label label7;
        private TextBox txtEmail;
        private Label label8;
        private ComboBox cmbCompany;
        private Label label9;
        private ComboBox cmbSuburb;
        private ComboBox cmbGender;
    }
}