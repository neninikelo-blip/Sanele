﻿namespace Security
{
    partial class EditSupervisorForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            comboBoxSuburb = new ComboBox();
            label5 = new Label();
            label6 = new Label();
            btnCancel = new Button();
            btnSave = new Button();
            label3 = new Label();
            label2 = new Label();
            label1 = new Label();
            txtLastName = new TextBox();
            txtFirstName = new TextBox();
            txtEmail = new TextBox();
            label4 = new Label();
            label7 = new Label();
            txtUsername = new TextBox();
            txtCell = new TextBox();
            txtIDNumber = new TextBox();
            label8 = new Label();
            comboBoxSite = new ComboBox();
            label9 = new Label();
            cmbGender = new ComboBox();
            SuspendLayout();
            // 
            // comboBoxSuburb
            // 
            comboBoxSuburb.FormattingEnabled = true;
            comboBoxSuburb.Location = new Point(413, 145);
            comboBoxSuburb.Name = "comboBoxSuburb";
            comboBoxSuburb.Size = new Size(121, 23);
            comboBoxSuburb.TabIndex = 54;
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Location = new Point(293, 62);
            label5.Name = "label5";
            label5.Size = new Size(74, 15);
            label5.TabIndex = 51;
            label5.Text = "Cell Number";
            // 
            // label6
            // 
            label6.Location = new Point(292, 15);
            label6.Name = "label6";
            label6.Size = new Size(100, 23);
            label6.TabIndex = 55;
            label6.Text = "Email";
            // 
            // btnCancel
            // 
            btnCancel.Location = new Point(326, 292);
            btnCancel.Name = "btnCancel";
            btnCancel.Size = new Size(75, 23);
            btnCancel.TabIndex = 50;
            btnCancel.Text = "Cancel";
            btnCancel.UseVisualStyleBackColor = true;
            btnCancel.Click += btnCancel_Click_1;
            // 
            // btnSave
            // 
            btnSave.Location = new Point(73, 292);
            btnSave.Name = "btnSave";
            btnSave.Size = new Size(75, 23);
            btnSave.TabIndex = 49;
            btnSave.Text = "Save";
            btnSave.UseVisualStyleBackColor = true;
            btnSave.Click += btnSave_Click_1;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(16, 62);
            label3.Name = "label3";
            label3.Size = new Size(63, 15);
            label3.TabIndex = 48;
            label3.Text = "Last Name";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(292, 148);
            label2.Name = "label2";
            label2.Size = new Size(45, 15);
            label2.TabIndex = 47;
            label2.Text = "Suburb";
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(16, 12);
            label1.Name = "label1";
            label1.Size = new Size(62, 15);
            label1.TabIndex = 46;
            label1.Text = "First name";
            // 
            // txtLastName
            // 
            txtLastName.Location = new Point(158, 59);
            txtLastName.Name = "txtLastName";
            txtLastName.Size = new Size(100, 23);
            txtLastName.TabIndex = 45;
            // 
            // txtFirstName
            // 
            txtFirstName.Location = new Point(158, 12);
            txtFirstName.Name = "txtFirstName";
            txtFirstName.Size = new Size(100, 23);
            txtFirstName.TabIndex = 44;
            // 
            // txtEmail
            // 
            txtEmail.Location = new Point(413, 9);
            txtEmail.Name = "txtEmail";
            txtEmail.Size = new Size(100, 23);
            txtEmail.TabIndex = 56;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new Point(16, 153);
            label4.Name = "label4";
            label4.Size = new Size(60, 15);
            label4.TabIndex = 60;
            label4.Text = "Username";
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Location = new Point(16, 103);
            label7.Name = "label7";
            label7.Size = new Size(45, 15);
            label7.TabIndex = 59;
            label7.Text = "Gender";
            // 
            // txtUsername
            // 
            txtUsername.Location = new Point(158, 150);
            txtUsername.Name = "txtUsername";
            txtUsername.Size = new Size(100, 23);
            txtUsername.TabIndex = 58;
            // 
            // txtCell
            // 
            txtCell.Location = new Point(413, 62);
            txtCell.Name = "txtCell";
            txtCell.Size = new Size(100, 23);
            txtCell.TabIndex = 61;
            // 
            // txtIDNumber
            // 
            txtIDNumber.Location = new Point(413, 106);
            txtIDNumber.Name = "txtIDNumber";
            txtIDNumber.Size = new Size(100, 23);
            txtIDNumber.TabIndex = 63;
            // 
            // label8
            // 
            label8.AutoSize = true;
            label8.Location = new Point(293, 106);
            label8.Name = "label8";
            label8.Size = new Size(65, 15);
            label8.TabIndex = 62;
            label8.Text = "ID Number";
            // 
            // comboBoxSite
            // 
            comboBoxSite.FormattingEnabled = true;
            comboBoxSite.Location = new Point(413, 189);
            comboBoxSite.Name = "comboBoxSite";
            comboBoxSite.Size = new Size(121, 23);
            comboBoxSite.TabIndex = 65;
            // 
            // label9
            // 
            label9.AutoSize = true;
            label9.Location = new Point(292, 192);
            label9.Name = "label9";
            label9.Size = new Size(31, 15);
            label9.TabIndex = 64;
            label9.Text = "Sites";
            // 
            // cmbGender
            // 
            cmbGender.FormattingEnabled = true;
            cmbGender.Location = new Point(158, 95);
            cmbGender.Name = "cmbGender";
            cmbGender.Size = new Size(100, 23);
            cmbGender.TabIndex = 66;
            // 
            // EditSupervisorForm
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.FromArgb(31, 45, 61);
            ClientSize = new Size(541, 339);
            Controls.Add(cmbGender);
            Controls.Add(comboBoxSite);
            Controls.Add(label9);
            Controls.Add(txtIDNumber);
            Controls.Add(label8);
            Controls.Add(txtCell);
            Controls.Add(label4);
            Controls.Add(label7);
            Controls.Add(txtUsername);
            Controls.Add(txtEmail);
            Controls.Add(comboBoxSuburb);
            Controls.Add(label5);
            Controls.Add(label6);
            Controls.Add(btnCancel);
            Controls.Add(btnSave);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(label1);
            Controls.Add(txtLastName);
            Controls.Add(txtFirstName);
            Name = "EditSupervisorForm";
            Text = "EditSupervisorForm";
            Load += EditSupervisorForm_Load;
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private ComboBox comboBoxSuburb;
        private Label label5;
        private Label label6;
        private Button btnCancel;
        private Button btnSave;
        private Label label3;
        private Label label2;
        private Label label1;
        private TextBox txtLastName;
        private TextBox txtFirstName;
        private TextBox txtEmail;
        private Label label4;
        private Label label7;
        private TextBox txtUsername;
        private TextBox txtCell;
        private TextBox txtIDNumber;
        private Label label8;
        private ComboBox comboBoxSite;
        private Label label9;
        private ComboBox cmbGender;
    }
}