﻿#pragma warning disable SYSLIB0060
using System;
using System.Security.Cryptography;

namespace Security
{
    public static class PasswordHasher
    {
        private const int Iterations = 10000;
        private const int SaltSize = 16;
        private const int HashSize = 32;

        public static string GenerateSalt()
        {
            byte[] salt = new byte[SaltSize];
            using (var rng = RandomNumberGenerator.Create())
                rng.GetBytes(salt);
            return Convert.ToBase64String(salt);
        }

        public static string HashPassword(string password, string saltBase64)
        {
            byte[] salt = Convert.FromBase64String(saltBase64);

            byte[] hash = Rfc2898DeriveBytes.Pbkdf2(
                password: password,
                salt: salt,
                iterations: Iterations,
                hashAlgorithm: HashAlgorithmName.SHA256,
                outputLength: HashSize);

            return Convert.ToBase64String(hash);
        }

        public static (string salt, string hash) CreateHash(string password)
        {
            string salt = GenerateSalt();
            string hash = HashPassword(password, salt);
            return (salt, hash);
        }

        public static bool Verify(string typedPassword, string storedSalt, string storedHash)
        {
            string computed = HashPassword(typedPassword, storedSalt);
            return computed == storedHash;
        }
    }
}/**/