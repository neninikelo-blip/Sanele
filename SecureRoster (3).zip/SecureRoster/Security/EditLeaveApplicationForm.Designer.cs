﻿namespace Security
{
    partial class EditLeaveApplicationForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            cmbLeaveType = new ComboBox();
            cmbLeaveStatus = new ComboBox();
            label5 = new Label();
            label6 = new Label();
            btnCancel = new Button();
            btnSave = new Button();
            label3 = new Label();
            label2 = new Label();
            label1 = new Label();
            txtLeaveReason = new TextBox();
            dtpEndDate = new DateTimePicker();
            dtpStartDate = new DateTimePicker();
            SuspendLayout();
            // 
            // cmbLeaveType
            // 
            cmbLeaveType.FormattingEnabled = true;
            cmbLeaveType.Location = new Point(404, 75);
            cmbLeaveType.Name = "cmbLeaveType";
            cmbLeaveType.Size = new Size(121, 23);
            cmbLeaveType.TabIndex = 65;
            // 
            // cmbLeaveStatus
            // 
            cmbLeaveStatus.FormattingEnabled = true;
            cmbLeaveStatus.Location = new Point(404, 25);
            cmbLeaveStatus.Name = "cmbLeaveStatus";
            cmbLeaveStatus.Size = new Size(121, 23);
            cmbLeaveStatus.TabIndex = 64;
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Location = new Point(284, 75);
            label5.Name = "label5";
            label5.Size = new Size(65, 15);
            label5.TabIndex = 63;
            label5.Text = "Leave Type";
            // 
            // label6
            // 
            label6.Location = new Point(283, 28);
            label6.Name = "label6";
            label6.Size = new Size(100, 23);
            label6.TabIndex = 67;
            label6.Text = "Leave Status";
            // 
            // btnCancel
            // 
            btnCancel.Location = new Point(317, 305);
            btnCancel.Name = "btnCancel";
            btnCancel.Size = new Size(75, 23);
            btnCancel.TabIndex = 62;
            btnCancel.Text = "Cancel";
            btnCancel.UseVisualStyleBackColor = true;
            btnCancel.Click += btnCancel_Click;
            // 
            // btnSave
            // 
            btnSave.Location = new Point(64, 305);
            btnSave.Name = "btnSave";
            btnSave.Size = new Size(75, 23);
            btnSave.TabIndex = 61;
            btnSave.Text = "Save";
            btnSave.UseVisualStyleBackColor = true;
            btnSave.Click += btnSave_Click;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(7, 75);
            label3.Name = "label3";
            label3.Size = new Size(54, 15);
            label3.TabIndex = 60;
            label3.Text = "End Date";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(283, 116);
            label2.Name = "label2";
            label2.Size = new Size(78, 15);
            label2.TabIndex = 59;
            label2.Text = "Leave Reason";
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(7, 25);
            label1.Name = "label1";
            label1.Size = new Size(58, 15);
            label1.TabIndex = 58;
            label1.Text = "Start Date";
            // 
            // txtLeaveReason
            // 
            txtLeaveReason.Location = new Point(404, 116);
            txtLeaveReason.Name = "txtLeaveReason";
            txtLeaveReason.Size = new Size(100, 23);
            txtLeaveReason.TabIndex = 68;
            // 
            // dtpEndDate
            // 
            dtpEndDate.Location = new Point(74, 69);
            dtpEndDate.Name = "dtpEndDate";
            dtpEndDate.Size = new Size(200, 23);
            dtpEndDate.TabIndex = 70;
            // 
            // dtpStartDate
            // 
            dtpStartDate.Location = new Point(74, 25);
            dtpStartDate.Name = "dtpStartDate";
            dtpStartDate.Size = new Size(200, 23);
            dtpStartDate.TabIndex = 69;
            // 
            // EditLeaveApplicationForm
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.FromArgb(31, 45, 61);
            ClientSize = new Size(543, 378);
            Controls.Add(dtpEndDate);
            Controls.Add(dtpStartDate);
            Controls.Add(txtLeaveReason);
            Controls.Add(cmbLeaveType);
            Controls.Add(cmbLeaveStatus);
            Controls.Add(label5);
            Controls.Add(label6);
            Controls.Add(btnCancel);
            Controls.Add(btnSave);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(label1);
            Name = "EditLeaveApplicationForm";
            Text = "EditLeaveApplicationForm";
            Load += EditLeaveApplicationForm_Load;
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion
        private ComboBox cmbLeaveType;
        private ComboBox cmbLeaveStatus;
        private Label label5;
        private Label label6;
        private Button btnCancel;
        private Button btnSave;
        private Label label3;
        private Label label2;
        private Label label1;
        private TextBox txtLeaveReason;
        private DateTimePicker dtpEndDate;
        private DateTimePicker dtpStartDate;
    }
}