﻿namespace Security
{
    partial class EditGuardForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            btnCancel = new Button();
            btnSave = new Button();
            label5 = new Label();
            label6 = new Label();
            txtID = new TextBox();
            label4 = new Label();
            comboBox1 = new ComboBox();
            label3 = new Label();
            label2 = new Label();
            label1 = new Label();
            txtCell = new TextBox();
            txtLastName = new TextBox();
            txtFirstName = new TextBox();
            cmbGender = new ComboBox();
            label7 = new Label();
            txtPassword = new TextBox();
            SuspendLayout();
            // 
            // btnCancel
            // 
            btnCancel.Location = new Point(228, 326);
            btnCancel.Name = "btnCancel";
            btnCancel.Size = new Size(75, 23);
            btnCancel.TabIndex = 17;
            btnCancel.Text = "Cancel";
            btnCancel.UseVisualStyleBackColor = true;
            btnCancel.Click += btnCancel_Click;
            // 
            // btnSave
            // 
            btnSave.Location = new Point(3, 339);
            btnSave.Name = "btnSave";
            btnSave.Size = new Size(75, 23);
            btnSave.TabIndex = 16;
            btnSave.Text = "Save";
            btnSave.UseVisualStyleBackColor = true;
            btnSave.Click += btnSave_Click;
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Location = new Point(13, 191);
            label5.Name = "label5";
            label5.Size = new Size(45, 15);
            label5.TabIndex = 29;
            label5.Text = "Gender";
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Location = new Point(13, 141);
            label6.Name = "label6";
            label6.Size = new Size(65, 15);
            label6.TabIndex = 28;
            label6.Text = "ID Number";
            // 
            // txtID
            // 
            txtID.Location = new Point(154, 141);
            txtID.Name = "txtID";
            txtID.Size = new Size(121, 23);
            txtID.TabIndex = 26;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new Point(12, 265);
            label4.Name = "label4";
            label4.Size = new Size(26, 15);
            label4.TabIndex = 25;
            label4.Text = "Site";
            // 
            // comboBox1
            // 
            comboBox1.FormattingEnabled = true;
            comboBox1.Items.AddRange(new object[] { "Potsdam Campus", "College Street Campus" });
            comboBox1.Location = new Point(154, 265);
            comboBox1.Name = "comboBox1";
            comboBox1.Size = new Size(121, 23);
            comboBox1.TabIndex = 24;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(12, 103);
            label3.Name = "label3";
            label3.Size = new Size(74, 15);
            label3.TabIndex = 23;
            label3.Text = "Cell Number";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(12, 53);
            label2.Name = "label2";
            label2.Size = new Size(63, 15);
            label2.TabIndex = 22;
            label2.Text = "Last Name";
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(12, 9);
            label1.Name = "label1";
            label1.Size = new Size(62, 15);
            label1.TabIndex = 21;
            label1.Text = "First name";
            // 
            // txtCell
            // 
            txtCell.Location = new Point(154, 100);
            txtCell.Name = "txtCell";
            txtCell.Size = new Size(121, 23);
            txtCell.TabIndex = 20;
            // 
            // txtLastName
            // 
            txtLastName.Location = new Point(154, 53);
            txtLastName.Name = "txtLastName";
            txtLastName.Size = new Size(121, 23);
            txtLastName.TabIndex = 19;
            // 
            // txtFirstName
            // 
            txtFirstName.Location = new Point(154, 9);
            txtFirstName.Name = "txtFirstName";
            txtFirstName.Size = new Size(121, 23);
            txtFirstName.TabIndex = 18;
            // 
            // cmbGender
            // 
            cmbGender.FormattingEnabled = true;
            cmbGender.Location = new Point(154, 188);
            cmbGender.Name = "cmbGender";
            cmbGender.Size = new Size(121, 23);
            cmbGender.TabIndex = 30;
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Location = new Point(13, 226);
            label7.Name = "label7";
            label7.Size = new Size(84, 15);
            label7.TabIndex = 32;
            label7.Text = "New Password";
            // 
            // txtPassword
            // 
            txtPassword.Location = new Point(154, 226);
            txtPassword.Name = "txtPassword";
            txtPassword.Size = new Size(121, 23);
            txtPassword.TabIndex = 31;
            // 
            // EditGuardForm
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.FromArgb(31, 45, 61);
            ClientSize = new Size(349, 382);
            Controls.Add(label7);
            Controls.Add(txtPassword);
            Controls.Add(cmbGender);
            Controls.Add(label5);
            Controls.Add(label6);
            Controls.Add(txtID);
            Controls.Add(label4);
            Controls.Add(comboBox1);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(label1);
            Controls.Add(txtCell);
            Controls.Add(txtLastName);
            Controls.Add(txtFirstName);
            Controls.Add(btnCancel);
            Controls.Add(btnSave);
            Name = "EditGuardForm";
            Text = "EditGuardForm";
            Load += EditGuardForm_Load;
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion
        private Button btnCancel;
        private Button btnSave;
        private Label label5;
        private Label label6;
        private TextBox txtID;
        private Label label4;
        private ComboBox comboBox1;
        private Label label3;
        private Label label2;
        private Label label1;
        private TextBox txtCell;
        private TextBox txtLastName;
        private TextBox txtFirstName;
        private ComboBox cmbGender;
        private Label label7;
        private TextBox txtPassword;
        //    private Button btnEdit;
    }
}