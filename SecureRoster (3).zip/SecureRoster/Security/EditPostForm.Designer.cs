﻿namespace Security
{
    partial class EditPostForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            cmbSite = new ComboBox();
            cmbStatus = new ComboBox();
            cmbSecurityCompany = new ComboBox();
            label5 = new Label();
            label6 = new Label();
            btnCancel = new Button();
            btnSave = new Button();
            label3 = new Label();
            label2 = new Label();
            label1 = new Label();
            txtPostName = new TextBox();
            cmbNumberPerPost = new ComboBox();
            SuspendLayout();
            // 
            // cmbSite
            // 
            cmbSite.FormattingEnabled = true;
            cmbSite.Location = new Point(421, 113);
            cmbSite.Name = "cmbSite";
            cmbSite.Size = new Size(121, 23);
            cmbSite.TabIndex = 54;
            // 
            // cmbStatus
            // 
            cmbStatus.FormattingEnabled = true;
            cmbStatus.Location = new Point(421, 75);
            cmbStatus.Name = "cmbStatus";
            cmbStatus.Size = new Size(121, 23);
            cmbStatus.TabIndex = 53;
            // 
            // cmbSecurityCompany
            // 
            cmbSecurityCompany.FormattingEnabled = true;
            cmbSecurityCompany.Location = new Point(421, 25);
            cmbSecurityCompany.Name = "cmbSecurityCompany";
            cmbSecurityCompany.Size = new Size(121, 23);
            cmbSecurityCompany.TabIndex = 52;
            cmbSecurityCompany.SelectedIndexChanged += cmbSecurityCompany_SelectedIndexChanged;
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Location = new Point(301, 75);
            label5.Name = "label5";
            label5.Size = new Size(39, 15);
            label5.TabIndex = 51;
            label5.Text = "Status";
            // 
            // label6
            // 
            label6.Location = new Point(300, 28);
            label6.Name = "label6";
            label6.Size = new Size(100, 23);
            label6.TabIndex = 55;
            label6.Text = "Client Company";
            // 
            // btnCancel
            // 
            btnCancel.Location = new Point(334, 305);
            btnCancel.Name = "btnCancel";
            btnCancel.Size = new Size(75, 23);
            btnCancel.TabIndex = 50;
            btnCancel.Text = "Cancel";
            btnCancel.UseVisualStyleBackColor = true;
            btnCancel.Click += btnCancel_Click_1;
            // 
            // btnSave
            // 
            btnSave.Location = new Point(81, 305);
            btnSave.Name = "btnSave";
            btnSave.Size = new Size(75, 23);
            btnSave.TabIndex = 49;
            btnSave.Text = "Save";
            btnSave.UseVisualStyleBackColor = true;
            btnSave.Click += btnSave_Click_1;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(24, 75);
            label3.Name = "label3";
            label3.Size = new Size(97, 15);
            label3.TabIndex = 48;
            label3.Text = "Number Per Post";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(300, 116);
            label2.Name = "label2";
            label2.Size = new Size(26, 15);
            label2.TabIndex = 47;
            label2.Text = "Site";
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(24, 25);
            label1.Name = "label1";
            label1.Size = new Size(63, 15);
            label1.TabIndex = 46;
            label1.Text = "Post name";
            // 
            // txtPostName
            // 
            txtPostName.Location = new Point(166, 25);
            txtPostName.Name = "txtPostName";
            txtPostName.Size = new Size(100, 23);
            txtPostName.TabIndex = 44;
            // 
            // cmbNumberPerPost
            // 
            cmbNumberPerPost.FormattingEnabled = true;
            cmbNumberPerPost.Location = new Point(166, 75);
            cmbNumberPerPost.Name = "cmbNumberPerPost";
            cmbNumberPerPost.Size = new Size(100, 23);
            cmbNumberPerPost.TabIndex = 56;
            // 
            // EditPostForm
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.FromArgb(31, 45, 61);
            ClientSize = new Size(558, 441);
            Controls.Add(cmbNumberPerPost);
            Controls.Add(cmbSite);
            Controls.Add(cmbStatus);
            Controls.Add(cmbSecurityCompany);
            Controls.Add(label5);
            Controls.Add(label6);
            Controls.Add(btnCancel);
            Controls.Add(btnSave);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(label1);
            Controls.Add(txtPostName);
            Name = "EditPostForm";
            Text = "EditPostForm";
            Load += EditPostForm_Load;
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private ComboBox cmbSite;
        private ComboBox cmbStatus;
        private ComboBox cmbSecurityCompany;
        private Label label5;
        private Label label6;
        private Button btnCancel;
        private Button btnSave;
        private Label label3;
        private Label label2;
        private Label label1;
        private TextBox txtPostName;
        private ComboBox cmbNumberPerPost;
    }
}