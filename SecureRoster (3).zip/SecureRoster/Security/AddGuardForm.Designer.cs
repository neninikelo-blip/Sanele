﻿namespace Security
{
    partial class AddGuardForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            txtFirstName = new TextBox();
            txtlastname = new TextBox();
            txtCellNO = new TextBox();
            label1 = new Label();
            label2 = new Label();
            label3 = new Label();
            btnSave = new Button();
            btnCancel = new Button();
            comboBox1 = new ComboBox();
            label4 = new Label();
            label5 = new Label();
            label6 = new Label();
            txtID_NO = new TextBox();
            label7 = new Label();
            label8 = new Label();
            txtPassword = new TextBox();
            txtUsername = new TextBox();
            cmbGender = new ComboBox();
            label9 = new Label();
            txtEmail = new TextBox();
            SuspendLayout();
            // 
            // txtFirstName
            // 
            txtFirstName.Location = new Point(151, 12);
            txtFirstName.Name = "txtFirstName";
            txtFirstName.Size = new Size(100, 23);
            txtFirstName.TabIndex = 0;
            // 
            // txtlastname
            // 
            txtlastname.Location = new Point(151, 56);
            txtlastname.Name = "txtlastname";
            txtlastname.Size = new Size(100, 23);
            txtlastname.TabIndex = 1;
            // 
            // txtCellNO
            // 
            txtCellNO.Location = new Point(151, 103);
            txtCellNO.Name = "txtCellNO";
            txtCellNO.Size = new Size(100, 23);
            txtCellNO.TabIndex = 2;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(9, 12);
            label1.Name = "label1";
            label1.Size = new Size(62, 15);
            label1.TabIndex = 3;
            label1.Text = "First name";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(9, 56);
            label2.Name = "label2";
            label2.Size = new Size(63, 15);
            label2.TabIndex = 4;
            label2.Text = "Last Name";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(9, 106);
            label3.Name = "label3";
            label3.Size = new Size(74, 15);
            label3.TabIndex = 5;
            label3.Text = "Cell Number";
            // 
            // btnSave
            // 
            btnSave.Location = new Point(66, 292);
            btnSave.Name = "btnSave";
            btnSave.Size = new Size(75, 23);
            btnSave.TabIndex = 6;
            btnSave.Text = "Save";
            btnSave.UseVisualStyleBackColor = true;
            btnSave.Click += btnSave_Click;
            // 
            // btnCancel
            // 
            btnCancel.Location = new Point(319, 292);
            btnCancel.Name = "btnCancel";
            btnCancel.Size = new Size(75, 23);
            btnCancel.TabIndex = 7;
            btnCancel.Text = "Cancel";
            btnCancel.UseVisualStyleBackColor = true;
            btnCancel.Click += btnCancel_Click;
            // 
            // comboBox1
            // 
            comboBox1.FormattingEnabled = true;
            comboBox1.Items.AddRange(new object[] { "Potsdam Campus", "College Street Campus" });
            comboBox1.Location = new Point(319, 205);
            comboBox1.Name = "comboBox1";
            comboBox1.Size = new Size(121, 23);
            comboBox1.TabIndex = 8;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new Point(177, 205);
            label4.Name = "label4";
            label4.Size = new Size(26, 15);
            label4.TabIndex = 9;
            label4.Text = "Site";
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Location = new Point(286, 62);
            label5.Name = "label5";
            label5.Size = new Size(45, 15);
            label5.TabIndex = 13;
            label5.Text = "Gender";
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Location = new Point(286, 12);
            label6.Name = "label6";
            label6.Size = new Size(65, 15);
            label6.TabIndex = 12;
            label6.Text = "ID Number";
            // 
            // txtID_NO
            // 
            txtID_NO.Location = new Point(427, 12);
            txtID_NO.Name = "txtID_NO";
            txtID_NO.Size = new Size(100, 23);
            txtID_NO.TabIndex = 10;
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Location = new Point(286, 143);
            label7.Name = "label7";
            label7.Size = new Size(57, 15);
            label7.TabIndex = 17;
            label7.Text = "Password";
            // 
            // label8
            // 
            label8.AutoSize = true;
            label8.Location = new Point(12, 148);
            label8.Name = "label8";
            label8.Size = new Size(60, 15);
            label8.TabIndex = 16;
            label8.Text = "Username";
            // 
            // txtPassword
            // 
            txtPassword.Location = new Point(427, 140);
            txtPassword.Name = "txtPassword";
            txtPassword.Size = new Size(100, 23);
            txtPassword.TabIndex = 15;
            // 
            // txtUsername
            // 
            txtUsername.Location = new Point(153, 148);
            txtUsername.Name = "txtUsername";
            txtUsername.Size = new Size(100, 23);
            txtUsername.TabIndex = 14;
            // 
            // cmbGender
            // 
            cmbGender.FormattingEnabled = true;
            cmbGender.Location = new Point(427, 59);
            cmbGender.Name = "cmbGender";
            cmbGender.Size = new Size(121, 23);
            cmbGender.TabIndex = 18;
            // 
            // label9
            // 
            label9.AutoSize = true;
            label9.Location = new Point(286, 106);
            label9.Name = "label9";
            label9.Size = new Size(36, 15);
            label9.TabIndex = 20;
            label9.Text = "Email";
            // 
            // txtEmail
            // 
            txtEmail.Location = new Point(427, 103);
            txtEmail.Name = "txtEmail";
            txtEmail.Size = new Size(100, 23);
            txtEmail.TabIndex = 19;
            // 
            // AddGuardForm
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.FromArgb(31, 45, 61);
            ClientSize = new Size(800, 450);
            Controls.Add(label9);
            Controls.Add(txtEmail);
            Controls.Add(cmbGender);
            Controls.Add(label7);
            Controls.Add(label8);
            Controls.Add(txtPassword);
            Controls.Add(txtUsername);
            Controls.Add(label5);
            Controls.Add(label6);
            Controls.Add(txtID_NO);
            Controls.Add(label4);
            Controls.Add(comboBox1);
            Controls.Add(btnCancel);
            Controls.Add(btnSave);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(label1);
            Controls.Add(txtCellNO);
            Controls.Add(txtlastname);
            Controls.Add(txtFirstName);
            Name = "AddGuardForm";
            Text = "AddGuardForm";
            Load += AddGuardForm_Load;
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private TextBox txtFirstName;
        private TextBox txtlastname;
        private TextBox txtCellNO;
        private Label label1;
        private Label label2;
        private Label label3;
        private Button btnSave;
        private Button btnCancel;
        private ComboBox comboBox1;
        private Label label4;
        private Label label5;
        private Label label6;
        private TextBox txtID_NO;
        private Label label7;
        private Label label8;
        private TextBox txtPassword;
        private TextBox txtUsername;
        private ComboBox cmbGender;
        private Label label9;
        private TextBox txtEmail;
    }
}