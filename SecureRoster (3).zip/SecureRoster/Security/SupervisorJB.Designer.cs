﻿namespace Security
{
    partial class SupervisorJB
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(SupervisorJB));
            label1 = new Label();
            panel1 = new Panel();
            pictureBox1 = new PictureBox();
            panel2 = new Panel();
            btnBack = new Button();
            btnAttendances = new Button();
            btnProfile = new Button();
            btnRosterAssign = new Button();
            btnLeaveApp = new Button();
            btnGuards = new Button();
            btnTypeofleaves = new Button();
            btnRosters = new Button();
            btnSites = new Button();
            btnSpecialShifts = new Button();
            btnPosts = new Button();
            btnRegularShifts = new Button();
            btnShiftTypes = new Button();
            dataGridView1 = new DataGridView();
            btnAdd = new Button();
            btnEdit = new Button();
            btnSave = new Button();
            lblRole = new Label();
            lblUsername = new Label();
            btnDelete = new Button();
            panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)dataGridView1).BeginInit();
            SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(314, 39);
            label1.Name = "label1";
            label1.Size = new Size(45, 19);
            label1.TabIndex = 0;
            label1.Text = "label1";
            // 
            // panel1
            // 
            panel1.Controls.Add(pictureBox1);
            panel1.Location = new Point(1, 1);
            panel1.Name = "panel1";
            panel1.Size = new Size(876, 113);
            panel1.TabIndex = 2;
            // 
            // pictureBox1
            // 
            pictureBox1.Dock = DockStyle.Fill;
            pictureBox1.Image = (Image)resources.GetObject("pictureBox1.Image");
            pictureBox1.Location = new Point(0, 0);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(876, 113);
            pictureBox1.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox1.TabIndex = 3;
            pictureBox1.TabStop = false;
            // 
            // panel2
            // 
            panel2.BackColor = Color.FromArgb(31, 45, 61);
            panel2.Controls.Add(btnBack);
            panel2.Controls.Add(btnAttendances);
            panel2.Controls.Add(btnProfile);
            panel2.Controls.Add(btnRosterAssign);
            panel2.Controls.Add(btnLeaveApp);
            panel2.Controls.Add(btnGuards);
            panel2.Controls.Add(btnTypeofleaves);
            panel2.Controls.Add(btnRosters);
            panel2.Controls.Add(btnSites);
            panel2.Controls.Add(btnSpecialShifts);
            panel2.Controls.Add(btnPosts);
            panel2.Controls.Add(btnRegularShifts);
            panel2.Controls.Add(btnShiftTypes);
            panel2.Location = new Point(1, 147);
            panel2.Name = "panel2";
            panel2.Size = new Size(200, 511);
            panel2.TabIndex = 3;
            panel2.Paint += panel2_Paint;
            // 
            // btnBack
            // 
            btnBack.ImageAlign = ContentAlignment.TopCenter;
            btnBack.Location = new Point(3, 3);
            btnBack.Name = "btnBack";
            btnBack.Size = new Size(36, 29);
            btnBack.TabIndex = 14;
            btnBack.Text = "<";
            btnBack.UseVisualStyleBackColor = true;
            btnBack.Click += btnBack_Click;
            // 
            // btnAttendances
            // 
            btnAttendances.BackColor = Color.White;
            btnAttendances.FlatStyle = FlatStyle.Flat;
            btnAttendances.Font = new Font("Segoe UI", 9F);
            btnAttendances.ForeColor = Color.Black;
            btnAttendances.Location = new Point(3, 350);
            btnAttendances.Name = "btnAttendances";
            btnAttendances.Size = new Size(189, 33);
            btnAttendances.TabIndex = 9;
            btnAttendances.Text = "Attendances   >";
            btnAttendances.TextAlign = ContentAlignment.MiddleLeft;
            btnAttendances.UseVisualStyleBackColor = false;
            btnAttendances.Click += btnAttendances_Click;
            // 
            // btnProfile
            // 
            btnProfile.BackColor = Color.White;
            btnProfile.FlatStyle = FlatStyle.Flat;
            btnProfile.Font = new Font("Segoe UI", 9F);
            btnProfile.ForeColor = Color.Black;
            btnProfile.Location = new Point(3, 467);
            btnProfile.Name = "btnProfile";
            btnProfile.Size = new Size(189, 33);
            btnProfile.TabIndex = 7;
            btnProfile.Text = "My Profile   >";
            btnProfile.TextAlign = ContentAlignment.MiddleLeft;
            btnProfile.UseVisualStyleBackColor = false;
            btnProfile.Click += btnProfile_Click;
            // 
            // btnRosterAssign
            // 
            btnRosterAssign.BackColor = Color.White;
            btnRosterAssign.FlatStyle = FlatStyle.Flat;
            btnRosterAssign.Font = new Font("Segoe UI", 9F);
            btnRosterAssign.ForeColor = Color.Black;
            btnRosterAssign.Location = new Point(3, 311);
            btnRosterAssign.Name = "btnRosterAssign";
            btnRosterAssign.Size = new Size(189, 33);
            btnRosterAssign.TabIndex = 12;
            btnRosterAssign.Text = "Roster Assignment   >";
            btnRosterAssign.TextAlign = ContentAlignment.MiddleLeft;
            btnRosterAssign.UseVisualStyleBackColor = false;
            btnRosterAssign.Click += btnRosterAssign_Click;
            // 
            // btnLeaveApp
            // 
            btnLeaveApp.BackColor = Color.White;
            btnLeaveApp.FlatStyle = FlatStyle.Flat;
            btnLeaveApp.Font = new Font("Segoe UI", 9F);
            btnLeaveApp.ForeColor = Color.Black;
            btnLeaveApp.Location = new Point(3, 428);
            btnLeaveApp.Name = "btnLeaveApp";
            btnLeaveApp.Size = new Size(189, 33);
            btnLeaveApp.TabIndex = 6;
            btnLeaveApp.Text = "Leave Applications   >";
            btnLeaveApp.TextAlign = ContentAlignment.MiddleLeft;
            btnLeaveApp.UseVisualStyleBackColor = false;
            btnLeaveApp.Click += btnLeaveApp_Click;
            // 
            // btnGuards
            // 
            btnGuards.BackColor = Color.White;
            btnGuards.FlatStyle = FlatStyle.Flat;
            btnGuards.Font = new Font("Segoe UI", 9F);
            btnGuards.ForeColor = SystemColors.ControlText;
            btnGuards.ImageAlign = ContentAlignment.MiddleLeft;
            btnGuards.Location = new Point(3, 38);
            btnGuards.Name = "btnGuards";
            btnGuards.Size = new Size(189, 33);
            btnGuards.TabIndex = 5;
            btnGuards.Text = "Guards  >";
            btnGuards.TextAlign = ContentAlignment.MiddleLeft;
            btnGuards.UseVisualStyleBackColor = false;
            btnGuards.Click += btnGuards_Click;
            // 
            // btnTypeofleaves
            // 
            btnTypeofleaves.BackColor = Color.White;
            btnTypeofleaves.CausesValidation = false;
            btnTypeofleaves.FlatStyle = FlatStyle.Flat;
            btnTypeofleaves.Font = new Font("Segoe UI", 9F);
            btnTypeofleaves.ForeColor = Color.Black;
            btnTypeofleaves.Location = new Point(3, 389);
            btnTypeofleaves.Name = "btnTypeofleaves";
            btnTypeofleaves.Size = new Size(189, 33);
            btnTypeofleaves.TabIndex = 5;
            btnTypeofleaves.Text = "Type of Leaves   >";
            btnTypeofleaves.TextAlign = ContentAlignment.MiddleLeft;
            btnTypeofleaves.UseVisualStyleBackColor = false;
            btnTypeofleaves.Click += btnTypeOfLeaves_Click;
            // 
            // btnRosters
            // 
            btnRosters.BackColor = Color.White;
            btnRosters.FlatStyle = FlatStyle.Flat;
            btnRosters.Font = new Font("Segoe UI", 9F);
            btnRosters.ForeColor = Color.Black;
            btnRosters.Location = new Point(3, 272);
            btnRosters.Name = "btnRosters";
            btnRosters.Size = new Size(189, 33);
            btnRosters.TabIndex = 11;
            btnRosters.Text = "Rosters   >";
            btnRosters.TextAlign = ContentAlignment.MiddleLeft;
            btnRosters.UseVisualStyleBackColor = false;
            btnRosters.Click += btnRosters_Click;
            // 
            // btnSites
            // 
            btnSites.BackColor = Color.White;
            btnSites.FlatStyle = FlatStyle.Flat;
            btnSites.Font = new Font("Segoe UI", 9F);
            btnSites.ForeColor = Color.Black;
            btnSites.Location = new Point(3, 77);
            btnSites.Name = "btnSites";
            btnSites.Size = new Size(189, 33);
            btnSites.TabIndex = 6;
            btnSites.Text = "Sites   >";
            btnSites.TextAlign = ContentAlignment.MiddleLeft;
            btnSites.UseVisualStyleBackColor = false;
            btnSites.Click += btnSites_Click;
            // 
            // btnSpecialShifts
            // 
            btnSpecialShifts.BackColor = Color.White;
            btnSpecialShifts.FlatStyle = FlatStyle.Flat;
            btnSpecialShifts.Font = new Font("Segoe UI", 9F);
            btnSpecialShifts.ForeColor = Color.Black;
            btnSpecialShifts.Location = new Point(3, 233);
            btnSpecialShifts.Name = "btnSpecialShifts";
            btnSpecialShifts.Size = new Size(189, 33);
            btnSpecialShifts.TabIndex = 10;
            btnSpecialShifts.Text = "Special Shifts   >";
            btnSpecialShifts.TextAlign = ContentAlignment.MiddleLeft;
            btnSpecialShifts.UseVisualStyleBackColor = false;
            btnSpecialShifts.Click += btnSpecialShifts_Click;
            // 
            // btnPosts
            // 
            btnPosts.BackColor = Color.White;
            btnPosts.FlatStyle = FlatStyle.Flat;
            btnPosts.Font = new Font("Segoe UI", 9F);
            btnPosts.ForeColor = Color.Black;
            btnPosts.Location = new Point(3, 116);
            btnPosts.Name = "btnPosts";
            btnPosts.Size = new Size(189, 33);
            btnPosts.TabIndex = 7;
            btnPosts.Text = "Posts    >";
            btnPosts.TextAlign = ContentAlignment.MiddleLeft;
            btnPosts.UseVisualStyleBackColor = false;
            btnPosts.Click += btnPosts_Click;
            // 
            // btnRegularShifts
            // 
            btnRegularShifts.BackColor = Color.White;
            btnRegularShifts.FlatStyle = FlatStyle.Flat;
            btnRegularShifts.Font = new Font("Segoe UI", 9F);
            btnRegularShifts.ForeColor = Color.Black;
            btnRegularShifts.Location = new Point(3, 194);
            btnRegularShifts.Name = "btnRegularShifts";
            btnRegularShifts.RightToLeft = RightToLeft.No;
            btnRegularShifts.Size = new Size(189, 33);
            btnRegularShifts.TabIndex = 9;
            btnRegularShifts.Text = "Regular Shifts   >";
            btnRegularShifts.TextAlign = ContentAlignment.MiddleLeft;
            btnRegularShifts.UseVisualStyleBackColor = false;
            btnRegularShifts.Click += btnRegularShifts_Click;
            // 
            // btnShiftTypes
            // 
            btnShiftTypes.BackColor = Color.White;
            btnShiftTypes.FlatStyle = FlatStyle.Flat;
            btnShiftTypes.Font = new Font("Segoe UI", 9F);
            btnShiftTypes.ForeColor = Color.Black;
            btnShiftTypes.Location = new Point(3, 155);
            btnShiftTypes.Name = "btnShiftTypes";
            btnShiftTypes.Size = new Size(189, 33);
            btnShiftTypes.TabIndex = 8;
            btnShiftTypes.Text = "Shift of Types   >";
            btnShiftTypes.TextAlign = ContentAlignment.MiddleLeft;
            btnShiftTypes.UseVisualStyleBackColor = false;
            btnShiftTypes.Click += btnShiftTypes_Click;
            // 
            // dataGridView1
            // 
            dataGridView1.BackgroundColor = Color.FromArgb(31, 45, 61);
            dataGridView1.BorderStyle = BorderStyle.None;
            dataGridView1.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridView1.Location = new Point(207, 192);
            dataGridView1.Name = "dataGridView1";
            dataGridView1.Size = new Size(856, 442);
            dataGridView1.TabIndex = 4;
            dataGridView1.CellContentClick += dataGridView1_CellContentClick;
            // 
            // btnAdd
            // 
            btnAdd.BackColor = Color.White;
            btnAdd.FlatAppearance.BorderSize = 0;
            btnAdd.FlatStyle = FlatStyle.Flat;
            btnAdd.Font = new Font("Segoe UI", 10F);
            btnAdd.ForeColor = Color.Black;
            btnAdd.Location = new Point(207, 147);
            btnAdd.Name = "btnAdd";
            btnAdd.Size = new Size(189, 33);
            btnAdd.TabIndex = 9;
            btnAdd.Text = "Add";
            btnAdd.UseVisualStyleBackColor = false;
            btnAdd.Click += btnAdd_Click;
            // 
            // btnEdit
            // 
            btnEdit.BackColor = Color.White;
            btnEdit.FlatAppearance.BorderSize = 0;
            btnEdit.FlatStyle = FlatStyle.Flat;
            btnEdit.Font = new Font("Segoe UI", 10F);
            btnEdit.ForeColor = Color.Black;
            btnEdit.Location = new Point(553, 147);
            btnEdit.Name = "btnEdit";
            btnEdit.Size = new Size(189, 33);
            btnEdit.TabIndex = 10;
            btnEdit.Text = "Edit";
            btnEdit.UseVisualStyleBackColor = false;
            btnEdit.Click += btnEdit_Click;
            // 
            // btnSave
            // 
            btnSave.BackColor = Color.White;
            btnSave.FlatAppearance.BorderSize = 0;
            btnSave.FlatStyle = FlatStyle.Flat;
            btnSave.Font = new Font("Segoe UI", 10F);
            btnSave.ForeColor = Color.Black;
            btnSave.Location = new Point(874, 147);
            btnSave.Name = "btnSave";
            btnSave.Size = new Size(189, 33);
            btnSave.TabIndex = 11;
            btnSave.Text = "Save";
            btnSave.UseVisualStyleBackColor = false;
            btnSave.Click += btnSave_Click;
            // 
            // lblRole
            // 
            lblRole.AutoSize = true;
            lblRole.Font = new Font("Microsoft Sans Serif", 8F);
            lblRole.ForeColor = Color.LightGray;
            lblRole.Location = new Point(883, 28);
            lblRole.Name = "lblRole";
            lblRole.Size = new Size(29, 13);
            lblRole.TabIndex = 22;
            lblRole.Text = "Role";
            // 
            // lblUsername
            // 
            lblUsername.AutoSize = true;
            lblUsername.Font = new Font("Microsoft Sans Serif", 9.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            lblUsername.ForeColor = Color.White;
            lblUsername.Location = new Point(883, 9);
            lblUsername.Name = "lblUsername";
            lblUsername.Size = new Size(40, 16);
            lblUsername.TabIndex = 21;
            lblUsername.Text = "User";
            // 
            // btnDelete
            // 
            btnDelete.BackColor = Color.White;
            btnDelete.FlatAppearance.BorderSize = 0;
            btnDelete.FlatStyle = FlatStyle.Flat;
            btnDelete.Font = new Font("Segoe UI", 10F);
            btnDelete.ForeColor = Color.Black;
            btnDelete.Location = new Point(565, 653);
            btnDelete.Name = "btnDelete";
            btnDelete.Size = new Size(189, 33);
            btnDelete.TabIndex = 23;
            btnDelete.Text = "Delete";
            btnDelete.UseVisualStyleBackColor = false;
            btnDelete.Click += btnDelete_Click;
            // 
            // SupervisorJB
            // 
            AutoScaleDimensions = new SizeF(7F, 17F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.FromArgb(31, 45, 61);
            ClientSize = new Size(1089, 749);
            Controls.Add(btnDelete);
            Controls.Add(lblRole);
            Controls.Add(btnSave);
            Controls.Add(lblUsername);
            Controls.Add(btnEdit);
            Controls.Add(btnAdd);
            Controls.Add(dataGridView1);
            Controls.Add(panel2);
            Controls.Add(panel1);
            Controls.Add(label1);
            Font = new Font("Segoe UI", 10F);
            Name = "SupervisorJB";
            Text = "+-";
            Load += SupervisorJB_Load;
            panel1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)dataGridView1).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label1;
        private Panel panel1;
        private Panel panel2;
        private Button btnGuards;
        private Button btnSites;
        private Button btnPosts;
        private Button btnRegularShifts;
        private Button btnShiftTypes;
        private Button btnSpecialShifts;
        private Button btnRosters;
        private Button btnRosterAssign;
        private Button btnTypeofleaves;
        private Button btnLeaveApp;
        private Button btnProfile;
        private Button btnAttendances;
        private DataGridView dataGridView1;
        private Button btnAdd;
        private Button btnEdit;
        private Button btnSave;
        private Button btnBack;
        private Label lblRole;
        private Label lblUsername;
        private PictureBox pictureBox1;
        private Button btnDelete;
    }
}