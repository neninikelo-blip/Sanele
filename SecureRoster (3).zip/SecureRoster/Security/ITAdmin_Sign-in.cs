﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace Security
{
    public partial class ITAdmin : Form
    {
        public ITAdmin()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
        private void button2_Click(object sender, EventArgs e)
        {
            Form3 F3 = new Form3();
            F3.Show();
            this.Hide();
        }
        private void button3_Click(object sender, EventArgs e)
        {
            // Put whatever you want button3 to do here
            MessageBox.Show("Button 3 clicked!");
            Form3 F3 = new Form3();
            F3.Show();
            this.Hide();
        }

        private void ITAdmin_Load(object sender, EventArgs e)
        {

        }
    }
}
