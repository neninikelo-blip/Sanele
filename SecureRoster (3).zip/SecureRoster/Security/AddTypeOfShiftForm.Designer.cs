﻿namespace Security
{
    partial class AddTypeOfShiftForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            label3 = new Label();
            label2 = new Label();
            label1 = new Label();
            txtEndTime = new TextBox();
            txtStartTime = new TextBox();
            txtTypeOfShift = new TextBox();
            btnCancel = new Button();
            btnSave = new Button();
         
            SuspendLayout();
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(13, 106);
            label3.Name = "label3";
            label3.Size = new Size(57, 15);
            label3.TabIndex = 11;
            label3.Text = "End Time";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(13, 56);
            label2.Name = "label2";
            label2.Size = new Size(61, 15);
            label2.TabIndex = 10;
            label2.Text = "Start Time";
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(13, 12);
            label1.Name = "label1";
            label1.Size = new Size(75, 15);
            label1.TabIndex = 9;
            label1.Text = "Type Of Shift";
            // 
            // txtEndTime
            // 
            txtEndTime.Location = new Point(155, 103);
            txtEndTime.Name = "txtEndTime";
            txtEndTime.Size = new Size(100, 23);
            txtEndTime.TabIndex = 8;
            // 
            // txtStartTime
            // 
            txtStartTime.Location = new Point(155, 56);
            txtStartTime.Name = "txtStartTime";
            txtStartTime.Size = new Size(100, 23);
            txtStartTime.TabIndex = 7;
            // 
            // txtTypeOfShift
            // 
            txtTypeOfShift.Location = new Point(155, 12);
            txtTypeOfShift.Name = "txtTypeOfShift";
            txtTypeOfShift.Size = new Size(100, 23);
            txtTypeOfShift.TabIndex = 6;
            // 
            // btnCancel
            // 
            btnCancel.Location = new Point(268, 253);
            btnCancel.Name = "btnCancel";
            btnCancel.Size = new Size(75, 23);
            btnCancel.TabIndex = 13;
            btnCancel.Text = "Cancel";
            btnCancel.UseVisualStyleBackColor = true;
            btnCancel.Click += btnCancel_Click;
            // 
            // btnSave
            // 
            btnSave.Location = new Point(15, 253);
            btnSave.Name = "btnSave";
            btnSave.Size = new Size(75, 23);
            btnSave.TabIndex = 12;
            btnSave.Text = "Save";
            btnSave.UseVisualStyleBackColor = true;
            btnSave.Click += btnSave_Click;
            // 
          
            // 
            // AddTypeOfShiftForm
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.FromArgb(31, 45, 61);
            ClientSize = new Size(506, 294);
            Controls.Add(btnCancel);
            Controls.Add(btnSave);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(label1);
            Controls.Add(txtEndTime);
            Controls.Add(txtStartTime);
            Controls.Add(txtTypeOfShift);
            Name = "AddTypeOfShiftForm";
            Text = "AddTypeOfShiftForm";
            Load += AddTypeOfShiftForm_Load;
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label3;
        private Label label2;
        private Label label1;
        private TextBox txtEndTime;
        private TextBox txtStartTime;
        private TextBox txtTypeOfShift;
        private Button btnCancel;
        private Button btnSave;
        
    }
}