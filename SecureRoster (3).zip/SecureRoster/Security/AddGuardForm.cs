﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using Microsoft.Data.SqlClient;
// using System.Data;

namespace Security
{
    public partial class AddGuardForm : Form
    {
        SqlConnection con = new SqlConnection("Data Source=DESKTOP-133OPA4\\SQLEXPRESS;" + "Initial Catalog=SecureRoster;" + "Integrated Security=True;" + "Encrypt=False;" + "Connect Timeout=60;");

        public AddGuardForm()
        {
            InitializeComponent();
        }

        private void AddGuardForm_Load(object sender, EventArgs e)
        {
            cmbGender.Items.Clear();
            cmbGender.Items.AddRange(new object[] { "M", "F", "Other" });
            cmbGender.DropDownStyle = ComboBoxStyle.DropDownList;

            SqlDataAdapter da = new SqlDataAdapter(
                "SELECT SiteID, NameOfSite FROM Sites",
                con);

            DataTable dt = new DataTable();

            da.Fill(dt);

            comboBox1.DataSource = dt;

            comboBox1.DisplayMember = "NameOfSite";

            comboBox1.ValueMember = "SiteID";

        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            // Guard clauses
            if (string.IsNullOrWhiteSpace(txtFirstName.Text)) { MessageBox.Show("First name required."); return; }
            if (string.IsNullOrWhiteSpace(txtlastname.Text)) { MessageBox.Show("Last name required."); return; }
            if (string.IsNullOrWhiteSpace(txtUsername.Text)) { MessageBox.Show("Username required."); return; }
            if (string.IsNullOrWhiteSpace(txtPassword.Text)) { MessageBox.Show("Password required."); return; }
            if (string.IsNullOrWhiteSpace(comboBox1.Text)) { MessageBox.Show("Select a site."); return; }
            if (string.IsNullOrWhiteSpace(cmbGender.Text)) { MessageBox.Show("Select a gender."); return; }


            // Validate Cell Number (SA format - 10 digits starting with 0)
            if (!System.Text.RegularExpressions.Regex.IsMatch(txtCellNO.Text, @"^0\d{9}$"))
            {
                MessageBox.Show("Please enter a valid 10-digit cell number (e.g., 0821234567).");
                return;
            }

            // Validate ID Number (SA 13-digit format)
            if (!System.Text.RegularExpressions.Regex.IsMatch(txtID_NO.Text, @"^\d{13}$"))
            {
                MessageBox.Show("Please enter a valid 13-digit SA ID number.");
                return;
            }


            try
            {
                con.Open();

                // 1. Check Capacity BEFORE starting transaction
                int selectedSiteID = Convert.ToInt32(comboBox1.SelectedValue);
                SqlCommand capacityCmd = new SqlCommand(
                    @"SELECT s.SiteCapacity, 
             (SELECT COUNT(*) FROM Guards WHERE SiteID = s.SiteID) AS CurrentGuards
             FROM Sites s WHERE SiteID = @sid", con);
                capacityCmd.Parameters.AddWithValue("@sid", selectedSiteID);

                SqlDataReader dr = capacityCmd.ExecuteReader();
                if (dr.Read())
                {
                    int capacity = Convert.ToInt32(dr["SiteCapacity"]);
                    int currentGuards = Convert.ToInt32(dr["CurrentGuards"]);

                    if (currentGuards >= capacity)
                    {
                        dr.Close();
                        MessageBox.Show("This site is already at maximum capacity! Cannot add another guard.");
                        con.Close();
                        return; // stop the save
                    }
                }
                dr.Close();

                SqlTransaction tx = con.BeginTransaction();

                try
                {
                    // 2) Next PersonID
                    SqlCommand idCmd = new SqlCommand(
                        "SELECT ISNULL(MAX(PersonID),0) + 1 FROM Persons", con, tx);
                    int personID = Convert.ToInt32(idCmd.ExecuteScalar());

                    // 3) Insert Person
                    SqlCommand personCmd = new SqlCommand(
                        @"INSERT INTO Persons
(PersonID, FirstName, LastName, Email, CellNumber, ID_Number, Gender, Username)
VALUES
(@pid, @fname, @lname, @email, @cell, @idnum, @gender, @user)",
                        con, tx);

                    personCmd.Parameters.AddWithValue("@pid", personID);
                    personCmd.Parameters.AddWithValue("@fname", txtFirstName.Text);
                    personCmd.Parameters.AddWithValue("@lname", txtlastname.Text);
                    personCmd.Parameters.AddWithValue("@email", txtEmail.Text); // <-- ADDED EMAIL HERE
                    personCmd.Parameters.AddWithValue("@cell", txtCellNO.Text);
                    personCmd.Parameters.AddWithValue("@idnum", txtID_NO.Text);
                    personCmd.Parameters.AddWithValue("@gender", cmbGender.Text);
                    personCmd.Parameters.AddWithValue("@user", txtUsername.Text);
                    personCmd.ExecuteNonQuery();

                    // 4) Next GuardID
                    SqlCommand gidCmd = new SqlCommand(
                        "SELECT ISNULL(MAX(GuardID),0) + 1 FROM Guards", con, tx);
                    int guardID = Convert.ToInt32(gidCmd.ExecuteScalar());

                    // 5) Insert Guard
                    SqlCommand guardCmd = new SqlCommand(
                        @"INSERT INTO Guards (GuardID, PersonID, SiteID)
                  VALUES (@gid, @pid, @siteid)", con, tx);

                    guardCmd.Parameters.AddWithValue("@gid", guardID);
                    guardCmd.Parameters.AddWithValue("@pid", personID);
                    guardCmd.Parameters.AddWithValue("@siteid", comboBox1.SelectedValue);
                    guardCmd.ExecuteNonQuery();

                    // 6) Hash the password
                    var (salt, hash) = PasswordHasher.CreateHash(txtPassword.Text);

                    // 7) Next AccountID
                    SqlCommand aidCmd = new SqlCommand(
                        "SELECT ISNULL(MAX(AccountID),0) + 1 FROM Accounts", con, tx);
                    int accountID = Convert.ToInt32(aidCmd.ExecuteScalar());

                    // 8) Insert Account
                    SqlCommand accCmd = new SqlCommand(
                        @"INSERT INTO Accounts
                    (AccountID, PersonID, Username, PasswordSalt, PasswordHash, Role_)
                  VALUES
                    (@aid, @pid, @user, @salt, @hash, @role)", con, tx);

                    accCmd.Parameters.AddWithValue("@aid", accountID);
                    accCmd.Parameters.AddWithValue("@pid", personID);
                    accCmd.Parameters.AddWithValue("@user", txtUsername.Text);
                    accCmd.Parameters.AddWithValue("@salt", salt);
                    accCmd.Parameters.AddWithValue("@hash", hash);
                    accCmd.Parameters.AddWithValue("@role", "Guard");
                    accCmd.ExecuteNonQuery();

                    // 9) Commit
                    tx.Commit();

                    MessageBox.Show("Guard added. They can now log in.");
                    con.Close();
                    this.Close();
                }
                catch
                {
                    tx.Rollback();
                    throw;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
    



        

        private void btnCancel_Click(object sender, EventArgs e)
        {
            this.Hide();
        }
    }

}
