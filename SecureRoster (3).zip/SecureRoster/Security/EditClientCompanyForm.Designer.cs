﻿namespace Security
{
    partial class EditClientCompanyForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            txtCompanyName = new TextBox();
            comboBoxSuburb = new ComboBox();
            comboBoxCompany = new ComboBox();
            label5 = new Label();
            label6 = new Label();
            btnCancel = new Button();
            btnSave = new Button();
            label3 = new Label();
            label2 = new Label();
            label1 = new Label();
            txtCompanyCell = new TextBox();
            txtCompanyEmail = new TextBox();
            SuspendLayout();
            // 
            // txtCompanyName
            // 
            txtCompanyName.Location = new Point(155, 12);
            txtCompanyName.Name = "txtCompanyName";
            txtCompanyName.Size = new Size(100, 23);
            txtCompanyName.TabIndex = 80;
            // 
            // comboBoxSuburb
            // 
            comboBoxSuburb.FormattingEnabled = true;
            comboBoxSuburb.Location = new Point(414, 97);
            comboBoxSuburb.Name = "comboBoxSuburb";
            comboBoxSuburb.Size = new Size(121, 23);
            comboBoxSuburb.TabIndex = 78;
            // 
            // comboBoxCompany
            // 
            comboBoxCompany.FormattingEnabled = true;
            comboBoxCompany.Location = new Point(414, 9);
            comboBoxCompany.Name = "comboBoxCompany";
            comboBoxCompany.Size = new Size(121, 23);
            comboBoxCompany.TabIndex = 77;
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Location = new Point(14, 20);
            label5.Name = "label5";
            label5.Size = new Size(94, 15);
            label5.TabIndex = 76;
            label5.Text = "Company Name";
            // 
            // label6
            // 
            label6.Location = new Point(293, 12);
            label6.Name = "label6";
            label6.Size = new Size(100, 23);
            label6.TabIndex = 79;
            label6.Text = "Company";
            // 
            // btnCancel
            // 
            btnCancel.Location = new Point(327, 289);
            btnCancel.Name = "btnCancel";
            btnCancel.Size = new Size(75, 23);
            btnCancel.TabIndex = 75;
            btnCancel.Text = "Cancel";
            btnCancel.UseVisualStyleBackColor = true;
            btnCancel.Click += btnCancel_Click_1;
            // 
            // btnSave
            // 
            btnSave.Location = new Point(74, 289);
            btnSave.Name = "btnSave";
            btnSave.Size = new Size(75, 23);
            btnSave.TabIndex = 74;
            btnSave.Text = "Save";
            btnSave.UseVisualStyleBackColor = true;
            btnSave.Click += btnSave_Click_1;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(13, 112);
            label3.Name = "label3";
            label3.Size = new Size(82, 15);
            label3.TabIndex = 73;
            label3.Text = "Company Cell";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(293, 100);
            label2.Name = "label2";
            label2.Size = new Size(45, 15);
            label2.TabIndex = 72;
            label2.Text = "Suburb";
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(13, 62);
            label1.Name = "label1";
            label1.Size = new Size(91, 15);
            label1.TabIndex = 71;
            label1.Text = "Company Email";
            // 
            // txtCompanyCell
            // 
            txtCompanyCell.Location = new Point(155, 109);
            txtCompanyCell.Name = "txtCompanyCell";
            txtCompanyCell.Size = new Size(100, 23);
            txtCompanyCell.TabIndex = 70;
            // 
            // txtCompanyEmail
            // 
            txtCompanyEmail.Location = new Point(155, 62);
            txtCompanyEmail.Name = "txtCompanyEmail";
            txtCompanyEmail.Size = new Size(100, 23);
            txtCompanyEmail.TabIndex = 69;
            // 
            // EditClientCompanyForm
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.FromArgb(31, 45, 61);
            ClientSize = new Size(559, 373);
            Controls.Add(txtCompanyName);
            Controls.Add(comboBoxSuburb);
            Controls.Add(comboBoxCompany);
            Controls.Add(label5);
            Controls.Add(label6);
            Controls.Add(btnCancel);
            Controls.Add(btnSave);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(label1);
            Controls.Add(txtCompanyCell);
            Controls.Add(txtCompanyEmail);
            Name = "EditClientCompanyForm";
            Text = "EditClientCompanyForm";
            Load += EditClientCompanyForm_Load;
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private TextBox txtCompanyName;
        private ComboBox comboBoxSuburb;
        private ComboBox comboBoxCompany;
        private Label label5;
        private Label label6;
        private Button btnCancel;
        private Button btnSave;
        private Label label3;
        private Label label2;
        private Label label1;
        private TextBox txtCompanyCell;
        private TextBox txtCompanyEmail;
    }
}