﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using Microsoft.Data.SqlClient;
namespace Security
{
    public partial class EditSecurityCompanyForm : Form
    {
        private int securityCompID;
        public EditSecurityCompanyForm(int id)
        {
            InitializeComponent();
            securityCompID = id;
        }
        SqlConnection con = new SqlConnection("Data Source=DESKTOP-133OPA4\\SQLEXPRESS;" + "Initial Catalog=SecureRoster;" + "Integrated Security=True;" + "Encrypt=False;");


        private void EditSecurityCompanyForm_Load(object sender, EventArgs e)
        {
            // 1. Load Suburbs
            SqlDataAdapter da = new SqlDataAdapter(
                "SELECT SuburbID, SuburbName FROM Suburbs", con);
            DataTable dt = new DataTable();
            da.Fill(dt);
            cmbSuburb.DataSource = dt;
            cmbSuburb.DisplayMember = "SuburbName";
            cmbSuburb.ValueMember = "SuburbID";

            // 2. Load ONLY valid Security Companies
            SqlDataAdapter da2 = new SqlDataAdapter(
                @"SELECT c.CompanyID, c.CompanyName 
          FROM Companies c
          WHERE c.CompanyID NOT IN (SELECT CompanyID FROM ClientCompanies)
          OR c.CompanyID = (SELECT CompanyID FROM SecurityCompanies WHERE SecurityCompID = @id)", con);

            da2.SelectCommand.Parameters.AddWithValue("@id", securityCompID);

            DataTable dt2 = new DataTable();
            da2.Fill(dt2);
            cmbCompany.DataSource = dt2;
            cmbCompany.DisplayMember = "CompanyName";
            cmbCompany.ValueMember = "CompanyID";

            // 3. Load existing data
            try
            {
                con.Open();
                SqlCommand cmd = new SqlCommand(
                    @"SELECT COMPANY_ID, COMPANYNAME, COMPANYCELL, COMPANYEMAIL, SUBURB_ID
              FROM SecurityCompaniesView WHERE SECURITYCOMP_ID = @id", con);
                cmd.Parameters.AddWithValue("@id", securityCompID);

                SqlDataReader dr = cmd.ExecuteReader();
                if (dr.Read())
                {
                    txtCompanyName.Text = dr["COMPANYNAME"].ToString();
                    txtCompanyCell.Text = dr["COMPANYCELL"].ToString();
                    txtCompanyEmail.Text = dr["COMPANYEMAIL"].ToString();

                    cmbCompany.SelectedValue = Convert.ToInt32(dr["COMPANY_ID"]);
                    if (dr["SUBURB_ID"] != DBNull.Value)
                    {
                        cmbSuburb.SelectedValue = Convert.ToInt32(dr["SUBURB_ID"]);
                    }
                }
                dr.Close();
                con.Close();
            }
            catch (Exception ex) { MessageBox.Show(ex.Message); }
         }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            this.Close();
        }
        private void btnSave_Click(object sender, EventArgs e)
        {
            try
            {
                con.Open();

                // Update Companies table
                SqlCommand cmd = new SqlCommand(
                    @"UPDATE Companies
              SET CompanyName  = @name,
                  CompanyCell  = @cell,
                  CompanyEmail = @email
              WHERE CompanyID = @companyid", con);

                cmd.Parameters.AddWithValue("@name", txtCompanyName.Text);
                cmd.Parameters.AddWithValue("@cell", txtCompanyCell.Text);
                cmd.Parameters.AddWithValue("@email", txtCompanyEmail.Text);
                cmd.Parameters.AddWithValue("@companyid", cmbCompany.SelectedValue);

                cmd.ExecuteNonQuery();

                // Update SecurityCompanies table (Suburb)
                SqlCommand scCmd = new SqlCommand(
                    @"UPDATE SecurityCompanies
              SET SuburbID = @suburbid
              WHERE SecurityCompID = @id", con);

                scCmd.Parameters.AddWithValue("@suburbid", cmbSuburb.SelectedValue);
                scCmd.Parameters.AddWithValue("@id", securityCompID);

                scCmd.ExecuteNonQuery();

                MessageBox.Show("Security Company Updated Successfully");
                con.Close();
                this.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
                con.Close(); // Ensure connection closes if there's an error
            }
        }
    }
}
