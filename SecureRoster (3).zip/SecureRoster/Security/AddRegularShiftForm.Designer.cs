﻿namespace Security
{
    partial class AddRegularShiftForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            btnCancel = new Button();
            btnSave = new Button();
            label3 = new Label();
            label2 = new Label();
            label1 = new Label();
            txtNameOfShift = new TextBox();
            cmbTypeShift = new ComboBox();
            cmbPost = new ComboBox();
            SuspendLayout();
            // 
            // btnCancel
            // 
            btnCancel.Location = new Point(265, 253);
            btnCancel.Name = "btnCancel";
            btnCancel.Size = new Size(75, 23);
            btnCancel.TabIndex = 21;
            btnCancel.Text = "Cancel";
            btnCancel.UseVisualStyleBackColor = true;
            btnCancel.Click += btnCancel_Click;
            // 
            // btnSave
            // 
            btnSave.Location = new Point(12, 253);
            btnSave.Name = "btnSave";
            btnSave.Size = new Size(75, 23);
            btnSave.TabIndex = 20;
            btnSave.Text = "Save";
            btnSave.UseVisualStyleBackColor = true;
            btnSave.Click += btnSave_Click;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(10, 106);
            label3.Name = "label3";
            label3.Size = new Size(80, 15);
            label3.TabIndex = 19;
            label3.Text = "Name of Shift";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(10, 56);
            label2.Name = "label2";
            label2.Size = new Size(30, 15);
            label2.TabIndex = 18;
            label2.Text = "Post";
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(10, 12);
            label1.Name = "label1";
            label1.Size = new Size(75, 15);
            label1.TabIndex = 17;
            label1.Text = "Type Of Shift";
            // 
            // txtNameOfShift
            // 
            txtNameOfShift.Location = new Point(152, 103);
            txtNameOfShift.Name = "txtNameOfShift";
            txtNameOfShift.Size = new Size(121, 23);
            txtNameOfShift.TabIndex = 16;
            // 
            // cmbTypeShift
            // 
            cmbTypeShift.FormattingEnabled = true;
            cmbTypeShift.Location = new Point(152, 12);
            cmbTypeShift.Name = "cmbTypeShift";
            cmbTypeShift.Size = new Size(121, 23);
            cmbTypeShift.TabIndex = 22;
            // 
            // cmbPost
            // 
            cmbPost.FormattingEnabled = true;
            cmbPost.Location = new Point(152, 56);
            cmbPost.Name = "cmbPost";
            cmbPost.Size = new Size(121, 23);
            cmbPost.TabIndex = 23;
            // 
            // AddRegularShiftForm
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.FromArgb(31, 45, 61);
            ClientSize = new Size(367, 338);
            Controls.Add(cmbPost);
            Controls.Add(cmbTypeShift);
            Controls.Add(btnCancel);
            Controls.Add(btnSave);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(label1);
            Controls.Add(txtNameOfShift);
            Name = "AddRegularShiftForm";
            Text = "AddRegularShiftForm";
            Load += AddRegularShiftForm_Load;
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Button btnCancel;
        private Button btnSave;
        private Label label3;
        private Label label2;
        private Label label1;
        private TextBox txtNameOfShift;
        private ComboBox cmbTypeShift;
        private ComboBox cmbPost;
    }
}