﻿namespace Security
{
    public static class Session
    {
        public static int AccountID;
        public static int PersonID;
        public static string Username = "";
        public static string Role = "";
        public static string FullName = "";
        public static int GuardID;
        public static int SupervisorID;
        public static int ManagerID;
        public static int ITAdminID;

        public static int CompanyID;
        public static int SiteID;
    }
}