﻿namespace Security
{
    partial class AddSecurityCompanyForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            txtCompanyName = new TextBox();
            comboBoxSuburb = new ComboBox();
            comboBoxCompany = new ComboBox();
            label5 = new Label();
            label6 = new Label();
            btnCancel = new Button();
            btnSave = new Button();
            label3 = new Label();
            label2 = new Label();
            label1 = new Label();
            txtCompanyCell = new TextBox();
            txtCompanyEmail = new TextBox();
            SuspendLayout();
            // 
            // txtCompanyName
            // 
            txtCompanyName.Location = new Point(163, 12);
            txtCompanyName.Name = "txtCompanyName";
            txtCompanyName.Size = new Size(100, 23);
            txtCompanyName.TabIndex = 68;
            // 
            // comboBoxSuburb
            // 
            comboBoxSuburb.FormattingEnabled = true;
            comboBoxSuburb.Location = new Point(422, 97);
            comboBoxSuburb.Name = "comboBoxSuburb";
            comboBoxSuburb.Size = new Size(121, 23);
            comboBoxSuburb.TabIndex = 66;
            // 
            // comboBoxCompany
            // 
            comboBoxCompany.FormattingEnabled = true;
            comboBoxCompany.Location = new Point(422, 9);
            comboBoxCompany.Name = "comboBoxCompany";
            comboBoxCompany.Size = new Size(121, 23);
            comboBoxCompany.TabIndex = 65;
            comboBoxCompany.SelectedIndexChanged += cmbCompany_SelectedIndexChanged;
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Location = new Point(22, 20);
            label5.Name = "label5";
            label5.Size = new Size(94, 15);
            label5.TabIndex = 64;
            label5.Text = "Company Name";
            // 
            // label6
            // 
            label6.Location = new Point(301, 12);
            label6.Name = "label6";
            label6.Size = new Size(100, 23);
            label6.TabIndex = 67;
            label6.Text = "Company";
            // 
            // btnCancel
            // 
            btnCancel.Location = new Point(335, 289);
            btnCancel.Name = "btnCancel";
            btnCancel.Size = new Size(75, 23);
            btnCancel.TabIndex = 63;
            btnCancel.Text = "Cancel";
            btnCancel.UseVisualStyleBackColor = true;
            btnCancel.Click += btnCancel_Click;
            // 
            // btnSave
            // 
            btnSave.Location = new Point(82, 289);
            btnSave.Name = "btnSave";
            btnSave.Size = new Size(75, 23);
            btnSave.TabIndex = 62;
            btnSave.Text = "Save";
            btnSave.UseVisualStyleBackColor = true;
            btnSave.Click += btnSave_Click;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(21, 112);
            label3.Name = "label3";
            label3.Size = new Size(82, 15);
            label3.TabIndex = 61;
            label3.Text = "Company Cell";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(301, 100);
            label2.Name = "label2";
            label2.Size = new Size(45, 15);
            label2.TabIndex = 60;
            label2.Text = "Suburb";
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(21, 62);
            label1.Name = "label1";
            label1.Size = new Size(91, 15);
            label1.TabIndex = 59;
            label1.Text = "Company Email";
            // 
            // txtCompanyCell
            // 
            txtCompanyCell.Location = new Point(163, 109);
            txtCompanyCell.Name = "txtCompanyCell";
            txtCompanyCell.Size = new Size(100, 23);
            txtCompanyCell.TabIndex = 58;
            // 
            // txtCompanyEmail
            // 
            txtCompanyEmail.Location = new Point(163, 62);
            txtCompanyEmail.Name = "txtCompanyEmail";
            txtCompanyEmail.Size = new Size(100, 23);
            txtCompanyEmail.TabIndex = 57;
            // 
            // AddSecurityCompanyForm
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.FromArgb(31, 45, 61);
            ClientSize = new Size(578, 343);
            Controls.Add(txtCompanyName);
            Controls.Add(comboBoxSuburb);
            Controls.Add(comboBoxCompany);
            Controls.Add(label5);
            Controls.Add(label6);
            Controls.Add(btnCancel);
            Controls.Add(btnSave);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(label1);
            Controls.Add(txtCompanyCell);
            Controls.Add(txtCompanyEmail);
            Name = "AddSecurityCompanyForm";
            Text = "AddSecurityCompanyForm";
            Load += AddSecurityCompanyForm_Load;
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private TextBox txtCompanyName;
        private ComboBox cmbSuburb;
        private ComboBox cmbCompany;
        private Label label5;
        private Label label6;
        private Button btnCancel;
        private Button btnSave;
        private Label label3;
        private Label label2;
        private Label label1;
        private TextBox txtCompanyCell;
        private TextBox txtCompanyEmail;
        private ComboBox comboBoxCompany;
        private ComboBox comboBoxSuburb;
    }
}