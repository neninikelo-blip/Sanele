﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using Microsoft.Data.SqlClient;
namespace Security
{
    public partial class SupervisorJB : Form
    {
        public SupervisorJB()
        {
            InitializeComponent();
        }
        SqlConnection con = new SqlConnection("Data Source=DESKTOP-133OPA4\\SQLEXPRESS;" + "Initial Catalog=SecureRoster;" + "Integrated Security=True;" + "Encrypt=False;" + "Connect Timeout=60;");

        private string currentTable = "";
        // Change LoadData to accept parameters
        private void LoadData(string query, SqlParameter[] parameters = null)
        {
            try
            {
                SqlDataAdapter da = new SqlDataAdapter(query, con);
                if (parameters != null) da.SelectCommand.Parameters.AddRange(parameters);
                DataTable dt = new DataTable();
                da.Fill(dt);

                dataGridView1.DataSource = dt;
                this.Text = "Supervisor Portal - " + (currentTable == "" ? "Dashboard" : currentTable);

            }
            catch (Exception ex) { MessageBox.Show(ex.Message); }
        }
        private void button1_Click(object sender, EventArgs e)
        {/*
            SupervisorJB sjb = new SupervisorJB();
            sjb.Show();
            this.Hide();
      */
        }

        private void panel2_Paint(object sender, PaintEventArgs e)
        {

        }

        private void btnGuards_Click(object sender, EventArgs e)
        {
            btnGuards.BackColor = Color.Gray;
            currentTable = "Guards";
            LoadData(@"SELECT FIRSTNAME, LASTNAME, IDNUMBER, GENDER, CELLNUMBER, NAMEOFSITE 
               FROM GuardsView WHERE SITE_ID = @sid",
                     new[] { new SqlParameter("@sid", Session.SiteID) });
         }

        private void button14_Click(object sender, EventArgs e)
        {/*
            SupervisorJB sjb = new SupervisorJB();
            sjb.Show();
            this.Hide();
      */
        }

        private void btnSites_Click(object sender, EventArgs e)
        {
            btnSites.BackColor = Color.Gray;
            currentTable = "Sites";
            LoadData(@"SELECT NAMEOFSITE, SITECAPACITY, COMPANYNAME, SECURITY_COMPANY_NAME, SUBURBNAME, TOWNNAME, CITYNAME, MUNICIPALITYNAME 
               FROM SitesView");
        }

        private void btnPosts_Click(object sender, EventArgs e)
        {
            btnPosts.BackColor = Color.Gray;
            currentTable = "Posts";
            LoadData(@"SELECT POSTNAME, NUMBERPERPOST, NAMEOFSITE 
               FROM SupervisorPostDetails WHERE SITE_ID = @sid",
                     new[] { new SqlParameter("@sid", Session.SiteID) });
        }

        private void btnShiftTypes_Click(object sender, EventArgs e)
        {
            btnShiftTypes.BackColor = Color.Gray;
            currentTable = "Type of Shifts";

            // Notice we are only selecting the specific columns
            LoadData("SELECT TYPEOFSHIFT, STARTTIME, ENDTIME, NAMEOFSITE FROM SupervisorTypeofShiftDetails");
        }

        private void btnRegularShifts_Click(object sender, EventArgs e)
        {
            btnRegularShifts.BackColor = Color.Gray;
            currentTable = "Regular Shifts";
            LoadData(@"SELECT NAMEOFSHIFT, TYPEOFSHIFT, STARTTIME, ENDTIME, POSTNAME, NAMEOFSITE, COMPANYNAME 
               FROM SupervisorRegularShiftDetails WHERE SITE_ID = @sid",
                     new[] { new SqlParameter("@sid", Session.SiteID) });
        }

        private void btnSpecialShifts_Click(object sender, EventArgs e)
        {
            btnSpecialShifts.BackColor = Color.Gray;
            currentTable = "Special Shifts";
            LoadData(@"SELECT NAMEOFSHIFT, SPECIALSHIFTDATE, STARTTIME, ENDTIME, POSTNAME, NAMEOFSITE, COMPANYNAME 
               FROM SupervisorSpecialShiftDetails WHERE SITE_ID = @sid",
                     new[] { new SqlParameter("@sid", Session.SiteID) });
        }

        private void btnRosters_Click(object sender, EventArgs e)
        { btnRosters.BackColor = Color.Gray;
         
            currentTable = "Rosters";
            LoadData(@"SELECT ROSTERNAME, STARTDATE, ENDDATE, NAMEOFSITE 
               FROM RostersDetails WHERE SUPERVISOR_ID = @spid",
                     new[] { new SqlParameter("@spid", Session.SupervisorID) });
        }

        private void btnRosterAssign_Click(object sender, EventArgs e)
        {
            btnRosterAssign.BackColor = Color.Gray;
            currentTable = "Roster Assignments";

            LoadData(@"SELECT 
                  rsa.ASSIGNMENTID,
                  rd.SHIFTDATE,
                  rs.NAMEOFSHIFT,
                  t.TYPEOFSHIFT,
                  p.POSTNAME,
                  gp.FIRSTNAME + ' ' + gp.LASTNAME AS GUARDNAME
              FROM RegularShiftsAssignments rsa
              INNER JOIN RosterDays rd ON rd.RosterDayID = rsa.RosterDayID
              INNER JOIN Rosters r ON rd.Roster_ID = r.RosterID
              INNER JOIN RegularShifts rs ON rs.RegularShiftID = rsa.RegularShiftID
              INNER JOIN TypeOfShifts t ON t.TypeShiftID = rs.TypeShiftID
              INNER JOIN Posts p ON p.PostID = rs.PostID
              INNER JOIN Guards g ON g.GuardID = rsa.GuardID
              INNER JOIN Persons gp ON gp.PersonID = g.PersonID
              WHERE r.SupervisorID = @spid
              ORDER BY rd.SHIFTDATE ASC, t.TYPEOFSHIFT ASC",
                      new[] { new SqlParameter("@spid", Session.SupervisorID) });
        }
        private void btnAttendances_Click(object sender, EventArgs e)
        {
            btnAttendances.BackColor = Color.Gray;
            currentTable = "Attendances";
            LoadData(@"SELECT ShiftDate, FirstName, LastName, NameOfShift, PostName, StartTime, CheckInTime, EndTime, CheckOutTime, AttendanceStatus 
               FROM SupervisorCaptureAttendanceE");
        } 

       /* private void btnOvertimes_Click(object sender, EventArgs e)
        {
            btnOvertimes.BackColor = Color.Gray;
            currentTable = "Overtimes";
            LoadData("SELECT * FROM Overtimes");
        }*/

        private void btnTypeOfLeaves_Click(object sender, EventArgs e)
        {

            btnTypeofleaves.BackColor = Color.Gray;
            currentTable = "Type of Leaves";
            LoadData("SELECT * FROM TypeOfLeaves");
        }

        private void btnLeaveApp_Click(object sender, EventArgs e)
        {
            btnLeaveApp.BackColor = Color.Gray;
            currentTable = "Leave Applications";

            // Notice the "d." in front of the columns
            LoadData(@"SELECT d.LEAVE_ID, d.TYPEOFLEAVE, d.USERNAME, d.FIRSTNAME, d.LASTNAME, 
                     d.STARTDATE, d.ENDDATE, d.LEAVEREASON, d.MAXDAYS, d.CELLNUMBER, d.LEAVESTATUS 
               FROM ManagerLeaveApplicationDetails d
               INNER JOIN Persons p ON d.USERNAME = p.Username
               INNER JOIN Guards g ON p.PersonID = g.PersonID
               WHERE g.SiteID = @sid",
                       new[] { new SqlParameter("@sid", Session.SiteID) });
        }

        private void btnProfile_Click(object sender, EventArgs e)
        {
            btnProfile.BackColor = Color.Gray;
            currentTable = "My Profile";
            LoadData("SELECT * FROM SupervisorView WHERE Username = @user",
                     new[] { new SqlParameter("@user", Session.Username) });
        }

        private void SupervisorJB_Load(object sender, EventArgs e)
        {
            lblUsername.Text = Session.Username.ToUpper() + " ▼";
            lblRole.Text = Session.Role.ToUpper();

            dataGridView1.ReadOnly = true;
            dataGridView1.AllowUserToAddRows = false;
            dataGridView1.AllowUserToDeleteRows = false;
            dataGridView1.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            dataGridView1.MultiSelect = false;



        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            if (currentTable == "Guards" || currentTable == "Sites" || currentTable == "Posts")
            {
                MessageBox.Show("Only Managers are allowed to add " + currentTable);
                return;
            }
            else if (currentTable == "Roster Assignments")
            {
                new AddAssignmentForm().ShowDialog();
                btnRosterAssign_Click(sender, e); // Refresh grid
            }
            else if (currentTable == "Type of Shifts")
            {
                new AddTypeOfShiftForm().ShowDialog();
                LoadData("SELECT * FROM SupervisorTypeOfShiftDetails");
            }
            else if (currentTable == "Regular Shifts")
            {
                new AddRegularShiftForm().ShowDialog();
                LoadData("SELECT * FROM RegularShifts");
            }
            else if (currentTable == "Special Shifts")
            {
                new AddSpecialShiftForm().ShowDialog();
                LoadData("SELECT * FROM SupervisorSpecialShiftDetails");
            }
            else if (currentTable == "Rosters")
            {
                new AddRosterForm().ShowDialog();
                LoadData("SELECT * FROM RostersDetails");
            }
            else if (currentTable == "Attendances")
            {
                new AddAttendanceForm().ShowDialog();
                LoadData("SELECT * FROM SupervisorCaptureAttendanceE");
            }
            else
            {
                MessageBox.Show("Adding is not supported for this list.");
            }

        }

        private void btnEdit_Click(object sender, EventArgs e)
        {
            if (dataGridView1.SelectedRows.Count == 0 ||
                dataGridView1.SelectedRows[0].IsNewRow)
            {
                MessageBox.Show("Please select a row first.");
                return;
            }

            DataGridViewRow row = dataGridView1.SelectedRows[0];


            if (currentTable == "Guards" || currentTable == "Sites" || currentTable == "Posts")
            {
                MessageBox.Show("Only Managers are allowed to edit " + currentTable);
                return;
            }

            else if (currentTable == "Type of Shifts")
            {
                // We can't read the ID from the grid anymore because we hid it.
                // So we look it up in the database using the Shift Name.
                string shiftName = row.Cells["TYPEOFSHIFT"].Value.ToString();

                SqlCommand cmd = new SqlCommand("SELECT TypeShiftID FROM TypeOfShifts WHERE TypeOfShift = @name", con);
                cmd.Parameters.AddWithValue("@name", shiftName);

                if (con.State != ConnectionState.Open) con.Open();
                object result = cmd.ExecuteScalar();
                con.Close();

                if (result != null)
                {
                    int id = Convert.ToInt32(result);
                    new EditTypeOfShiftForm(id).ShowDialog();
                    btnShiftTypes_Click(sender, e); // Refresh
                }
            }
            else if (currentTable == "Regular Shifts")
            {
                int id = Convert.ToInt32(row.Cells["RegularShiftID"].Value);
                new EditRegularShiftForm(id).ShowDialog();
                LoadData("SELECT * FROM RegularShifts");
            }
            else if (currentTable == "Special Shifts")
            {
                int id = Convert.ToInt32(row.Cells["SPECIALSHIFT_ID"].Value);
                new EditSpecialShiftForm(id).ShowDialog();
                LoadData("SELECT * FROM SupervisorSpecialShiftDetails");
            }
            else if (currentTable == "Rosters")
            {
                int id = Convert.ToInt32(row.Cells["ROSTER_ID"].Value);
                new EditRosterForm(id).ShowDialog();
                LoadData("SELECT * FROM RostersDetails");
            }
            else if (currentTable == "Roster Assignments")
            {
                MessageBox.Show("To change an assignment, please delete it and add a new one.");
            }
            else if (currentTable == "Attendances")
            {
                int id = Convert.ToInt32(row.Cells["ATTENDANCE_ID"].Value);
                new EditAttendanceForm(id).ShowDialog();
                LoadData("SELECT * FROM SupervisorCaptureAttendanceE");
            }
            else if (currentTable == "Leave Applications")
            {
                int id = Convert.ToInt32(row.Cells["LEAVE_ID"].Value);
                new EditLeaveApplicationForm(id).ShowDialog();
                LoadData("SELECT * FROM ManagerLeaveApplicationDetails");
            }
            else if (currentTable == "My Profile")
            {
                new EditProfileForm().ShowDialog();
                btnProfile_Click(sender, e);
            }
            else
            {
                MessageBox.Show("Editing is not supported for this list.");
            }
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            if (currentTable == "Guards") btnGuards_Click(sender, e);
            else if (currentTable == "Sites") btnSites_Click(sender, e);
            else if (currentTable == "Posts") btnPosts_Click(sender, e);
            else if (currentTable == "Type of Shifts") btnShiftTypes_Click(sender, e);
            else if (currentTable == "Regular Shifts") btnRegularShifts_Click(sender, e);
            else if (currentTable == "Special Shifts") btnSpecialShifts_Click(sender, e);
            else if (currentTable == "Rosters") btnRosters_Click(sender, e);
            else if (currentTable == "Attendances") btnAttendances_Click(sender, e);
            else if (currentTable == "Type of Leaves") btnTypeOfLeaves_Click(sender, e);
            else if (currentTable == "Leave Applications") btnLeaveApp_Click(sender, e);
            else if (currentTable == "My Profile") btnProfile_Click(sender, e);
        }

        private void btnBack_Click(object sender, EventArgs e)
        {
            /*   Supervisor S = new Supervisor();
               S.Show();
               this.Hide();*/

            Session.AccountID = 0;
            Session.PersonID = 0;
            Session.Username = null;
            Session.Role = null;

            LoginForm frm = new LoginForm();
            frm.Show();
            this.Hide();
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            if (dataGridView1.SelectedRows.Count == 0 ||
                dataGridView1.SelectedRows[0].IsNewRow)
            {
                MessageBox.Show("Please select a row first.");
                return;
            }

            DataGridViewRow row = dataGridView1.SelectedRows[0];

            if (MessageBox.Show("Delete the selected record?", "Confirm",
                MessageBoxButtons.YesNo, MessageBoxIcon.Warning) != DialogResult.Yes)
                return;

            try
            {
                using (SqlConnection delCon = new SqlConnection(
                    "Data Source=DESKTOP-133OPA4\\SQLEXPRESS;Initial Catalog=SecureRoster;" +
                    "Integrated Security=True;Encrypt=False;"))
                {
                    delCon.Open();

                    if (currentTable == "Posts")
                    {
                        int id = Convert.ToInt32(row.Cells["POST_ID"].Value);
                        new SqlCommand($"DELETE FROM Posts WHERE PostID = {id}", delCon).ExecuteNonQuery();
                    }
                    else if (currentTable == "Type of Shifts")
                    {
                        // FIX: Get the name from the grid, then look up the ID to delete
                        string shiftName = row.Cells["TYPEOFSHIFT"].Value.ToString();

                        SqlCommand getIDCmd = new SqlCommand("SELECT TypeShiftID FROM TypeOfShifts WHERE TypeOfShift = @name", delCon);
                        getIDCmd.Parameters.AddWithValue("@name", shiftName);
                        object result = getIDCmd.ExecuteScalar();

                        if (result != null)
                        {
                            int id = Convert.ToInt32(result);
                            new SqlCommand($"DELETE FROM TypeOfShifts WHERE TypeShiftID = {id}", delCon).ExecuteNonQuery();
                        }
                    }
                    else if (currentTable == "Regular Shifts")
                    {
                        int id = Convert.ToInt32(row.Cells["RegularShiftID"].Value);
                        new SqlCommand($"DELETE FROM RegularShifts WHERE RegularShiftID = {id}", delCon).ExecuteNonQuery();
                    }
                    else if (currentTable == "Special Shifts")
                    {
                        int id = Convert.ToInt32(row.Cells["SPECIALSHIFT_ID"].Value);
                        new SqlCommand($"DELETE FROM SpecialShifts WHERE SpecialShiftID = {id}", delCon).ExecuteNonQuery();
                    }
                    else if (currentTable == "Rosters")
                    {
                        int id = Convert.ToInt32(row.Cells["ROSTER_ID"].Value);
                        new SqlCommand($"DELETE FROM Rosters WHERE RosterID = {id}", delCon).ExecuteNonQuery();
                    }
                    else if (currentTable == "Roster Assignments")
                    {
                        int id = Convert.ToInt32(row.Cells["ASSIGNMENT_ID"].Value);
                        new SqlCommand($"DELETE FROM RegularShiftsAssignments WHERE AssignmentID = {id}", delCon).ExecuteNonQuery();
                    }
                    else if (currentTable == "Attendances")
                    {
                        int id = Convert.ToInt32(row.Cells["ATTENDANCE_ID"].Value);
                        new SqlCommand($"DELETE FROM Attendances WHERE AttendanceID = {id}", delCon).ExecuteNonQuery();
                    }
                    else if (currentTable == "Leave Applications")
                    {
                        int id = Convert.ToInt32(row.Cells["LEAVE_ID"].Value);
                        new SqlCommand($"DELETE FROM Leaves WHERE LeaveID = {id}", delCon).ExecuteNonQuery();
                    }
                    else
                    {
                        MessageBox.Show("Deleting is not supported for this list.");
                        return;
                    }
                }

                MessageBox.Show("Deleted successfully.");

                // Reload the current view to reflect the deletion
                btnSave_Click(sender, e);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Could not delete. There may be other data linked to this record.\n\n" + ex.Message);
            }
        }

    }


}
/**/