﻿namespace Security
{
    partial class GuardJB1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(GuardJB1));
            btnEdit = new Button();
            btnAdd = new Button();
            dataGridView1 = new DataGridView();
            panel2 = new Panel();
            Attendances = new Button();
            btnProfile = new Button();
            btnLeaves = new Button();
            btnSpecial = new Button();
            btnRegularShifts = new Button();
            panel1 = new Panel();
            pictureBox1 = new PictureBox();
            label1 = new Label();
            btnLogout = new Button();
            btnSave = new Button();
            lblRole = new Label();
            lblUsername = new Label();
            btnDelete = new Button();
            ((System.ComponentModel.ISupportInitialize)dataGridView1).BeginInit();
            panel2.SuspendLayout();
            panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            SuspendLayout();
            // 
            // btnEdit
            // 
            btnEdit.BackColor = SystemColors.ActiveCaption;
            btnEdit.FlatStyle = FlatStyle.Flat;
            btnEdit.Location = new Point(578, 127);
            btnEdit.Name = "btnEdit";
            btnEdit.Size = new Size(189, 33);
            btnEdit.TabIndex = 29;
            btnEdit.Text = "Edit";
            btnEdit.UseVisualStyleBackColor = false;
            btnEdit.Click += btnEdit_Click;
            // 
            // btnAdd
            // 
            btnAdd.BackColor = SystemColors.ActiveCaption;
            btnAdd.FlatStyle = FlatStyle.Flat;
            btnAdd.Location = new Point(199, 127);
            btnAdd.Name = "btnAdd";
            btnAdd.Size = new Size(189, 33);
            btnAdd.TabIndex = 28;
            btnAdd.Text = "Add";
            btnAdd.UseVisualStyleBackColor = false;
            btnAdd.Click += btnAdd_Click;
            // 
            // dataGridView1
            // 
            dataGridView1.BackgroundColor = Color.FromArgb(31, 45, 61);
            dataGridView1.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridView1.Location = new Point(199, 166);
            dataGridView1.Name = "dataGridView1";
            dataGridView1.Size = new Size(875, 293);
            dataGridView1.TabIndex = 27;
            // 
            // panel2
            // 
            panel2.Controls.Add(Attendances);
            panel2.Controls.Add(btnProfile);
            panel2.Controls.Add(btnLeaves);
            panel2.Controls.Add(btnSpecial);
            panel2.Controls.Add(btnRegularShifts);
            panel2.Location = new Point(1, 176);
            panel2.Name = "panel2";
            panel2.Size = new Size(192, 197);
            panel2.TabIndex = 26;
            panel2.Paint += panel2_Paint;
            // 
            // Attendances
            // 
            Attendances.BackColor = Color.White;
            Attendances.FlatAppearance.BorderSize = 0;
            Attendances.FlatStyle = FlatStyle.Flat;
            Attendances.Location = new Point(0, 77);
            Attendances.Name = "Attendances";
            Attendances.Size = new Size(189, 33);
            Attendances.TabIndex = 9;
            Attendances.Text = "Attendances   >";
            Attendances.TextAlign = ContentAlignment.MiddleLeft;
            Attendances.UseVisualStyleBackColor = false;
            Attendances.Click += Attendances_Click;
            // 
            // btnProfile
            // 
            btnProfile.BackColor = Color.White;
            btnProfile.FlatStyle = FlatStyle.Flat;
            btnProfile.Location = new Point(0, 155);
            btnProfile.Name = "btnProfile";
            btnProfile.Size = new Size(189, 33);
            btnProfile.TabIndex = 7;
            btnProfile.Text = "My profile   >";
            btnProfile.TextAlign = ContentAlignment.MiddleLeft;
            btnProfile.UseVisualStyleBackColor = false;
            btnProfile.Click += btnProfile_Click;
            // 
            // btnLeaves
            // 
            btnLeaves.BackColor = Color.White;
            btnLeaves.FlatStyle = FlatStyle.Flat;
            btnLeaves.Location = new Point(0, 116);
            btnLeaves.Name = "btnLeaves";
            btnLeaves.Size = new Size(189, 33);
            btnLeaves.TabIndex = 5;
            btnLeaves.Text = "Leaves   >";
            btnLeaves.TextAlign = ContentAlignment.MiddleLeft;
            btnLeaves.UseVisualStyleBackColor = false;
            btnLeaves.Click += btnLeaves_Click;
            // 
            // btnSpecial
            // 
            btnSpecial.BackColor = Color.White;
            btnSpecial.FlatStyle = FlatStyle.Flat;
            btnSpecial.Location = new Point(0, 38);
            btnSpecial.Name = "btnSpecial";
            btnSpecial.Size = new Size(189, 33);
            btnSpecial.TabIndex = 10;
            btnSpecial.Text = "Special Shifts   >";
            btnSpecial.TextAlign = ContentAlignment.MiddleLeft;
            btnSpecial.UseVisualStyleBackColor = false;
            btnSpecial.Click += btnSpecial_Click;
            // 
            // btnRegularShifts
            // 
            btnRegularShifts.BackColor = Color.White;
            btnRegularShifts.FlatStyle = FlatStyle.Flat;
            btnRegularShifts.Location = new Point(0, 3);
            btnRegularShifts.Name = "btnRegularShifts";
            btnRegularShifts.Size = new Size(189, 33);
            btnRegularShifts.TabIndex = 9;
            btnRegularShifts.Text = "Regular Shifts   >";
            btnRegularShifts.TextAlign = ContentAlignment.MiddleLeft;
            btnRegularShifts.UseVisualStyleBackColor = false;
            btnRegularShifts.Click += btnRegularShifts_Click;
            // 
            // panel1
            // 
            panel1.Controls.Add(pictureBox1);
            panel1.Location = new Point(1, 1);
            panel1.Name = "panel1";
            panel1.Size = new Size(704, 117);
            panel1.TabIndex = 25;
            // 
            // pictureBox1
            // 
            pictureBox1.Dock = DockStyle.Fill;
            pictureBox1.Image = (Image)resources.GetObject("pictureBox1.Image");
            pictureBox1.Location = new Point(0, 0);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(704, 117);
            pictureBox1.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox1.TabIndex = 3;
            pictureBox1.TabStop = false;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(314, 34);
            label1.Name = "label1";
            label1.Size = new Size(38, 15);
            label1.TabIndex = 24;
            label1.Text = "label1";
            // 
            // btnLogout
            // 
            btnLogout.Location = new Point(4, 124);
            btnLogout.Name = "btnLogout";
            btnLogout.Size = new Size(36, 33);
            btnLogout.TabIndex = 30;
            btnLogout.Text = "<";
            btnLogout.UseVisualStyleBackColor = true;
            btnLogout.Click += btnLogout_Click;
            // 
            // btnSave
            // 
            btnSave.BackColor = SystemColors.ActiveCaption;
            btnSave.FlatStyle = FlatStyle.Flat;
            btnSave.Location = new Point(885, 127);
            btnSave.Name = "btnSave";
            btnSave.Size = new Size(189, 33);
            btnSave.TabIndex = 31;
            btnSave.Text = "Save";
            btnSave.UseVisualStyleBackColor = false;
            // 
            // lblRole
            // 
            lblRole.AutoSize = true;
            lblRole.Font = new Font("Microsoft Sans Serif", 8F);
            lblRole.ForeColor = Color.LightGray;
            lblRole.Location = new Point(738, 20);
            lblRole.Name = "lblRole";
            lblRole.Size = new Size(29, 13);
            lblRole.TabIndex = 35;
            lblRole.Text = "Role";
            // 
            // lblUsername
            // 
            lblUsername.AutoSize = true;
            lblUsername.Font = new Font("Microsoft Sans Serif", 9.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            lblUsername.ForeColor = Color.White;
            lblUsername.Location = new Point(738, 1);
            lblUsername.Name = "lblUsername";
            lblUsername.Size = new Size(40, 16);
            lblUsername.TabIndex = 34;
            lblUsername.Text = "User";
            // 
            // btnDelete
            // 
            btnDelete.BackColor = SystemColors.ActiveCaption;
            btnDelete.FlatStyle = FlatStyle.Flat;
            btnDelete.Location = new Point(578, 465);
            btnDelete.Name = "btnDelete";
            btnDelete.Size = new Size(189, 33);
            btnDelete.TabIndex = 32;
            btnDelete.Text = "Delete";
            btnDelete.UseVisualStyleBackColor = false;
            btnDelete.Click += btnDelete_Click;
            // 
            // GuardJB1
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.FromArgb(31, 45, 61);
            ClientSize = new Size(1082, 732);
            Controls.Add(btnDelete);
            Controls.Add(lblRole);
            Controls.Add(lblUsername);
            Controls.Add(btnSave);
            Controls.Add(btnLogout);
            Controls.Add(btnEdit);
            Controls.Add(btnAdd);
            Controls.Add(dataGridView1);
            Controls.Add(panel2);
            Controls.Add(panel1);
            Controls.Add(label1);
            Name = "GuardJB1";
            Text = "GuardJB1";
            Load += GuardJB1_Load;
            ((System.ComponentModel.ISupportInitialize)dataGridView1).EndInit();
            panel2.ResumeLayout(false);
            panel1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Button btnEdit;
        private Button btnAdd;
        private DataGridView dataGridView1;
        private Panel panel2;
        private Button Attendances;
        private Button btnProfile;
        private Button btnLeaves;
        private Button btnSpecial;
        private Button btnRegularShifts;
        private Panel panel1;
        private Label label1;
        private Button btnLogout;
        private Button btnSave;
        private PictureBox pictureBox1;
        private Label lblRole;
        private Label lblUsername;
        private Button btnDelete;
    }
}