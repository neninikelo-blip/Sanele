﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using Microsoft.Data.SqlClient;
namespace Security
{
    public partial class AddSecurityCompanyForm : Form
    {
        SqlConnection con = new SqlConnection(
            "Data Source=DESKTOP-133OPA4\\SQLEXPRESS;" +
            "Initial Catalog=SecureRoster;" +
            "Integrated Security=True;" +
            "Encrypt=False;");
        public AddSecurityCompanyForm()
        {
            InitializeComponent();
        }

        private void AddSecurityCompanyForm_Load(object sender, EventArgs e)
        {
            // 1. Load Suburbs
            SqlDataAdapter daSuburb = new SqlDataAdapter(
                "SELECT SuburbID, SuburbName FROM Suburbs", con);

            DataTable dtSuburb = new DataTable();
            daSuburb.Fill(dtSuburb);

            comboBoxSuburb.DataSource = dtSuburb;
            comboBoxSuburb.DisplayMember = "SuburbName";
            comboBoxSuburb.ValueMember = "SuburbID";

            // 2. Load Companies (Optional: If you want them to pick an existing company)
            SqlDataAdapter daComp = new SqlDataAdapter(
                "SELECT CompanyID, CompanyName FROM Companies", con);

            DataTable dtComp = new DataTable();
            daComp.Fill(dtComp);

            comboBoxCompany.DataSource = dtComp;
            comboBoxCompany.DisplayMember = "CompanyName";
            comboBoxCompany.ValueMember = "CompanyID";

            // Set the combobox to start empty so they don't accidentally pick one
            comboBoxCompany.SelectedIndex = -1;
        
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            // VALIDATION (Guard Clauses)
            if (string.IsNullOrWhiteSpace(txtCompanyName.Text))
            {
                MessageBox.Show("Please enter a Company Name."); return;
            }
            if (comboBoxSuburb.SelectedValue == null)
            {
                MessageBox.Show("Please select a Suburb."); return;
            }

            try
            {
                con.Open();
                // Start a transaction because we are inserting into TWO tables
                SqlTransaction tx = con.BeginTransaction();

                try
                {
                    // 1. Generate new CompanyID
                    SqlCommand idCmd = new SqlCommand(
                        "SELECT ISNULL(MAX(CompanyID),0) + 1 FROM Companies", con, tx);
                    int newCompanyID = Convert.ToInt32(idCmd.ExecuteScalar());

                    // 2. Insert into Companies table
                    SqlCommand companyCmd = new SqlCommand(
                        @"INSERT INTO Companies (CompanyID, CompanyName, CompanyCell, CompanyEmail)
                          VALUES (@cid, @name, @cell, @email)", con, tx);

                    companyCmd.Parameters.AddWithValue("@cid", newCompanyID);
                    companyCmd.Parameters.AddWithValue("@name", txtCompanyName.Text);
                    companyCmd.Parameters.AddWithValue("@cell", txtCompanyCell.Text);
                    companyCmd.Parameters.AddWithValue("@email", txtCompanyEmail.Text);
                    companyCmd.ExecuteNonQuery();

                    // 3. Generate new SecurityCompID
                    SqlCommand secIdCmd = new SqlCommand(
                        "SELECT ISNULL(MAX(SecurityCompID),0) + 1 FROM SecurityCompanies", con, tx);
                    int newSecCompID = Convert.ToInt32(secIdCmd.ExecuteScalar());

                    // 4. Insert into SecurityCompanies table
                    SqlCommand secCmd = new SqlCommand(
                        @"INSERT INTO SecurityCompanies (SecurityCompID, CompanyID, SuburbID)
                          VALUES (@secid, @cid, @suburbid)", con, tx);

                    secCmd.Parameters.AddWithValue("@secid", newSecCompID);
                    secCmd.Parameters.AddWithValue("@cid", newCompanyID);
                    secCmd.Parameters.AddWithValue("@suburbid", comboBoxSuburb.SelectedValue);
                    secCmd.ExecuteNonQuery();

                    // 5. Commit Transaction
                    tx.Commit();

                    MessageBox.Show("Security Company Added Successfully");
                    this.Close();
                }
                catch (Exception ex)
                {
                    tx.Rollback();
                    MessageBox.Show("Database Error: " + ex.Message);
                }
                finally
                {
                    con.Close();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Connection Error: " + ex.Message);
            }
        
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void cmbCompany_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (comboBoxCompany.SelectedValue is not int) return;

            try
            {
                if (con.State != ConnectionState.Open) con.Open();
                SqlCommand cmd = new SqlCommand(
                    "SELECT CompanyName, CompanyCell, CompanyEmail FROM Companies WHERE CompanyID = @id", con);
                cmd.Parameters.AddWithValue("@id", comboBoxCompany.SelectedValue);

                SqlDataReader dr = cmd.ExecuteReader();
                if (dr.Read())
                {
                    txtCompanyName.Text = dr["CompanyName"].ToString();
                    txtCompanyCell.Text = dr["CompanyCell"].ToString();
                    txtCompanyEmail.Text = dr["CompanyEmail"].ToString();
                }
                dr.Close();
            }
            catch (Exception ex) { MessageBox.Show(ex.Message); }
            finally { con.Close(); }
        }
    
    }
}
/*
     

       

        // BONUS: Auto-fill the textboxes if they select an existing company from the dropdown
      
    }
}*/