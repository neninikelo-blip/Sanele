﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using Microsoft.Data.SqlClient;

namespace Security
{
    public partial class Supervisor : Form
    {
        public Supervisor()
        {
            InitializeComponent();
        }
        SqlConnection con = new SqlConnection("Data Source=DESKTOP-133OPA4\\SQLEXPRESS;" + "Initial Catalog=SecureRoster;" + "Integrated Security=True;" + "Encrypt=False;");


        private void button1_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Form3 F3 = new Form3();
            F3.Show();
            this.Hide();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            SupervisorJB SJB = new SupervisorJB();
            SJB.Show();
            this.Hide();
        }

        private void Supervisor_Load(object sender, EventArgs e)
        {

        }
    }
}
