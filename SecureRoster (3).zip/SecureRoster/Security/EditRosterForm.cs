﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using Microsoft.Data.SqlClient;
namespace Security
{
    public partial class EditRosterForm : Form
    {
        SqlConnection con = new SqlConnection(
            "Data Source=DESKTOP-133OPA4\\SQLEXPRESS;" +
            "Initial Catalog=SecureRoster;" +
            "Integrated Security=True;" +
            "Encrypt=False;");

        private int rosterID;
        public EditRosterForm(int id)
        {
            InitializeComponent();
            rosterID = id;
        }

        private void EditRosterForm_Load(object sender, EventArgs e)
        { 
            // 1. Load Sites
            DataTable dtSite = new DataTable();
            new SqlDataAdapter("SELECT SiteID, NameOfSite FROM Sites", con).Fill(dtSite);
            cmbSite.DataSource = dtSite;
            cmbSite.DisplayMember = "NameOfSite";
            cmbSite.ValueMember = "SiteID";

            // 2. Load Status
            cmbStatus.Items.Clear();
            cmbStatus.Items.AddRange(new object[] { "Draft", "WORKING ON IT!", "Completed", "Cancelled" });
            cmbStatus.DropDownStyle = ComboBoxStyle.DropDownList;

            // 3. Load Supervisors
            DataTable dtSup = new DataTable();
            new SqlDataAdapter(
                @"SELECT sp.SupervisorID, p.FirstName + ' ' + p.LastName AS FullName
                  FROM Supervisors sp
                  INNER JOIN Persons p ON sp.PersonID = p.PersonID", con)
                .Fill(dtSup);
            cmbSupervisor.DataSource = dtSup;
            cmbSupervisor.DisplayMember = "FullName";
            cmbSupervisor.ValueMember = "SupervisorID";

            // 4. Load the existing roster data to populate the form
            try
            {
                con.Open();
                SqlCommand cmd = new SqlCommand(
                    @"SELECT StartDate, EndDate, RosterName, SiteID, SupervisorID, RosterStatus 
                      FROM Rosters WHERE RosterID = @id", con);
                cmd.Parameters.AddWithValue("@id", rosterID);

                SqlDataReader dr = cmd.ExecuteReader();
                if (dr.Read())
                {
                    dtpStartDate.Value = Convert.ToDateTime(dr["StartDate"]);
                    dtpEndDate.Value = Convert.ToDateTime(dr["EndDate"]);
                    txtRosterName.Text = dr["RosterName"].ToString();
                    cmbSite.SelectedValue = Convert.ToInt32(dr["SiteID"]);
                    cmbSupervisor.SelectedValue = Convert.ToInt32(dr["SupervisorID"]);
                    cmbStatus.Text = dr["RosterStatus"].ToString();
                }
                dr.Close();
                con.Close();
            }
            catch (Exception ex) { MessageBox.Show(ex.Message); }
        }
 

        private void btnCancel_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnSave_Click(object sender, EventArgs e)
        { 
            if (cmbSite.SelectedValue == null || cmbSite.SelectedValue is DataRowView) { MessageBox.Show("Select a site."); return; }
            if (cmbSupervisor.SelectedValue == null || cmbSupervisor.SelectedValue is DataRowView) { MessageBox.Show("Select a supervisor."); return; }

            // Date Validation
            if (dtpEndDate.Value.Date < dtpStartDate.Value.Date)
            {
                MessageBox.Show("The End Date cannot be before the Start Date.");
                return;
            }

            try
            {
                con.Open();
                SqlCommand cmd = new SqlCommand(
                    @"UPDATE Rosters
                      SET StartDate   = @start,
                          EndDate     = @end,
                          RosterName  = @name,
                          SiteID      = @site,
                          SupervisorID= @sup,
                          RosterStatus= @status
                      WHERE RosterID = @id", con);

                cmd.Parameters.AddWithValue("@start", dtpStartDate.Value.Date);
                cmd.Parameters.AddWithValue("@end", dtpEndDate.Value.Date);
                cmd.Parameters.AddWithValue("@name", txtRosterName.Text);
                cmd.Parameters.AddWithValue("@site", cmbSite.SelectedValue);
                cmd.Parameters.AddWithValue("@sup", cmbSupervisor.SelectedValue);
                cmd.Parameters.AddWithValue("@status", cmbStatus.Text);
                cmd.Parameters.AddWithValue("@id", rosterID);

                cmd.ExecuteNonQuery();

                MessageBox.Show("Roster Updated");
                con.Close();
                this.Close();
            }
            catch (Exception ex) { MessageBox.Show(ex.Message); }
        }
    

    
}
}
/**/