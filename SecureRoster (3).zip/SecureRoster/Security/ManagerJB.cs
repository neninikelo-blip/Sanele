﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using Microsoft.Data.SqlClient;

namespace Security
{
    public partial class ManagerJB : Form
    {
        private string currentQuery = "";
        public ManagerJB()
        {
            InitializeComponent();
        }
       
        SqlConnection con = new SqlConnection("Data Source=DESKTOP-133OPA4\\SQLEXPRESS;" + "Initial Catalog=SecureRoster;" + "Integrated Security=True;" + "Encrypt=False;");
        private string currentTable = "";
        private SqlDataAdapter da = new SqlDataAdapter();
        private DataTable dt = new DataTable();

        private void LoadData(string query, SqlParameter[] parameters = null)
        {
            currentQuery = query;
            try
            {
                da = new SqlDataAdapter(query, con);
                if (parameters != null) da.SelectCommand.Parameters.AddRange(parameters);

                dt = new DataTable();
                da.Fill(dt);
                dataGridView1.DataSource = dt;
                this.Text = "Manager Portal - " + (currentTable == "" ? "Dashboard" : currentTable);

                // AUTO-HIDE ID COLUMNS (Fixes your visual issue without breaking code)
                foreach (DataGridViewColumn col in dataGridView1.Columns)
                {
                    if (col.Name.EndsWith("_ID") || col.Name == "ID" || col.Name == "IDNUMBER")
                    {
                        col.Visible = false;
                    }
                }
            }
            catch (Exception ex) { MessageBox.Show(ex.Message); }
        }

        private void ManagerJB_Load(object sender, EventArgs e)
        { 
            lblUsername.Text = Session.Username.ToUpper() + " ▼";
            lblRole.Text = Session.Role.ToUpper();

            dataGridView1.ReadOnly = true;
            dataGridView1.AllowUserToAddRows = false;
            dataGridView1.AllowUserToDeleteRows = false;
            dataGridView1.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            dataGridView1.MultiSelect = false;
        }
        private void button1_Click(object sender, EventArgs e)
        {/*
            SupervisorJB sjb = new SupervisorJB();
            sjb.Show();
            this.Hide();
      */
        }

        private void panel2_Paint(object sender, PaintEventArgs e)
        {

        }

        private void button16_Click(object sender, EventArgs e)
        {
            currentTable = "Security Companies";
            LoadData(@"SELECT COMPANYNAME, COMPANYCELL, COMPANYEMAIL, SUBURBNAME, TOWNNAME, CITYNAME, MUNICIPALITYNAME, PROVINCENAME 
                       FROM SecurityCompaniesView");
        }

        private void button9_Click_1(object sender, EventArgs e)
        {
            currentTable = "Client Companies";
            LoadData(@"SELECT CLIENTCOMP_ID, COMPANYNAME, COMPANYCELL, COMPANYEMAIL 
                       FROM ManagerClientCompanyDetails");
        }

        private void button2_Click_1(object sender, EventArgs e)
        { 
            currentTable = "Guards";
            LoadData(@"SELECT GUARD_ID, FIRSTNAME, LASTNAME, IDNUMBER, GENDER, CELLNUMBER, NAMEOFSITE, COMPANYNAME 
                       FROM GuardsView WHERE SECURITYCOMP_ID = @cid",
                     new[] { new SqlParameter("@cid", Session.CompanyID) });
        }
        private void button10_Click_1(object sender, EventArgs e)
        {
            currentTable = "Supervisors";
            LoadData(@"SELECT SupervisorID, Username, FirstName, LastName, CellNumber, Email, Gender, ID_Number, NameOfSite, CompanyName 
                       FROM SupervisorView WHERE SECURITYCOMP_ID = @cid",
                     new[] { new SqlParameter("@cid", Session.CompanyID) });
        }

        private void button3_Click_1(object sender, EventArgs e)
        {
            currentTable = "Sites";
            LoadData(@"SELECT SITE_ID, NAMEOFSITE, SITECAPACITY, COMPANYNAME, SECURITY_COMPANY_NAME, SUBURBNAME, TOWNNAME, CITYNAME, MUNICIPALITYNAME 
                       FROM SitesView WHERE SECURITYCOMP_ID = @cid",
                     new[] { new SqlParameter("@cid", Session.CompanyID) });
        }

        private void button4_Click_1(object sender, EventArgs e)
        {
            currentTable = "Posts";
            LoadData(@"SELECT POSTID, POSTNAME, NUMBERPERPOST, POSTSTATUS, NAMEOFSITE, SECURITYCOMPANYNAME 
                       FROM PostsView WHERE SECURITYCOMP_ID = @cid",
                     new[] { new SqlParameter("@cid", Session.CompanyID) });
        }

        private void button5_Click_1(object sender, EventArgs e)
        {
            currentTable = "Type of Shifts";
            LoadData(@"SELECT TYPESHIFT_ID, SITE_ID, SECURITYCOMP_ID, COMPANY_ID, TYPEOFSHIFT, STARTTIME, ENDTIME, NAMEOFSITE, COMPANYNAME
                       FROM ManagerTypeOfShiftDetails
                       WHERE SECURITYCOMP_ID = @cid ORDER BY NAMEOFSITE",
                     new[] { new SqlParameter("@cid", Session.CompanyID) });
        }

        private void button6_Click_1(object sender, EventArgs e)
        { 
            currentTable = "Regular Shifts";
            LoadData(@"SELECT REGULARSHIFT_ID, TYPESHIFT_ID, POST_ID, SITE_ID, SECURITYCOMP_ID, COMPANY_ID, NAMEOFSHIFT, TYPEOFSHIFT, STARTTIME, ENDTIME, POSTNAME, NAMEOFSITE, COMPANYNAME, NUMBERPERPOST
                       FROM ManagerRegularShiftDetails
                       WHERE SECURITYCOMP_ID = @cid ORDER BY NAMEOFSITE",
                     new[] { new SqlParameter("@cid", Session.CompanyID) });
        }
        private void button7_Click_1(object sender, EventArgs e)
        {
            currentTable = "Special Shifts";
            LoadData(@"SELECT SPECIALSHIFT_ID, POST_ID, SITE_ID, SECURITYCOMP_ID, COMPANY_ID, SPECIALSHIFTDATE, NAMEOFSHIFT, STARTTIME, ENDTIME, POSTNAME, NUMBERPERPOST, NAMEOFSITE, COMPANYNAME
                       FROM ManagerSpecialShiftDetails
                       WHERE SECURITYCOMP_ID = @cid ORDER BY NAMEOFSITE",
                     new[] { new SqlParameter("@cid", Session.CompanyID) });
        }
        private void button8_Click_1(object sender, EventArgs e)
        {
            currentTable = "Rosters";
            LoadData(@"SELECT FIRSTNAME, LASTNAME, TYPEOFSHIFT, POSTNAME, SHIFTDATE, DAYNAME, STARTTIME, ENDTIME, ROSTERNAME, NAMEOFSITE 
                       FROM ManagerRegularShiftRoster WHERE SECURITYCOMP_ID = @cid",
                     new[] { new SqlParameter("@cid", Session.CompanyID) });
        }


        private void button15_Click_1(object sender, EventArgs e)
        {
            currentTable = "Attendances";
            LoadData(@"SELECT SHIFTDATE, FIRSTNAME, LASTNAME, NAMEOFSHIFT, POSTNAME, STARTTIME, CHECKINTIME, ENDTIME, CHECKOUTTIME, ATTENDANCESTATUS, SITE_ID, NAMEOFSITE, SECURITYCOMP_ID, TYPEOFSHIFT, ASSIGNMENT_ID, ROSTERDAY_ID
                       FROM ManagerAttendanceDetails
                       WHERE SECURITYCOMP_ID = @cid ORDER BY SITE_ID, SHIFTDATE ASC",
                     new[] { new SqlParameter("@cid", Session.CompanyID) });
        }
        private void button11_Click_1(object sender, EventArgs e)
        {
            currentTable = "Type of Leaves";
            LoadData(@"SELECT TYPEOFLEAVE_ID, TYPEOFLEAVE, MAXDAYS, SECURITYCOMP_ID, COMPANY_ID, COMPANYNAME
                       FROM ManagerTypeOfLeaveDetails
                       WHERE SECURITYCOMP_ID = @cid",
                     new[] { new SqlParameter("@cid", Session.CompanyID) });
        }

        private void button12_Click_1(object sender, EventArgs e)
        {//LEAVE_ID, TYPEOFLEAVE, USERNAME, FIRSTNAME, LASTNAME, STARTDATE, ENDDATE, LEAVEREASON, MAXDAYS, CELLNUMBER, LEAVESTATUS 

            currentTable = "Leave Applications";
            LoadData(@"SELECT *  FROM ManagerLeaveApplicationDetails d
                       INNER JOIN Persons p ON d.USERNAME = p.Username
                       INNER JOIN Guards g ON p.PersonID = g.PersonID
                       INNER JOIN Sites s ON g.SiteID = s.SiteID
                       WHERE s.SecurityCompID = @cid",
                     new[] { new SqlParameter("@cid", Session.CompanyID) });
        }

        private void button13_Click_1(object sender, EventArgs e)
        {
            currentTable = "My Profile";
            LoadData(@"SELECT FirstName, LastName, Email, Gender, Username, CellNumber, ID_Number, SuburbName, TownName, CityName, CompanyName, CompanyCell, CompanyEmail 
                       FROM ManagersDetailsView WHERE Username = @user",
                     new[] { new SqlParameter("@user", Session.Username) });
        }

        private void button14_Click(object sender, EventArgs e)
        {/*
            SupervisorJB sjb = new SupervisorJB();
            sjb.Show();
            this.Hide();
      */
        }




        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }





        private void button14_Click_1(object sender, EventArgs e)
        {

        }

        private void btnAdd_Click_1(object sender, EventArgs e)
        {
            if (currentTable == "Guards") { new AddGuardForm().ShowDialog(); button2_Click_1(sender, e); }
            else if (currentTable == "Sites") { new AddSiteForm().ShowDialog(); button3_Click_1(sender, e); }
            else if (currentTable == "Posts") { new AddPostForm().ShowDialog(); button4_Click_1(sender, e); }
            else if (currentTable == "Client Companies") { new AddClientCompanyForm().ShowDialog(); button9_Click_1(sender, e); }
            else if (currentTable == "Supervisors") { new AddSupervisorForm().ShowDialog(); button10_Click_1(sender, e); }
            else if (currentTable == "Type of Leaves") { new AddTypeOfLeaveForm().ShowDialog(); button11_Click_1(sender, e); }
            else { MessageBox.Show("This role does not have permission to add new records to the '" + currentTable + "' tab."); }
        }
        private void btnEdit_Click(object sender, EventArgs e)
        {
            if (dataGridView1.SelectedRows.Count == 0) { MessageBox.Show("Please select a row first."); return; }
            DataGridViewRow row = dataGridView1.SelectedRows[0];

            if (currentTable == "Guards")
            {
                int guardID = Convert.ToInt32(row.Cells["GUARD_ID"].Value);
                new EditGuardForm(guardID).ShowDialog();
                button2_Click_1(sender, e);
            }
            else if (currentTable == "Sites")
            {
                int siteID = Convert.ToInt32(row.Cells["SITE_ID"].Value);
                new EditSiteForm(siteID).ShowDialog();
                button3_Click_1(sender, e);
            }
            else if (currentTable == "Posts")
            {
                int postID = Convert.ToInt32(row.Cells["POSTID"].Value);
                new EditPostForm(postID).ShowDialog();
                button4_Click_1(sender, e);
            }
            else if (currentTable == "Security Companies")
            {
                int securityCompID = Convert.ToInt32(row.Cells["SECURITYCOMP_ID"].Value);
                new EditSecurityCompanyForm(securityCompID).ShowDialog();
                button16_Click(sender, e);
            }
            else if (currentTable == "Client Companies")
            {
                int clientCompID = Convert.ToInt32(row.Cells["CLIENTCOMP_ID"].Value);
                new EditClientCompanyForm(clientCompID).ShowDialog();
                button9_Click_1(sender, e);
            }
            else if (currentTable == "Supervisors")
            {
                int supervisorID = Convert.ToInt32(row.Cells["SupervisorID"].Value);
                new EditSupervisorForm(supervisorID).ShowDialog();
                button10_Click_1(sender, e);
            }
            else if (currentTable == "Type of Leaves")
            {
                int leaveTypeID = Convert.ToInt32(row.Cells["TYPEOFLEAVE_ID"].Value);
                new EditTypeOfLeaveForm(leaveTypeID).ShowDialog();
                button11_Click_1(sender, e);
            }
            else if (currentTable == "Leave Applications")
            {
                int leaveID = Convert.ToInt32(row.Cells["LEAVE_ID"].Value);
                new EditLeaveApplicationForm(leaveID).ShowDialog();
                button12_Click_1(sender, e);
            }
            else if (currentTable == "My Profile")
            {
                new EditProfileForm().ShowDialog();
                button13_Click_1(sender, e);
            }
            else
            {
                MessageBox.Show("This role does not have permission to edit records in the '" + currentTable + "' tab.");
            }
        } 

        private void btnSave_Click(object sender, EventArgs e)
        {
            if (currentTable == "Guards") button2_Click_1(sender, e);
            else if (currentTable == "Sites") button3_Click_1(sender, e);
            else if (currentTable == "Posts") button4_Click_1(sender, e);
            else if (currentTable == "Supervisors") button10_Click_1(sender, e);
            else if (currentTable == "Leave Applications") button12_Click_1(sender, e);
            else if (currentTable == "My Profile") button13_Click_1(sender, e);
            else if (currentTable == "Security Companies") button16_Click(sender, e);
            else if (currentTable == "Client Companies") button9_Click_1(sender, e);
            else if (currentTable == "Type of Shifts") button5_Click_1(sender, e);
            else if (currentTable == "Regular Shifts") button6_Click_1(sender, e);
            else if (currentTable == "Special Shifts") button7_Click_1(sender, e);
            else if (currentTable == "Rosters") button8_Click_1(sender, e);
            else if (currentTable == "Attendances") button15_Click_1(sender, e);
            else if (currentTable == "Type of Leaves") button11_Click_1(sender, e);
        }

        private void btnBack_Click_1(object sender, EventArgs e)
        {
            Session.AccountID = 0; Session.PersonID = 0; Session.Username = null; Session.Role = null;
            new LoginForm().Show(); this.Hide();
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            if (dataGridView1.SelectedRows.Count == 0) return;
            if (MessageBox.Show("Delete selected?", "Confirm", MessageBoxButtons.YesNo) != DialogResult.Yes) return;

            DataGridViewRow row = dataGridView1.SelectedRows[0];

            try
            {
                using (SqlConnection c = new SqlConnection("Data Source=DESKTOP-133OPA4\\SQLEXPRESS;Initial Catalog=SecureRoster;Integrated Security=True;Encrypt=False;"))
                {
                    c.Open();
                    string sql = null;

                    if (currentTable == "Guards")
                    {
                        // Get the PersonID first, then delete the Person (which cascades to Guard and Accounts)
                        SqlCommand getPID = new SqlCommand($"SELECT PersonID FROM Guards WHERE GuardID = {row.Cells["GUARD_ID"].Value}", c);
                        int pid = Convert.ToInt32(getPID.ExecuteScalar());
                        sql = $"DELETE FROM Persons WHERE PersonID = {pid}";
                    }
                    else if (currentTable == "Sites") sql = $"DELETE FROM Sites WHERE SiteID = {row.Cells["SITE_ID"].Value}";
                    else if (currentTable == "Posts") sql = $"DELETE FROM Posts WHERE PostID = {row.Cells["POSTID"].Value}";
                    else if (currentTable == "Security Companies") sql = $"DELETE FROM SecurityCompanies WHERE SecurityCompID = {row.Cells["SECURITYCOMP_ID"].Value}";
                    else if (currentTable == "Client Companies") sql = $"DELETE FROM ClientCompanies WHERE ClientCompID = {row.Cells["CLIENTCOMP_ID"].Value}";
                    else if (currentTable == "Supervisors")
                    {
                        SqlCommand getPID = new SqlCommand($"SELECT PersonID FROM Supervisors WHERE SupervisorID = {row.Cells["SupervisorID"].Value}", c);
                        int pid = Convert.ToInt32(getPID.ExecuteScalar());
                        sql = $"DELETE FROM Persons WHERE PersonID = {pid}";
                    }
                    else if (currentTable == "Type of Leaves")
                    {
                        int id = Convert.ToInt32(row.Cells["TYPEOFLEAVE_ID"].Value);
                        SqlCommand checkCmd = new SqlCommand("SELECT COUNT(*) FROM Leaves WHERE LeaveTypeID = @id", c);
                        checkCmd.Parameters.AddWithValue("@id", id);
                        if (Convert.ToInt32(checkCmd.ExecuteScalar()) > 0)
                        {
                            MessageBox.Show("Cannot delete this leave type because it is already assigned to guard leave requests.");
                            return;
                        }
                        sql = $"DELETE FROM TypeOfLeaves WHERE TypeOfLeaveID = {id}";
                    }
                    else
                    {
                        MessageBox.Show("Deleting is not supported for this list.");
                        return;
                    }

                    new SqlCommand(sql, c).ExecuteNonQuery();
                }

                MessageBox.Show("Deleted completely from system.");
                btnSave_Click(sender, e);
            }
            catch (Exception ex) { MessageBox.Show(ex.Message); }
        }

        private void dataGridView1_CellContentClick_1(object sender, DataGridViewCellEventArgs e)
        {

        }
    }


}



