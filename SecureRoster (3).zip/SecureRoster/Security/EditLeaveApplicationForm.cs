﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using Microsoft.Data.SqlClient;
namespace Security
{
    public partial class EditLeaveApplicationForm : Form
    {
        SqlConnection con = new SqlConnection(
            "Data Source=DESKTOP-133OPA4\\SQLEXPRESS;" +
            "Initial Catalog=SecureRoster;" +
            "Integrated Security=True;" +
            "Encrypt=False;");

        private int leaveID;
        public EditLeaveApplicationForm(int id)
        {
            InitializeComponent();
            leaveID = id;
        }

        private void EditLeaveApplicationForm_Load(object sender, EventArgs e)
        {
            // 1. Lock textbox if Supervisor/Manager
            if (Session.Role == "Supervisor" || Session.Role == "Manager")
            {
                txtLeaveReason.ReadOnly = true;
                txtLeaveReason.BackColor = System.Drawing.Color.LightGray;
            }

            // 2. Load Type of Leaves
            DataTable dtType = new DataTable();
            new SqlDataAdapter("SELECT TypeOfLeaveID, TypeOfLeave FROM TypeOfLeaves", con).Fill(dtType);
            cmbLeaveType.DataSource = dtType;
            cmbLeaveType.DisplayMember = "TypeOfLeave";
            cmbLeaveType.ValueMember = "TypeOfLeaveID";

            // 3. Load Status
            cmbLeaveStatus.Items.Clear();
            cmbLeaveStatus.Items.AddRange(new object[] { "Pending", "Approved", "Rejected" });
            cmbLeaveStatus.DropDownStyle = ComboBoxStyle.DropDownList;

            // 4. Load the Data
            try
            {
                con.Open();
                SqlCommand cmd = new SqlCommand(
                    @"SELECT StartDate, EndDate, LeaveTypeID, LeaveReason, LeaveStatus
                      FROM Leaves WHERE LeaveID = @id", con);
                cmd.Parameters.AddWithValue("@id", leaveID);

                SqlDataReader dr = cmd.ExecuteReader();
                if (dr.Read())
                {
                    // Read the dates (Now they are actual DATE types in SQL)
                    if (dr["StartDate"] != DBNull.Value)
                        dtpStartDate.Value = Convert.ToDateTime(dr["StartDate"]);
                    else
                        dtpStartDate.Value = DateTime.Today;

                    if (dr["EndDate"] != DBNull.Value)
                        dtpEndDate.Value = Convert.ToDateTime(dr["EndDate"]);
                    else
                        dtpEndDate.Value = DateTime.Today;

                    txtLeaveReason.Text = dr["LeaveReason"].ToString();
                    cmbLeaveStatus.Text = dr["LeaveStatus"].ToString();
                    cmbLeaveType.SelectedValue = Convert.ToInt32(dr["LeaveTypeID"]);
                }
                dr.Close();
                con.Close();
            }
            catch (Exception ex) { MessageBox.Show(ex.Message); }
        }


        private void btnSave_Click(object sender, EventArgs e)
        {
            if (cmbLeaveType.SelectedValue == null || cmbLeaveType.SelectedValue is DataRowView)
            {
                MessageBox.Show("Please select a leave type.");
                return;
            }

            try
            {
                if (con.State != ConnectionState.Open) con.Open();

                SqlCommand cmd = new SqlCommand(
                    @"UPDATE Leaves
                      SET StartDate   = @start,
                          EndDate     = @end,
                          LeaveTypeID = @type,
                          LeaveReason = @reason,
                          LeaveStatus = @status
                      WHERE LeaveID = @id", con);

                // Save them directly as Dates (No more formatting strings)
                cmd.Parameters.AddWithValue("@start", dtpStartDate.Value.Date);
                cmd.Parameters.AddWithValue("@end", dtpEndDate.Value.Date);
                cmd.Parameters.AddWithValue("@type", cmbLeaveType.SelectedValue);
                cmd.Parameters.AddWithValue("@reason", txtLeaveReason.Text);
                cmd.Parameters.AddWithValue("@status", cmbLeaveStatus.Text);
                cmd.Parameters.AddWithValue("@id", leaveID);

                cmd.ExecuteNonQuery();

                MessageBox.Show("Leave Application Updated");
                this.Close();
            }
            catch (Exception ex) { MessageBox.Show(ex.Message); }
            finally
            {
                if (con.State == ConnectionState.Open) con.Close();
            }
        }


        private void btnCancel_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
/*using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using Microsoft.Data.SqlClient;

namespace Security
{
    public partial class EditLeaveApplicationForm : Form
    {
        SqlConnection con = new SqlConnection(
            "Data Source=DESKTOP-133OPA4\\SQLEXPRESS;" +
            "Initial Catalog=SecureRoster;" +
            "Integrated Security=True;" +
            "Encrypt=False;");

        private int leaveID;

        public EditLeaveApplicationForm(int id)
        {
            InitializeComponent();
            leaveID = id;
        }

       

        

        private void btnCancel_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}*/