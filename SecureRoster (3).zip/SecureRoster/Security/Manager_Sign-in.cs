﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace Security
{
    public partial class Manager : Form
    {
        public Manager()
        {
            InitializeComponent();
        }
        private void button1_Click(object sender, EventArgs e)
        {
            
            ManagerJB M = new ManagerJB();
            M.Show();
            this.Hide();
        }
        private void button2_Click(object sender, EventArgs e)
        {
           
            Form3 F3 = new Form3();
            F3.Show();
            this.Hide();
        }
        private void Manager_Load(object sender, EventArgs e)
        {
            

        }

    }
}