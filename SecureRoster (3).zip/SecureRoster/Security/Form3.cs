﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace Security
{
    public partial class Form3 : Form
    {
        public Form3()
        {
            InitializeComponent();
        }

        private void Guard_Click(object sender, EventArgs e)
        {
            Form2 f2 = new Form2();
            f2.Show();
            this.Hide();
        }

        private void Supervisor_Click(object sender, EventArgs e)
        {
            Supervisor S1 = new Supervisor();
            S1.Show();
            this.Hide();
        }

        private void Manager_Click(object sender, EventArgs e)
        {
            Manager M1 = new Manager();
            M1.Show();
            this.Hide();
        }

        private void ITAdmin_Click(object sender, EventArgs e)
        {
            ITAdmin IT1 = new ITAdmin();
            IT1.Show();
            this.Hide();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Form4 F4 = new Form4();
            F4.Show();
            this.Hide();
        }

        private void Form3_Load(object sender, EventArgs e)
        {

        }
    }
}
