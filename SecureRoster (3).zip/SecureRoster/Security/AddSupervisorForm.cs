﻿using Microsoft.Data.SqlClient;
using System;
using System.Data;
using System.Windows.Forms;
using System.Windows.Forms.VisualStyles;

namespace Security
{
    public partial class AddSupervisorForm : Form
    {
        SqlConnection con = new SqlConnection(
            "Data Source=DESKTOP-133OPA4\\SQLEXPRESS;" +
            "Initial Catalog=SecureRoster;" +
            "Integrated Security=True;" +
            "Encrypt=False;"+"Connect Timeout=60;");

        public AddSupervisorForm()
        {
            InitializeComponent();
        }

        private void AddSupervisorForm_Load(object sender, EventArgs e)
        {
            cmbGender.Items.Clear();
            cmbGender.Items.AddRange(new object[] { "M", "F", "Other" });
            cmbGender.DropDownStyle = ComboBoxStyle.DropDownList;
            // Sites dropdown
            SqlDataAdapter da = new SqlDataAdapter(
                "SELECT SiteID, NameOfSite FROM Sites", con);
            DataTable dt = new DataTable();
            da.Fill(dt);

            comboBoxSite.DataSource = dt;
            comboBoxSite.DisplayMember = "NameOfSite";
            comboBoxSite.ValueMember = "SiteID";

            // ← NEW: Suburbs dropdown (was used in your INSERT but never filled here)
            SqlDataAdapter daSub = new SqlDataAdapter(
                "SELECT SuburbID, SuburbName FROM Suburbs", con);
            DataTable dtSub = new DataTable();
            daSub.Fill(dtSub);

            comboBoxSuburb.DataSource = dtSub;
            comboBoxSuburb.DisplayMember = "SuburbName";
            comboBoxSuburb.ValueMember = "SuburbID";
        }





        private void btnSave_Click_1(object sender, EventArgs e)
        {
            // ← NEW: Guard clauses (same pattern as AddGuardForm)
            if (string.IsNullOrWhiteSpace(txtFirstName.Text)) { MessageBox.Show("First name required."); return; }
            if (string.IsNullOrWhiteSpace(txtLastName.Text)) { MessageBox.Show("Last name required."); return; }
            if (string.IsNullOrWhiteSpace(txtUsername.Text)) { MessageBox.Show("Username required."); return; }
            if (string.IsNullOrWhiteSpace(txtPassword.Text)) { MessageBox.Show("Password required."); return; }
            if (comboBoxSite.SelectedValue == null ||
                comboBoxSite.SelectedValue is DataRowView) { MessageBox.Show("Select a site."); return; }
            if (comboBoxSuburb.SelectedValue == null ||
                comboBoxSuburb.SelectedValue is DataRowView) { MessageBox.Show("Select a suburb."); return; }

            try
            {
                con.Open();
                SqlTransaction tx = con.BeginTransaction();   // ← NEW: transaction

                try
                {
                    // -----------------------------------------------
                    // 1) Insert Person
                    // -----------------------------------------------
                    SqlCommand pIdCmd = new SqlCommand(
                        "SELECT ISNULL(MAX(PersonID),0) + 1 FROM Persons", con, tx);
                    int personID = Convert.ToInt32(pIdCmd.ExecuteScalar());

                    SqlCommand personCmd = new SqlCommand(
                        @"INSERT INTO Persons
                            (PersonID, FirstName, LastName, Email, Gender,
                             Username, CellNumber, ID_Number, Suburb_ID)
                          VALUES
                            (@pid, @fname, @lname, @email, @gender,
                             @username, @cell, @idnum, @suburbid)", con, tx);

                    personCmd.Parameters.AddWithValue("@pid", personID);
                    personCmd.Parameters.AddWithValue("@fname", txtFirstName.Text);
                    personCmd.Parameters.AddWithValue("@lname", txtLastName.Text);
                    personCmd.Parameters.AddWithValue("@email", txtEmail.Text);
                    personCmd.Parameters.AddWithValue("@gender", cmbGender.Text);
                    personCmd.Parameters.AddWithValue("@username", txtUsername.Text);
                    personCmd.Parameters.AddWithValue("@cell", txtCell.Text);
                    personCmd.Parameters.AddWithValue("@idnum", txtIDNumber.Text);
                    personCmd.Parameters.AddWithValue("@suburbid", comboBoxSuburb.SelectedValue);

                    personCmd.ExecuteNonQuery();

                    // -----------------------------------------------
                    // 2) Insert Supervisor
                    // -----------------------------------------------
                    SqlCommand sIdCmd = new SqlCommand(
                        "SELECT ISNULL(MAX(SupervisorID),0) + 1 FROM Supervisors", con, tx);
                    int supervisorID = Convert.ToInt32(sIdCmd.ExecuteScalar());

                    SqlCommand supCmd = new SqlCommand(
                        @"INSERT INTO Supervisors
                            (SupervisorID, PersonID, SiteID)
                          VALUES
                            (@supid, @pid, @siteid)", con, tx);

                    supCmd.Parameters.AddWithValue("@supid", supervisorID);
                    supCmd.Parameters.AddWithValue("@pid", personID);
                    supCmd.Parameters.AddWithValue("@siteid", comboBoxSite.SelectedValue);

                    supCmd.ExecuteNonQuery();

                    // -----------------------------------------------
                    // 3) Insert Account (hashed password)
                    // -----------------------------------------------
                    var (salt, hash) = PasswordHasher.CreateHash(txtPassword.Text);

                    SqlCommand aidCmd = new SqlCommand(
                        "SELECT ISNULL(MAX(AccountID),0) + 1 FROM Accounts", con, tx);
                    int accountID = Convert.ToInt32(aidCmd.ExecuteScalar());

                    SqlCommand accCmd = new SqlCommand(
                        @"INSERT INTO Accounts
                            (AccountID, PersonID, Username, PasswordSalt, PasswordHash, Role_)
                          VALUES
                            (@aid, @pid, @user, @salt, @hash, @role)", con, tx);

                    accCmd.Parameters.AddWithValue("@aid", accountID);
                    accCmd.Parameters.AddWithValue("@pid", personID);
                    accCmd.Parameters.AddWithValue("@user", txtUsername.Text);
                    accCmd.Parameters.AddWithValue("@salt", salt);
                    accCmd.Parameters.AddWithValue("@hash", hash);
                    accCmd.Parameters.AddWithValue("@role", "Supervisor"); // ← role

                    accCmd.ExecuteNonQuery();

                    // -----------------------------------------------
                    // 4) Commit
                    // -----------------------------------------------
                    tx.Commit();

                    MessageBox.Show("Supervisor added. They can now log in.");
                    con.Close();
                    this.Close();
                }
                catch
                {
                    tx.Rollback();
                    throw;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }

        }

        private void btnCancel_Click_1(object sender, EventArgs e)
        {
            this.Close();
        }
    
    }
}