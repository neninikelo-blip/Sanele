﻿using System;
using System.Data;
using System.Windows.Forms;
using Microsoft.Data.SqlClient;

namespace Security
{
    public partial class EditLeaveForm : Form
    {
        SqlConnection con = new SqlConnection(
            "Data Source=DESKTOP-133OPA4\\SQLEXPRESS;" +
            "Initial Catalog=SecureRoster;" +
            "Integrated Security=True;" +
            "Encrypt=False;" +
            "Connect Timeout=60;");

        private int leaveID;

        public EditLeaveForm(int leaveID)
        {
            InitializeComponent();
            this.leaveID = leaveID;
        }

        private void EditLeaveForm_Load(object sender, EventArgs e)
        {
            // Only a Guard may open this form
            if (Session.Role != "Guard")
            {
                MessageBox.Show("Only guards can edit their leave requests.");
                this.Close();
                return;
            }

            // Populate leave types
            DataTable dtType = new DataTable();
            new SqlDataAdapter(
                "SELECT TypeOfLeaveID, TypeOfLeave FROM TypeOfLeaves", con)
                .Fill(dtType);
            cmbLeaveType.DataSource = dtType;
            cmbLeaveType.DisplayMember = "TypeOfLeave";
            cmbLeaveType.ValueMember = "TypeOfLeaveID";

            try
            {
                con.Open();

                // Load the leave, but ONLY if it belongs to this guard
                SqlCommand cmd = new SqlCommand(
                    @"SELECT StartDate, EndDate, LeaveTypeID,
                             LeaveReason, LeaveStatus
                      FROM Leaves
                      WHERE LeaveID = @id
                        AND GuardID = @gid", con);

                cmd.Parameters.AddWithValue("@id", leaveID);
                cmd.Parameters.AddWithValue("@gid", Session.GuardID);

                SqlDataReader dr = cmd.ExecuteReader();

                if (!dr.Read())
                {
                    dr.Close();
                    con.Close();
                    MessageBox.Show("This leave request does not belong to you.");
                    this.Close();
                    return;
                }

                string status = dr["LeaveStatus"].ToString();
                dtpStartDate.Value = Convert.ToDateTime(dr["StartDate"]);
                dtpEndDate.Value = Convert.ToDateTime(dr["EndDate"]);
                txtReason.Text = dr["LeaveReason"].ToString();
                cmbLeaveType.SelectedValue = Convert.ToInt32(dr["LeaveTypeID"]);

                dr.Close();
                con.Close();

                // Lock the form if the request is no longer pending
                if (!string.Equals(status, "Pending", StringComparison.OrdinalIgnoreCase))
                {
                    dtpStartDate.Enabled = false;
                    dtpEndDate.Enabled = false;
                    txtReason.ReadOnly = true;
                    cmbLeaveType.Enabled = false;
                    btnSave.Enabled = false;
                    MessageBox.Show("This leave request is already " + status + ". You cannot change it.");
                }
            }
            catch (Exception ex) { MessageBox.Show(ex.Message); }
        }





        private void btnSave_Click_1(object sender, EventArgs e)
        {
            if (Session.Role != "Guard") return;

            try
            {
                con.Open();

                // Update only rows belonging to this guard AND still Pending
                SqlCommand cmd = new SqlCommand(
                    @"UPDATE Leaves
                      SET StartDate   = @start,
                          EndDate     = @end,
                          LeaveTypeID = @type,
                          LeaveReason = @reason
                      WHERE LeaveID = @id
                        AND GuardID = @gid
                        AND LeaveStatus = 'Pending'", con);

                cmd.Parameters.AddWithValue("@start", dtpStartDate.Value.Date);
                cmd.Parameters.AddWithValue("@end", dtpEndDate.Value.Date);
                cmd.Parameters.AddWithValue("@type", cmbLeaveType.SelectedValue);
                cmd.Parameters.AddWithValue("@reason", txtReason.Text);
                cmd.Parameters.AddWithValue("@id", leaveID);
                cmd.Parameters.AddWithValue("@gid", Session.GuardID);

                int rows = cmd.ExecuteNonQuery();

                if (rows == 0)
                    MessageBox.Show("Could not update. It may already be approved or rejected.");
                else
                    MessageBox.Show("Leave request updated.");

                con.Close();
                this.Close();
            }
            catch (Exception ex) { MessageBox.Show(ex.Message); }

        }

        private void btnCancel_Click_1(object sender, EventArgs e)
        {
            this.Close();
        }

        private void cmbGuard_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
    }
}