﻿using System;
using System.Data;
using System.Windows.Forms;
using Microsoft.Data.SqlClient;

namespace Security
{
    public partial class AddSpecialShiftForm : Form
    {
        SqlConnection con = new SqlConnection(
            "Data Source=DESKTOP-133OPA4\\SQLEXPRESS;" +
            "Initial Catalog=SecureRoster;" +
            "Integrated Security=True;" +
            "Encrypt=False;");

        public AddSpecialShiftForm()
        {
            InitializeComponent();
        }

        private void AddSpecialShiftForm_Load(object sender, EventArgs e)
        {
            DataTable dtPost = new DataTable();
            new SqlDataAdapter("SELECT PostID, PostName FROM Posts", con).Fill(dtPost);
            cmbPost.DataSource = dtPost;
            cmbPost.DisplayMember = "PostName";
            cmbPost.ValueMember = "PostID";
            string[] times = { "00H00", "06H00", "12H00", "18H00", "22H00", "23H59" };
            cmbStartTime.Items.Clear(); cmbStartTime.Items.AddRange(times);
            cmbEndTime.Items.Clear(); cmbEndTime.Items.AddRange(times);
        }




        private void btnSave_Click(object sender, EventArgs e)
        {
            if (cmbPost.SelectedValue == null || cmbPost.SelectedValue is DataRowView) return;
            if (string.IsNullOrWhiteSpace(txtNameOfShift.Text)) { MessageBox.Show("Enter shift name."); return; }
            if (string.IsNullOrWhiteSpace(cmbStartTime.Text)) { MessageBox.Show("Select start time."); return; }
            if (string.IsNullOrWhiteSpace(cmbEndTime.Text)) { MessageBox.Show("Select end time."); return; }

            // --- NEW VALIDATION START ---
            if (cmbStartTime.Text == cmbEndTime.Text)
            {
                MessageBox.Show("Start time and End time cannot be the same.");
                return;
            }
            // --- NEW VALIDATION END ---

            try
            {
                con.Open();
                SqlCommand cmd = new SqlCommand(
                    @"INSERT INTO SpecialShifts
                (SpecialShiftID, PostID, NameOfShift,
                 StartTime, EndTime, SpecialShiftDate)
              VALUES
                ((SELECT ISNULL(MAX(SpecialShiftID),0) + 1 FROM SpecialShifts),
                 @post, @name, @start, @end, @date)", con);

                cmd.Parameters.AddWithValue("@post", cmbPost.SelectedValue);
                cmd.Parameters.AddWithValue("@name", txtNameOfShift.Text);
                cmd.Parameters.AddWithValue("@start", cmbStartTime.Text);
                cmd.Parameters.AddWithValue("@end", cmbEndTime.Text);
                cmd.Parameters.AddWithValue("@date", dtpSpecialShiftDate.Value.Date);

                cmd.ExecuteNonQuery();

                MessageBox.Show("Special Shift Added");
                con.Close();
                this.Close();
            }
            catch (Exception ex) { MessageBox.Show(ex.Message); }
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}