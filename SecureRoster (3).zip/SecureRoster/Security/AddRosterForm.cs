﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using Microsoft.Data.SqlClient;
namespace Security
{
    public partial class AddRosterForm : Form
    {
        SqlConnection con = new SqlConnection(
            "Data Source=DESKTOP-133OPA4\\SQLEXPRESS;" +
            "Initial Catalog=SecureRoster;" +
            "Integrated Security=True;" +
            "Encrypt=False;");
        public AddRosterForm()
        {
            InitializeComponent();
        }

        private void AddRosterForm_Load(object sender, EventArgs e)
        {
            // 1. Load Sites
            DataTable dtSite = new DataTable();
            new SqlDataAdapter("SELECT SiteID, NameOfSite FROM Sites", con).Fill(dtSite);
            cmbSite.DataSource = dtSite;
            cmbSite.DisplayMember = "NameOfSite";
            cmbSite.ValueMember = "SiteID";

            // 2. Load Status
            cmbStatus.Items.Clear();
            cmbStatus.Items.AddRange(new object[] { "Draft", "WORKING ON IT!", "Completed", "Cancelled" });
            cmbStatus.DropDownStyle = ComboBoxStyle.DropDownList;

            // 3. Load Supervisors
            DataTable dtSup = new DataTable();
            new SqlDataAdapter(
                @"SELECT sp.SupervisorID, p.FirstName + ' ' + p.LastName AS FullName
          FROM Supervisors sp
          INNER JOIN Persons p ON sp.PersonID = p.PersonID", con)
                .Fill(dtSup);
            cmbSupervisor.DataSource = dtSup;
            cmbSupervisor.DisplayMember = "FullName";
            cmbSupervisor.ValueMember = "SupervisorID";
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            // Changed to check if the text is empty rather than SelectedValue
            if (string.IsNullOrWhiteSpace(cmbSite.Text)) { MessageBox.Show("Select a site."); return; }
            if (cmbSupervisor.SelectedValue == null || cmbSupervisor.SelectedValue is DataRowView) { MessageBox.Show("Select a supervisor."); return; }

            if (dtpEndDate.Value.Date < dtpStartDate.Value.Date)
            {
                MessageBox.Show("The End Date cannot be before the Start Date.");
                return;
            }

            try
            {
                con.Open();
                SqlCommand cmd = new SqlCommand(
                    @"INSERT INTO Rosters
            (RosterID, StartDate, EndDate, RosterName, SiteID, SupervisorID, CreatedDate, RosterStatus)
          VALUES
            ((SELECT ISNULL(MAX(RosterID),0) + 1 FROM Rosters),
             @start, @end, @name, @site, @sup, GETDATE(), @status)", con);

                cmd.Parameters.AddWithValue("@start", dtpStartDate.Value.Date);
                cmd.Parameters.AddWithValue("@end", dtpEndDate.Value.Date);
                cmd.Parameters.AddWithValue("@name", txtRosterName.Text);

                // This ensures you get the ID even if you typed the name manually
                cmd.Parameters.AddWithValue("@site", cmbSite.SelectedValue ?? cmbSite.Text);

                cmd.Parameters.AddWithValue("@sup", cmbSupervisor.SelectedValue);
                cmd.Parameters.AddWithValue("@status", cmbStatus.Text);

                cmd.ExecuteNonQuery();

                MessageBox.Show("Roster Added");
                con.Close();
                this.Close();
            }
            catch (Exception ex) { MessageBox.Show(ex.Message); }
        }
        private void btnCancel_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
/*
*/