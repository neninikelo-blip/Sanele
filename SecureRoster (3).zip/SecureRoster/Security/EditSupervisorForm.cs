﻿using Microsoft.Data.SqlClient;
using System;
using System.Data;
using System.Windows.Forms;
using System.Windows.Forms.VisualStyles;

namespace Security
{
    public partial class EditSupervisorForm : Form
    {
        SqlConnection con = new SqlConnection(
            "Data Source=DESKTOP-133OPA4\\SQLEXPRESS;" +
            "Initial Catalog=SecureRoster;" +
            "Integrated Security=True;" +
            "Encrypt=False;");

        private int supervisorID;

        public EditSupervisorForm(int id)
        {
            InitializeComponent();
            supervisorID = id;
        }

        private void EditSupervisorForm_Load(object sender, EventArgs e)
        {
            cmbGender.Items.Clear();
            cmbGender.Items.AddRange(new object[] { "M", "F", "Other" });
            cmbGender.DropDownStyle = ComboBoxStyle.DropDownList;
            SqlDataAdapter da = new SqlDataAdapter(
                "SELECT SiteID, NameOfSite FROM Sites", con);
            DataTable dt = new DataTable();
            da.Fill(dt);

            comboBoxSite.DataSource = dt;
            comboBoxSite.DisplayMember = "NameOfSite";
            comboBoxSite.ValueMember = "SiteID";

            SqlDataAdapter da2 = new SqlDataAdapter(
                "SELECT SuburbID, SuburbName FROM Suburbs", con);
            DataTable dt2 = new DataTable();
            da2.Fill(dt2);

            comboBoxSuburb.DataSource = dt2;
            comboBoxSuburb.DisplayMember = "SuburbName";
            comboBoxSuburb.ValueMember = "SuburbID";

            try
            {
                con.Open();

                SqlCommand cmd = new SqlCommand(
                    @"SELECT PersonID, FirstName, LastName, Email,
                             Gender, Username, CellNumber, ID_Number, SiteID
                      FROM SupervisorView
                      WHERE SupervisorID = @id", con);

                cmd.Parameters.AddWithValue("@id", supervisorID);

                SqlDataReader dr = cmd.ExecuteReader();

                if (dr.Read())
                {
                    txtFirstName.Text = dr["FirstName"].ToString();
                    txtLastName.Text = dr["LastName"].ToString();
                    txtEmail.Text = dr["Email"].ToString();
                    cmbGender.Text = dr["GENDER"].ToString();
                    txtUsername.Text = dr["Username"].ToString();
                    txtCell.Text = dr["CellNumber"].ToString();
                    txtIDNumber.Text = dr["ID_Number"].ToString();

                    comboBoxSite.SelectedValue = Convert.ToInt32(dr["SiteID"]);
                }
                dr.Close();
                con.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }





        private void btnSave_Click_1(object sender, EventArgs e)
        {

            try
            {
                con.Open();

                // Update Persons
                SqlCommand cmd = new SqlCommand(
                    @"UPDATE Persons
                      SET FirstName  = @fname,
                          LastName   = @lname,
                          Email      = @email,
                          Gender     = @gender,
                          Username   = @username,
                          CellNumber = @cell,
                          ID_Number  = @idnum,
                          Suburb_ID  = @suburbid
                      WHERE PersonID =
                      (
                          SELECT PERSON_ID
                          FROM SupervisorView
                          WHERE SupervisorID = @supid
                      )", con);

                cmd.Parameters.AddWithValue("@fname", txtFirstName.Text);
                cmd.Parameters.AddWithValue("@lname", txtLastName.Text);
                cmd.Parameters.AddWithValue("@email", txtEmail.Text);
                cmd.Parameters.AddWithValue("@gender", cmbGender.Text);
                cmd.Parameters.AddWithValue("@username", txtUsername.Text);
                cmd.Parameters.AddWithValue("@cell", txtCell.Text);
                cmd.Parameters.AddWithValue("@idnum", txtIDNumber.Text);
                cmd.Parameters.AddWithValue("@suburbid", comboBoxSuburb.SelectedValue);
                cmd.Parameters.AddWithValue("@supid", supervisorID);

                cmd.ExecuteNonQuery();

                // Update Supervisor Site
                SqlCommand supCmd = new SqlCommand(
                    @"UPDATE Supervisors
                      SET SiteID = @siteid
                      WHERE SupervisorID = @supid", con);

                supCmd.Parameters.AddWithValue("@siteid", comboBoxSite.SelectedValue);
                supCmd.Parameters.AddWithValue("@supid", supervisorID);

                supCmd.ExecuteNonQuery();

                MessageBox.Show("Supervisor Updated Successfully");
                con.Close();
                this.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }

        }

        private void btnCancel_Click_1(object sender, EventArgs e)
        {
            this.Close();
        
        }
    }
}