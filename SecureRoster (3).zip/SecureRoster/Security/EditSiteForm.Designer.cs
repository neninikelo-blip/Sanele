﻿namespace Security
{
    partial class EditSiteForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            cmbSuburb = new ComboBox();
            cmbSecurityCompany = new ComboBox();
            cmbClientCompany = new ComboBox();
            label5 = new Label();
            label6 = new Label();
            btnCancel = new Button();
            btnSave = new Button();
            label3 = new Label();
            label2 = new Label();
            label1 = new Label();
            txtCapacity = new TextBox();
            txtSiteName = new TextBox();
            SuspendLayout();
            // 
            // cmbSuburb
            // 
            cmbSuburb.FormattingEnabled = true;
            cmbSuburb.Location = new Point(420, 97);
            cmbSuburb.Name = "cmbSuburb";
            cmbSuburb.Size = new Size(121, 23);
            cmbSuburb.TabIndex = 42;
            // 
            // cmbSecurityCompany
            // 
            cmbSecurityCompany.FormattingEnabled = true;
            cmbSecurityCompany.Location = new Point(420, 59);
            cmbSecurityCompany.Name = "cmbSecurityCompany";
            cmbSecurityCompany.Size = new Size(121, 23);
            cmbSecurityCompany.TabIndex = 41;
            // 
            // cmbClientCompany
            // 
            cmbClientCompany.FormattingEnabled = true;
            cmbClientCompany.Location = new Point(420, 9);
            cmbClientCompany.Name = "cmbClientCompany";
            cmbClientCompany.Size = new Size(121, 23);
            cmbClientCompany.TabIndex = 40;
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Location = new Point(300, 59);
            label5.Name = "label5";
            label5.Size = new Size(104, 15);
            label5.TabIndex = 39;
            label5.Text = "Security Company";
            // 
            // label6
            // 
            label6.Location = new Point(299, 12);
            label6.Name = "label6";
            label6.Size = new Size(100, 23);
            label6.TabIndex = 43;
            label6.Text = "Client Company";
            // 
            // btnCancel
            // 
            btnCancel.Location = new Point(333, 289);
            btnCancel.Name = "btnCancel";
            btnCancel.Size = new Size(75, 23);
            btnCancel.TabIndex = 38;
            btnCancel.Text = "Cancel";
            btnCancel.UseVisualStyleBackColor = true;
            btnCancel.Click += btnCancel_Click;
            // 
            // btnSave
            // 
            btnSave.Location = new Point(80, 289);
            btnSave.Name = "btnSave";
            btnSave.Size = new Size(75, 23);
            btnSave.TabIndex = 37;
            btnSave.Text = "Save";
            btnSave.UseVisualStyleBackColor = true;
            btnSave.Click += btnSave_Click;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(23, 59);
            label3.Name = "label3";
            label3.Size = new Size(53, 15);
            label3.TabIndex = 36;
            label3.Text = "Capacity";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(299, 100);
            label2.Name = "label2";
            label2.Size = new Size(45, 15);
            label2.TabIndex = 35;
            label2.Text = "Suburb";
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(23, 9);
            label1.Name = "label1";
            label1.Size = new Size(59, 15);
            label1.TabIndex = 34;
            label1.Text = "Site name";
            // 
            // txtCapacity
            // 
            txtCapacity.Location = new Point(165, 56);
            txtCapacity.Name = "txtCapacity";
            txtCapacity.Size = new Size(100, 23);
            txtCapacity.TabIndex = 33;
            // 
            // txtSiteName
            // 
            txtSiteName.Location = new Point(165, 9);
            txtSiteName.Name = "txtSiteName";
            txtSiteName.Size = new Size(100, 23);
            txtSiteName.TabIndex = 32;
            // 
            // EditSiteForm
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.FromArgb(31, 45, 61);
            ClientSize = new Size(553, 348);
            Controls.Add(cmbSuburb);
            Controls.Add(cmbSecurityCompany);
            Controls.Add(cmbClientCompany);
            Controls.Add(label5);
            Controls.Add(label6);
            Controls.Add(btnCancel);
            Controls.Add(btnSave);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(label1);
            Controls.Add(txtCapacity);
            Controls.Add(txtSiteName);
            Name = "EditSiteForm";
            Text = "EditSiteForm";
            Load += EditSiteForm_Load;
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private ComboBox cmbSuburb;
        private ComboBox cmbSecurityCompany;
        private ComboBox cmbClientCompany;
        private Label label5;
        private Label label6;
        private Button btnCancel;
        private Button btnSave;
        private Label label3;
        private Label label2;
        private Label label1;
        private TextBox txtCapacity;
        private TextBox txtSiteName;
    }
}