﻿namespace Security
{
    partial class AddSiteForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            label5 = new Label();
            label6 = new Label();
            btnCancel = new Button();
            btnSave = new Button();
            label3 = new Label();
            label2 = new Label();
            label1 = new Label();
            txtCapacity = new TextBox();
            txtSiteName = new TextBox();
            cmbClientCompany = new ComboBox();
            cmbSecurityCompany = new ComboBox();
            cmbSuburb = new ComboBox();
            SuspendLayout();
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Location = new Point(287, 62);
            label5.Name = "label5";
            label5.Size = new Size(104, 15);
            label5.TabIndex = 27;
            label5.Text = "Security Company";
            // 
            // label6
            // 
            label6.Location = new Point(286, 15);
            label6.Name = "label6";
            label6.Size = new Size(100, 23);
            label6.TabIndex = 31;
            label6.Text = "Client Company";
            // 
            // btnCancel
            // 
            btnCancel.Location = new Point(320, 292);
            btnCancel.Name = "btnCancel";
            btnCancel.Size = new Size(75, 23);
            btnCancel.TabIndex = 21;
            btnCancel.Text = "Cancel";
            btnCancel.UseVisualStyleBackColor = true;
            btnCancel.Click += btnCancel_Click;
            // 
            // btnSave
            // 
            btnSave.Location = new Point(67, 292);
            btnSave.Name = "btnSave";
            btnSave.Size = new Size(75, 23);
            btnSave.TabIndex = 20;
            btnSave.Text = "Save";
            btnSave.UseVisualStyleBackColor = true;
            btnSave.Click += btnSave_Click;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(10, 62);
            label3.Name = "label3";
            label3.Size = new Size(53, 15);
            label3.TabIndex = 19;
            label3.Text = "Capacity";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(286, 103);
            label2.Name = "label2";
            label2.Size = new Size(45, 15);
            label2.TabIndex = 18;
            label2.Text = "Suburb";
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(10, 12);
            label1.Name = "label1";
            label1.Size = new Size(59, 15);
            label1.TabIndex = 17;
            label1.Text = "Site name";
            // 
            // txtCapacity
            // 
            txtCapacity.Location = new Point(152, 59);
            txtCapacity.Name = "txtCapacity";
            txtCapacity.Size = new Size(100, 23);
            txtCapacity.TabIndex = 16;
            // 
            // txtSiteName
            // 
            txtSiteName.Location = new Point(152, 12);
            txtSiteName.Name = "txtSiteName";
            txtSiteName.Size = new Size(100, 23);
            txtSiteName.TabIndex = 14;
            // 
            // cmbClientCompany
            // 
            cmbClientCompany.FormattingEnabled = true;
            cmbClientCompany.Location = new Point(407, 12);
            cmbClientCompany.Name = "cmbClientCompany";
            cmbClientCompany.Size = new Size(121, 23);
            cmbClientCompany.TabIndex = 28;
            // 
            // cmbSecurityCompany
            // 
            cmbSecurityCompany.FormattingEnabled = true;
            cmbSecurityCompany.Location = new Point(407, 62);
            cmbSecurityCompany.Name = "cmbSecurityCompany";
            cmbSecurityCompany.Size = new Size(121, 23);
            cmbSecurityCompany.TabIndex = 29;
            // 
            // cmbSuburb
            // 
            cmbSuburb.FormattingEnabled = true;
            cmbSuburb.Location = new Point(407, 100);
            cmbSuburb.Name = "cmbSuburb";
            cmbSuburb.Size = new Size(121, 23);
            cmbSuburb.TabIndex = 30;
            // 
            // AddSiteForm
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.FromArgb(31, 45, 61);
            ClientSize = new Size(580, 359);
            Controls.Add(cmbSuburb);
            Controls.Add(cmbSecurityCompany);
            Controls.Add(cmbClientCompany);
            Controls.Add(label5);
            Controls.Add(label6);
            Controls.Add(btnCancel);
            Controls.Add(btnSave);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(label1);
            Controls.Add(txtCapacity);
            Controls.Add(txtSiteName);
            Name = "AddSiteForm";
            Text = "AddSiteForm";
            Load += AddSiteForm_Load;
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label5;
        private Label label6;
        private Button btnCancel;
        private Button btnSave;
        private Label label3;
        private Label label2;
        private Label label1;
        private TextBox txtCapacity;
        private TextBox txtSiteName;
        private ComboBox cmbClientCompany;
        private ComboBox cmbSecurityCompany;
        private ComboBox cmbSuburb;
    }
}