﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using Microsoft.Data.SqlClient;
namespace Security
{
    public partial class EditGuardForm : Form
    {
        public EditGuardForm(int id)
        {
            InitializeComponent();
            guardID = id;
        }
        SqlConnection con = new SqlConnection("Data Source=DESKTOP-133OPA4\\SQLEXPRESS;" + "Initial Catalog=SecureRoster;" + "Integrated Security=True;" + "Encrypt=False;");

        private int guardID;
        //   guardID =id;
        private void EditGuardForm_Load(object sender, EventArgs e)
        {
            cmbGender.Items.Clear();
            cmbGender.Items.AddRange(new object[] { "M", "F", "Other" });
            cmbGender.DropDownStyle = ComboBoxStyle.DropDownList;
            SqlDataAdapter da =
    new SqlDataAdapter(
    "SELECT SiteID, NameOfSite FROM Sites",
    con);

            DataTable dt = new DataTable();

            da.Fill(dt);

            comboBox1.DataSource = dt;
            comboBox1.DisplayMember = "NameOfSite";
            comboBox1.ValueMember = "SiteID";

            try
            {
                con.Open();

                SqlCommand cmd =
                new SqlCommand(
                @"SELECT
            PERSON_ID,
            FIRSTNAME,
            LASTNAME,
            CELLNUMBER,
            IDNUMBER,
            GENDER,
            SITE_ID
          FROM GuardsView
          WHERE GUARD_ID = @id",
                con);

                cmd.Parameters.AddWithValue("@id", guardID);

                SqlDataReader dr =
                    cmd.ExecuteReader();

                if (dr.Read())
                {
                    txtFirstName.Text =
                        dr["FIRSTNAME"].ToString();

                    txtLastName.Text =
                        dr["LASTNAME"].ToString();

                    txtCell.Text =
                        dr["CELLNUMBER"].ToString();

                    txtID.Text =
                        dr["IDNUMBER"].ToString();

                    cmbGender.Text = dr["GENDER"].ToString();

                    comboBox1.SelectedValue =
    Convert.ToInt32(dr["SITE_ID"]);
                }
                dr.Close();

                con.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }


        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            try
            {
                if (con.State != ConnectionState.Open) con.Open();

                // Start a transaction because we might update multiple tables
                SqlTransaction tx = con.BeginTransaction();

                try
                {
                    // 1. Update Persons table (Personal Details)
                    SqlCommand cmd = new SqlCommand(
                        @"UPDATE Persons
                  SET FirstName = @fname,
                      LastName = @lname,
                      CellNumber = @cell,
                      ID_Number = @idnum,
                      Gender = @gender
                  WHERE PersonID = (SELECT PERSON_ID FROM GuardsView WHERE GUARD_ID = @guardid)",
                        con, tx);

                    cmd.Parameters.AddWithValue("@fname", txtFirstName.Text);
                    cmd.Parameters.AddWithValue("@lname", txtLastName.Text);
                    cmd.Parameters.AddWithValue("@cell", txtCell.Text);
                    cmd.Parameters.AddWithValue("@idnum", txtID.Text);
                    cmd.Parameters.AddWithValue("@gender", cmbGender.Text);
                    cmd.Parameters.AddWithValue("@guardid", guardID);
                    cmd.ExecuteNonQuery();

                    // 2. Update Guards table (Site)
                    SqlCommand guardCmd = new SqlCommand(
                        @"UPDATE Guards
                  SET SiteID = @siteid
                  WHERE GuardID = @guardid",
                        con, tx);

                    guardCmd.Parameters.AddWithValue("@siteid", comboBox1.SelectedValue);
                    guardCmd.Parameters.AddWithValue("@guardid", guardID);
                    guardCmd.ExecuteNonQuery();

                    // 3. Update Password ONLY if the manager typed a new one
                    if (!string.IsNullOrWhiteSpace(txtPassword.Text))
                    {
                        // Hash the new password
                        var (salt, hash) = PasswordHasher.CreateHash(txtPassword.Text);

                        SqlCommand pwdCmd = new SqlCommand(
                            @"UPDATE Accounts
                      SET PasswordSalt = @salt, 
                          PasswordHash = @hash
                      WHERE PersonID = (SELECT PERSON_ID FROM GuardsView WHERE GUARD_ID = @guardid)",
                            con, tx);

                        pwdCmd.Parameters.AddWithValue("@salt", salt);
                        pwdCmd.Parameters.AddWithValue("@hash", hash);
                        pwdCmd.Parameters.AddWithValue("@guardid", guardID);
                        pwdCmd.ExecuteNonQuery();
                    }

                    // Commit everything
                    tx.Commit();

                    MessageBox.Show("Guard Updated Successfully");
                    con.Close();
                    this.Close();
                }
                catch
                {
                    tx.Rollback();
                    throw;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
