﻿namespace Security
{
    partial class AddSpecialShiftForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            label6 = new Label();
            label4 = new Label();
            cmbPost = new ComboBox();
            btnCancel = new Button();
            btnSave = new Button();
            label3 = new Label();
            label2 = new Label();
            label1 = new Label();
            txtNameOfShift = new TextBox();
            cmbStartTime = new ComboBox();
            cmbEndTime = new ComboBox();
            dtpSpecialShiftDate = new DateTimePicker();
            SuspendLayout();
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Location = new Point(13, 184);
            label6.Name = "label6";
            label6.Size = new Size(58, 15);
            label6.TabIndex = 26;
            label6.Text = "Shift Date";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new Point(12, 144);
            label4.Name = "label4";
            label4.Size = new Size(30, 15);
            label4.TabIndex = 23;
            label4.Text = "Post";
            // 
            // cmbPost
            // 
            cmbPost.FormattingEnabled = true;
            cmbPost.Items.AddRange(new object[] { "Potsdam Campus", "College Street Campus" });
            cmbPost.Location = new Point(154, 144);
            cmbPost.Name = "cmbPost";
            cmbPost.Size = new Size(121, 23);
            cmbPost.TabIndex = 22;
            // 
            // btnCancel
            // 
            btnCancel.Location = new Point(265, 287);
            btnCancel.Name = "btnCancel";
            btnCancel.Size = new Size(75, 23);
            btnCancel.TabIndex = 21;
            btnCancel.Text = "Cancel";
            btnCancel.UseVisualStyleBackColor = true;
            btnCancel.Click += btnCancel_Click;
            // 
            // btnSave
            // 
            btnSave.Location = new Point(12, 287);
            btnSave.Name = "btnSave";
            btnSave.Size = new Size(75, 23);
            btnSave.TabIndex = 20;
            btnSave.Text = "Save";
            btnSave.UseVisualStyleBackColor = true;
            btnSave.Click += btnSave_Click;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(12, 106);
            label3.Name = "label3";
            label3.Size = new Size(57, 15);
            label3.TabIndex = 19;
            label3.Text = "End Time";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(12, 56);
            label2.Name = "label2";
            label2.Size = new Size(61, 15);
            label2.TabIndex = 18;
            label2.Text = "Start Time";
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(12, 12);
            label1.Name = "label1";
            label1.Size = new Size(79, 15);
            label1.TabIndex = 17;
            label1.Text = "Name of shift";
            // 
            // txtNameOfShift
            // 
            txtNameOfShift.Location = new Point(154, 12);
            txtNameOfShift.Name = "txtNameOfShift";
            txtNameOfShift.Size = new Size(121, 23);
            txtNameOfShift.TabIndex = 14;
            // 
            // cmbStartTime
            // 
            cmbStartTime.FormattingEnabled = true;
            cmbStartTime.Location = new Point(154, 48);
            cmbStartTime.Name = "cmbStartTime";
            cmbStartTime.Size = new Size(121, 23);
            cmbStartTime.TabIndex = 27;
            // 
            // cmbEndTime
            // 
            cmbEndTime.FormattingEnabled = true;
            cmbEndTime.Location = new Point(154, 98);
            cmbEndTime.Name = "cmbEndTime";
            cmbEndTime.Size = new Size(121, 23);
            cmbEndTime.TabIndex = 28;
            // 
            // dtpSpecialShiftDate
            // 
            dtpSpecialShiftDate.Location = new Point(75, 184);
            dtpSpecialShiftDate.Name = "dtpSpecialShiftDate";
            dtpSpecialShiftDate.Size = new Size(200, 23);
            dtpSpecialShiftDate.TabIndex = 29;
            // 
            // AddSpecialShiftForm
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.FromArgb(31, 45, 61);
            ClientSize = new Size(368, 333);
            Controls.Add(dtpSpecialShiftDate);
            Controls.Add(cmbEndTime);
            Controls.Add(cmbStartTime);
            Controls.Add(label6);
            Controls.Add(label4);
            Controls.Add(cmbPost);
            Controls.Add(btnCancel);
            Controls.Add(btnSave);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(label1);
            Controls.Add(txtNameOfShift);
            Name = "AddSpecialShiftForm";
            Text = "AddSpecialShiftForm";
            Load += AddSpecialShiftForm_Load;
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion
        private Label label6;
        private Label label4;
        private ComboBox cmbPost;
        private Button btnCancel;
        private Button btnSave;
        private Label label3;
        private Label label2;
        private Label label1;
        private TextBox txtNameOfShift;
        private ComboBox cmbStartTime;
        private ComboBox cmbEndTime;
        private DateTimePicker dtpSpecialShiftDate;
    }
}