﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using Microsoft.Data.SqlClient;

namespace Security
{
    public partial class EditProfileForm : Form
    {
        SqlConnection con = new SqlConnection(
            "Data Source=DESKTOP-133OPA4\\SQLEXPRESS;" +
            "Initial Catalog=SecureRoster;" +
            "Integrated Security=True;" +
            "Encrypt=False;" +
            "Connect Timeout=60;");
        public EditProfileForm()
        {
            InitializeComponent();
        }

        private void EditProfileForm_Load(object sender, EventArgs e)
        {
            cmbGender.Items.Clear();
            cmbGender.Items.AddRange(new object[] { "M", "F", "Other" });
            cmbGender.DropDownStyle = ComboBoxStyle.DropDownList;

            // Hide combos by default
            cmbCompany.Visible = false;
            cmbSite.Visible = false;
            cmbSuburb.Visible = false;

            try
            {
                con.Open();

                // 1. Load Suburbs (for everyone)
                DataTable dtSub = new DataTable();
                new SqlDataAdapter("SELECT SuburbID, SuburbName FROM Suburbs", con).Fill(dtSub);
                cmbSuburb.DataSource = dtSub;
                cmbSuburb.DisplayMember = "SuburbName";
                cmbSuburb.ValueMember = "SuburbID";
                cmbSuburb.Visible = true;

                // 2. Load Companies and Sites based on Role
                if (Session.Role == "Manager")
                {
                    cmbCompany.Visible = true;
                    DataTable dtComp = new DataTable();

                    // FIXED: Used exact column names from SecurityCompaniesView
                    new SqlDataAdapter("SELECT SECURITYCOMP_ID, COMPANYNAME FROM SecurityCompaniesView", con).Fill(dtComp);

                    cmbCompany.DataSource = dtComp;
                    cmbCompany.DisplayMember = "COMPANYNAME";
                    cmbCompany.ValueMember = "SECURITYCOMP_ID";
                }
                else if (Session.Role == "Supervisor" || Session.Role == "Guard")
                {
                    cmbCompany.Visible = true;
                    cmbSite.Visible = true;

                    // Company Combo
                    DataTable dtComp = new DataTable();

                    // FIXED: Used exact column names from SecurityCompaniesView
                    new SqlDataAdapter("SELECT SECURITYCOMP_ID, COMPANYNAME FROM SecurityCompaniesView", con).Fill(dtComp);

                    cmbCompany.DataSource = dtComp;
                    cmbCompany.DisplayMember = "COMPANYNAME";
                    cmbCompany.ValueMember = "SECURITYCOMP_ID";

                    // Site Combo
                    DataTable dtSite = new DataTable();
                    new SqlDataAdapter("SELECT SiteID, NameOfSite FROM Sites", con).Fill(dtSite);
                    cmbSite.DataSource = dtSite;
                    cmbSite.DisplayMember = "NameOfSite";
                    cmbSite.ValueMember = "SiteID";
                }

                // 3. Load the user's specific data
                LoadUserData();
            }
            catch (Exception ex) { MessageBox.Show(ex.Message); }
            finally { con.Close(); }
        }


        private void LoadUserData()
        {
            string query = "";
            if (Session.Role == "Guard") query = "SELECT * FROM GuardsProfile WHERE USERNAME = @user";
            else if (Session.Role == "Supervisor") query = "SELECT * FROM SupervisorView WHERE Username = @user";
            else if (Session.Role == "Manager") query = "SELECT * FROM ManagersDetailsView WHERE Username = @user";

            SqlCommand cmd = new SqlCommand(query, con);
            cmd.Parameters.AddWithValue("@user", Session.Username);

            DataTable dt = new DataTable();
            using (SqlDataAdapter da = new SqlDataAdapter(cmd)) { da.Fill(dt); }

            if (dt.Rows.Count > 0)
            {
                DataRow row = dt.Rows[0];

                // Basic Info
                txtFirstName.Text = row["FIRSTNAME"].ToString();
                txtLastName.Text = row["LASTNAME"].ToString();
                txtEmail.Text = row["EMAIL"].ToString();
                txtCell.Text = row["CELLNUMBER"].ToString();
                cmbGender.Text = row["GENDER"].ToString();

                if (dt.Columns.Contains("ID_Number") && row["ID_Number"] != DBNull.Value)
                    txtIDNumber.Text = row["ID_Number"].ToString();

                if (dt.Columns.Contains("Suburb_ID") && row["Suburb_ID"] != DBNull.Value)
                    cmbSuburb.SelectedValue = Convert.ToInt32(row["Suburb_ID"]);

                // Role-Specific Data (The fix is here)
                if (Session.Role == "Manager")
                {
                    if (dt.Columns.Contains("SecurityCompID") && row["SecurityCompID"] != DBNull.Value)
                        cmbCompany.SelectedValue = Convert.ToInt32(row["SecurityCompID"]);
                }
                else if (Session.Role == "Supervisor" || Session.Role == "Guard")
                {
                    if (dt.Columns.Contains("SITE_ID") && row["SITE_ID"] != DBNull.Value)
                        cmbSite.SelectedValue = Convert.ToInt32(row["SITE_ID"]);
                }
            }
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            try
            {
                con.Open();

                // 1. Update Persons table
                SqlCommand cmd = new SqlCommand(
                    @"UPDATE Persons
                      SET FirstName = @fname, LastName = @lname, Email = @email, 
                          Gender = @gender, CellNumber = @cell, ID_Number = @idnum, Suburb_ID = @sub
                      WHERE PersonID = @pid", con);

                cmd.Parameters.AddWithValue("@fname", txtFirstName.Text);
                cmd.Parameters.AddWithValue("@lname", txtLastName.Text);
                cmd.Parameters.AddWithValue("@email", txtEmail.Text);
                cmd.Parameters.AddWithValue("@gender", cmbGender.Text);
                cmd.Parameters.AddWithValue("@cell", txtCell.Text);
                cmd.Parameters.AddWithValue("@idnum", txtIDNumber.Text);
                cmd.Parameters.AddWithValue("@sub", cmbSuburb.SelectedValue);
                cmd.Parameters.AddWithValue("@pid", Session.PersonID);
                cmd.ExecuteNonQuery();

                // 2. Update specific tables based on Role (Company/Site changes)
                if (Session.Role == "Manager")
                {
                    SqlCommand mCmd = new SqlCommand(
                        "UPDATE Managers SET CompanyID = @cid WHERE PersonID = @pid", con);
                    mCmd.Parameters.AddWithValue("@cid", cmbCompany.SelectedValue);
                    mCmd.Parameters.AddWithValue("@pid", Session.PersonID);
                    mCmd.ExecuteNonQuery();
                }
                else if (Session.Role == "Supervisor")
                {
                    SqlCommand sCmd = new SqlCommand(
                        "UPDATE Supervisors SET SiteID = @sid WHERE PersonID = @pid", con);
                    sCmd.Parameters.AddWithValue("@sid", cmbSite.SelectedValue);
                    sCmd.Parameters.AddWithValue("@pid", Session.PersonID);
                    sCmd.ExecuteNonQuery();
                }
                else if (Session.Role == "Guard")
                {
                    SqlCommand gCmd = new SqlCommand(
                        "UPDATE Guards SET SiteID = @sid WHERE PersonID = @pid", con);
                    gCmd.Parameters.AddWithValue("@sid", cmbSite.SelectedValue);
                    gCmd.Parameters.AddWithValue("@pid", Session.PersonID);
                    gCmd.ExecuteNonQuery();
                }

                MessageBox.Show("Profile updated successfully.");
                this.Close();
            }
            catch (Exception ex) { MessageBox.Show(ex.Message); }
        }
    


        private void btnCancel_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }

}
/**/