﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using Microsoft.Data.SqlClient;
namespace Security
{
    public partial class EditTypeOfShiftForm : Form
    {
        private int typeShiftID;
        public EditTypeOfShiftForm(int id)
        {
            InitializeComponent();
            typeShiftID = id;
        }
        SqlConnection con = new SqlConnection(
           "Data Source=DESKTOP-133OPA4\\SQLEXPRESS;" +
           "Initial Catalog=SecureRoster;" +
           "Integrated Security=True;" +
           "Encrypt=False;");

        private void EditTypeOfShiftForm_Load(object sender, EventArgs e)
        {
            try
            {
                if (con.State != ConnectionState.Open) con.Open();
                SqlCommand cmd = new SqlCommand(
                    "SELECT TypeOfShift, StartTime, EndTime FROM TypeOfShifts WHERE TypeShiftID = @id", con);
                cmd.Parameters.AddWithValue("@id", typeShiftID);
                SqlDataReader dr = cmd.ExecuteReader();
                if (dr.Read())
                {
                    txtTypeOfShift.Text = dr["TypeOfShift"].ToString();
                    txtStartTime.Text = dr["StartTime"].ToString();
                    txtEndTime.Text = dr["EndTime"].ToString();
                }
                dr.Close();
                con.Close();
            }
            catch (Exception ex) { MessageBox.Show(ex.Message); }
         }

        private void btnSave_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(txtTypeOfShift.Text)) { MessageBox.Show("Enter shift type."); return; }
            if (string.IsNullOrWhiteSpace(txtStartTime.Text)) { MessageBox.Show("Enter start time."); return; }
            if (string.IsNullOrWhiteSpace(txtEndTime.Text)) { MessageBox.Show("Enter end time."); return; }

            try
            {
                if (con.State != ConnectionState.Open) con.Open();
                SqlCommand cmd = new SqlCommand(
                    @"UPDATE TypeOfShifts
              SET TypeOfShift = @type, StartTime = @start, EndTime = @end
              WHERE TypeShiftID = @id", con);

                cmd.Parameters.AddWithValue("@type", txtTypeOfShift.Text);
                cmd.Parameters.AddWithValue("@start", txtStartTime.Text);
                cmd.Parameters.AddWithValue("@end", txtEndTime.Text);
                cmd.Parameters.AddWithValue("@id", typeShiftID);

                cmd.ExecuteNonQuery();
                MessageBox.Show("Type of Shift Updated");
                con.Close();
                this.Close();
            }
            catch (Exception ex) { MessageBox.Show(ex.Message); }
         }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}

/*
       
*/