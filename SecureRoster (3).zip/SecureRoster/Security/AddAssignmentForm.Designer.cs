﻿namespace Security
{
    partial class AddAssignmentForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            cmbRosterDay = new ComboBox();
            label5 = new Label();
            label4 = new Label();
            cmbGuard = new ComboBox();
            label1 = new Label();
            btnCancel = new Button();
            btnSave = new Button();
            cmbShift = new ComboBox();
            SuspendLayout();
            // 
            // cmbRosterDay
            // 
            cmbRosterDay.FormattingEnabled = true;
            cmbRosterDay.Items.AddRange(new object[] { "Potsdam Campus", "College Street Campus" });
            cmbRosterDay.Location = new Point(147, 12);
            cmbRosterDay.Name = "cmbRosterDay";
            cmbRosterDay.Size = new Size(100, 23);
            cmbRosterDay.TabIndex = 62;
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Location = new Point(6, 69);
            label5.Name = "label5";
            label5.Size = new Size(31, 15);
            label5.TabIndex = 61;
            label5.Text = "Shift";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new Point(5, 112);
            label4.Name = "label4";
            label4.Size = new Size(77, 15);
            label4.TabIndex = 58;
            label4.Text = "Assign Guard";
            // 
            // cmbGuard
            // 
            cmbGuard.FormattingEnabled = true;
            cmbGuard.Items.AddRange(new object[] { "Potsdam Campus", "College Street Campus" });
            cmbGuard.Location = new Point(147, 112);
            cmbGuard.Name = "cmbGuard";
            cmbGuard.Size = new Size(121, 23);
            cmbGuard.TabIndex = 57;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(19, 12);
            label1.Name = "label1";
            label1.Size = new Size(63, 15);
            label1.TabIndex = 54;
            label1.Text = "Roster Day";
            // 
            // btnCancel
            // 
            btnCancel.Location = new Point(227, 353);
            btnCancel.Name = "btnCancel";
            btnCancel.Size = new Size(75, 23);
            btnCancel.TabIndex = 64;
            btnCancel.Text = "Cancel";
            btnCancel.UseVisualStyleBackColor = true;
            btnCancel.Click += btnCancel_Click;
            // 
            // btnSave
            // 
            btnSave.Location = new Point(9, 353);
            btnSave.Name = "btnSave";
            btnSave.Size = new Size(75, 23);
            btnSave.TabIndex = 63;
            btnSave.Text = "Save";
            btnSave.UseVisualStyleBackColor = true;
            btnSave.Click += btnSave_Click;
            // 
            // cmbShift
            // 
            cmbShift.FormattingEnabled = true;
            cmbShift.Items.AddRange(new object[] { "Potsdam Campus", "College Street Campus" });
            cmbShift.Location = new Point(147, 61);
            cmbShift.Name = "cmbShift";
            cmbShift.Size = new Size(121, 23);
            cmbShift.TabIndex = 65;
            // 
            // AddAssignmentForm
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(cmbShift);
            Controls.Add(btnCancel);
            Controls.Add(btnSave);
            Controls.Add(cmbRosterDay);
            Controls.Add(label5);
            Controls.Add(label4);
            Controls.Add(cmbGuard);
            Controls.Add(label1);
            Name = "AddAssignmentForm";
            Text = "AddAssignmentForm";
            Load += AddAssignmentForm_Load;
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private ComboBox cmbGender;
        private Label label5;
        private Label label6;
        private TextBox txtIDNumber;
        private Label label4;
        private ComboBox cmbSite;
        private Label label3;
        private Label label2;
        private Label label1;
        private TextBox txtCell;
        private TextBox txtLastName;
        private TextBox txtFirstName;
        private ComboBox cmbRosterDay;
        private ComboBox cmbGuard;
        private Button btnCancel;
        private Button btnSave;
        private ComboBox cmbShift;
    }
}