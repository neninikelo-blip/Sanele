﻿using System;
using System.Data;
using System.Windows.Forms;
using Microsoft.Data.SqlClient;

namespace Security
{
    public partial class AddRegularShiftForm : Form
    {
        SqlConnection con = new SqlConnection(
            "Data Source=DESKTOP-133OPA4\\SQLEXPRESS;" +
            "Initial Catalog=SecureRoster;" +
            "Integrated Security=True;" +
            "Encrypt=False;");

        public AddRegularShiftForm()
        {
            InitializeComponent();
        }

        private void AddRegularShiftForm_Load(object sender, EventArgs e)
        {
            // Type of shifts
            DataTable dtType = new DataTable();
            // Added DISTINCT
            new SqlDataAdapter("SELECT DISTINCT TypeShiftID, TypeOfShift FROM TypeOfShifts", con).Fill(dtType);
            cmbTypeShift.DataSource = dtType;
            cmbTypeShift.DisplayMember = "TypeOfShift";
            cmbTypeShift.ValueMember = "TypeShiftID";

            // Posts
            DataTable dtPost = new DataTable();
            new SqlDataAdapter(
                "SELECT PostID, PostName FROM Posts", con).Fill(dtPost);
            cmbPost.DataSource = dtPost;
            cmbPost.DisplayMember = "PostName";
            cmbPost.ValueMember = "PostID";
        }



       
        private void btnSave_Click(object sender, EventArgs e)
        {
            if (cmbTypeShift.SelectedValue == null || cmbTypeShift.SelectedValue is DataRowView) { MessageBox.Show("Select shift type"); return; }
            if (cmbPost.SelectedValue == null || cmbPost.SelectedValue is DataRowView) { MessageBox.Show("Select post"); return; }
            if (string.IsNullOrWhiteSpace(txtNameOfShift.Text)) { MessageBox.Show("Enter shift name"); return; }

            try
            {
                con.Open();

                // Check if a shift of this type already exists for this post
                SqlCommand checkCmd = new SqlCommand(
                    "SELECT COUNT(*) FROM RegularShifts WHERE PostID = @pid AND TypeShiftID = @tsid", con);
                checkCmd.Parameters.AddWithValue("@pid", cmbPost.SelectedValue);
                checkCmd.Parameters.AddWithValue("@tsid", cmbTypeShift.SelectedValue);

                int count = Convert.ToInt32(checkCmd.ExecuteScalar());
                if (count > 0)
                {
                    MessageBox.Show("A shift of this type already exists for this post.");
                    con.Close();
                    return;
                }

                SqlCommand cmd = new SqlCommand(
                    @"INSERT INTO RegularShifts
            (RegularShiftID, TypeShiftID, PostID, NameOfShift)
          VALUES
            ((SELECT ISNULL(MAX(RegularShiftID),0) + 1 FROM RegularShifts),
             @type, @post, @name)", con);

                cmd.Parameters.AddWithValue("@type", cmbTypeShift.SelectedValue);
                cmd.Parameters.AddWithValue("@post", cmbPost.SelectedValue);
                cmd.Parameters.AddWithValue("@name", txtNameOfShift.Text);

                cmd.ExecuteNonQuery();

                MessageBox.Show("Regular Shift Added");
                con.Close();
                this.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message);
                if (con.State == ConnectionState.Open) con.Close();
            }
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}