﻿using System;
using Microsoft.Data.SqlClient;

namespace Security
{
    public static class SeedAdmin
    {
        public static void CreateFirstAccounts()
        {
            // (username, password, personID, role)
            var users = new[]
            {
                ("thabisomokwena"   , "aDone1431*" ,   4 ,  "Manager"),
                ("NtandokaziMavuso" , "aDone1431*" , 101 ,  "Manager"),
                ("NomsaZulu"        , "aDone1431*" , 201 ,  "Manager"),

                ("johnbrown"        , "aDone1431*" ,   1 ,  "Supervisor"),
                ("siyandapeterson"  , "aDone1431*" , 124 ,  "Supervisor"),
                ("yangamthethwa"    , "aDone1431*" , 125 ,  "Supervisor"),

                ("leratozondo"      , "aDone1431*" ,   3 ,  "Guard"),
                ("zintlekhumalo"    , "aDone1431*" ,   2 ,  "Guard"),
                ("BASETSANA"        , "aDone1431*" ,   9 ,  "Guard"),
                ("buhleM"           , "aDone1431*" ,  72 ,  "Guard"),
                ("ThandiDlamini"    , "aDone1431*" ,  32 ,  "Guard"),
                ("lethaboP"         , "aDone1431*" ,  67 ,  "Guard"),
                ("siphom03"         , "aDone1431*" ,  33 ,  "Guard"),
                ("LihleNdaba"       , "aDone1431*" ,  19 ,  "Guard"),
                ("mandlaG"          , "aDone1431*" ,  68 ,  "Guard"),

                ("jamal5ITAdmin"    , "aDone1431*" ,   6 ,  "ITAdmin"),

            };

            using (var con = new SqlConnection(
                "Data Source=DESKTOP-133OPA4\\SQLEXPRESS;" +
                "Initial Catalog=SecureRoster;" +
                "Integrated Security=True;" +
                "Encrypt=False;" +
                "Connect Timeout=60;"))
            {
                con.Open();

                foreach (var (username, password, personID, role) in users)
                {
                    // Skip if account already exists
                    SqlCommand exists = new SqlCommand(
                        "SELECT COUNT(*) FROM Accounts WHERE Username = @u", con);
                    exists.Parameters.AddWithValue("@u", username);
                    if (Convert.ToInt32(exists.ExecuteScalar()) > 0) continue;

                    var (salt, hash) = PasswordHasher.CreateHash(password);

                    SqlCommand idCmd = new SqlCommand(
                        "SELECT ISNULL(MAX(AccountID),0) + 1 FROM Accounts", con);
                    int accountID = Convert.ToInt32(idCmd.ExecuteScalar());

                    SqlCommand cmd = new SqlCommand(
                        @"INSERT INTO Accounts
                            (AccountID, PersonID, Username,
                             PasswordSalt, PasswordHash, Role_)
                          VALUES
                            (@aid, @pid, @user, @salt, @hash, @role)", con);

                    cmd.Parameters.AddWithValue("@aid", accountID);
                    cmd.Parameters.AddWithValue("@pid", personID);
                    cmd.Parameters.AddWithValue("@user", username);
                    cmd.Parameters.AddWithValue("@salt", salt);
                    cmd.Parameters.AddWithValue("@hash", hash);
                    cmd.Parameters.AddWithValue("@role", role);

                    cmd.ExecuteNonQuery();
                }
            }
        }
    }
}