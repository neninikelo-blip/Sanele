﻿namespace Security
{
    partial class Form3
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            Guard = new Button();
            Supervisor = new Button();
            Manager = new Button();
            ITAdmin = new Button();
            button1 = new Button();
            SuspendLayout();
            // 
            // Guard
            // 
            Guard.BackColor = Color.Yellow;
            Guard.Font = new Font("Segoe UI", 13F);
            Guard.Location = new Point(294, 28);
            Guard.Name = "Guard";
            Guard.Size = new Size(105, 47);
            Guard.TabIndex = 0;
            Guard.Text = "Guard";
            Guard.UseVisualStyleBackColor = false;
            Guard.Click += Guard_Click;
            // 
            // Supervisor
            // 
            Supervisor.BackColor = Color.Lime;
            Supervisor.Font = new Font("Segoe UI", 13F);
            Supervisor.Location = new Point(294, 102);
            Supervisor.Name = "Supervisor";
            Supervisor.Size = new Size(121, 37);
            Supervisor.TabIndex = 1;
            Supervisor.Text = "Supervisor";
            Supervisor.UseVisualStyleBackColor = false;
            Supervisor.Click += Supervisor_Click;
            // 
            // Manager
            // 
            Manager.BackColor = Color.Red;
            Manager.Font = new Font("Segoe UI", 13F);
            Manager.Location = new Point(294, 167);
            Manager.Name = "Manager";
            Manager.Size = new Size(105, 43);
            Manager.TabIndex = 2;
            Manager.Text = "Manager";
            Manager.UseVisualStyleBackColor = false;
            Manager.Click += Manager_Click;
            // 
            // ITAdmin
            // 
            ITAdmin.BackColor = Color.FromArgb(255, 128, 0);
            ITAdmin.Font = new Font("Segoe UI", 13F);
            ITAdmin.Location = new Point(294, 236);
            ITAdmin.Name = "ITAdmin";
            ITAdmin.Size = new Size(105, 53);
            ITAdmin.TabIndex = 3;
            ITAdmin.Text = "ITAdmin";
            ITAdmin.UseVisualStyleBackColor = false;
            ITAdmin.Click += ITAdmin_Click;
            // 
            // button1
            // 
            button1.BackColor = SystemColors.ControlLight;
            button1.Font = new Font("Segoe UI", 13F);
            button1.Location = new Point(303, 337);
            button1.Name = "button1";
            button1.Size = new Size(96, 41);
            button1.TabIndex = 4;
            button1.Text = "Exit";
            button1.UseVisualStyleBackColor = false;
            button1.Click += button1_Click;
            // 
            // Form3
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.FromArgb(31, 45, 61);
            ClientSize = new Size(800, 450);
            Controls.Add(button1);
            Controls.Add(ITAdmin);
            Controls.Add(Manager);
            Controls.Add(Supervisor);
            Controls.Add(Guard);
            Name = "Form3";
            Text = "Form3";
            Load += Form3_Load;
            ResumeLayout(false);
        }

        #endregion

        private Button Guard;
        private Button Supervisor;
        private Button Manager;
        private Button ITAdmin;
        private Button button1;
    }
}