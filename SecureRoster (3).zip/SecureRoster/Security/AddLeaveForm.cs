﻿using System;
using System.Data;
using System.Windows.Forms;
using Microsoft.Data.SqlClient;

namespace Security
{
    public partial class AddLeaveForm : Form
    {
        SqlConnection con = new SqlConnection(
            "Data Source=DESKTOP-133OPA4\\SQLEXPRESS;" +
            "Initial Catalog=SecureRoster;" +
            "Integrated Security=True;" +
            "Encrypt=False;" +
            "Connect Timeout=60;");

        // Which guard this leave is for.
        // If a Guard is logged in, this is their GuardID.
        // If a Supervisor/Manager is adding on behalf, they pick it.
      //  private int guardID;
      //  private bool guardIsFixed;   // true if we should not let the user change it

        public AddLeaveForm()
        {
            InitializeComponent();
        }

        private void AddLeaveForm_Load(object sender, EventArgs e)
        {
            if (Session.Role != "Guard")
            {
                MessageBox.Show("Only guards can submit leave requests.");
                this.Close();
                return;
            }

            DataTable dt = new DataTable();
            new SqlDataAdapter(
                "SELECT TypeOfLeaveID, TypeOfLeave FROM TypeOfLeaves", con).Fill(dt);

            cmbLeaveType.DataSource = dt;
            cmbLeaveType.DisplayMember = "TypeOfLeave";
            cmbLeaveType.ValueMember = "TypeOfLeaveID";

        }



        private void btnSave_Click_1(object sender, EventArgs e)
        {
            if (Session.Role != "Guard") return;

            if (Session.GuardID == 0)
            {
                try
                {
                    con.Open();
                    SqlCommand g = new SqlCommand(
                        "SELECT GuardID, SiteID FROM Guards WHERE PersonID = @pid", con);
                    g.Parameters.AddWithValue("@pid", Session.PersonID);

                    SqlDataReader dr = g.ExecuteReader();
                    if (dr.Read())
                    {
                        Session.GuardID = Convert.ToInt32(dr["GuardID"]);
                        Session.SiteID = Convert.ToInt32(dr["SiteID"]);
                    }
                    dr.Close();
                    con.Close();
                }
                catch (Exception ex) { MessageBox.Show(ex.Message); }
            }

            if (Session.GuardID == 0)
            {
                MessageBox.Show("Your guard profile is not linked. Contact your manager.");
                return;
            }

            if (cmbLeaveType.SelectedValue == null ||
                cmbLeaveType.SelectedValue is DataRowView)
            {
                MessageBox.Show("Please choose a leave type.");
                return;
            }

            // --- NEW VALIDATION START ---
            DateTime start = dtpStartDate.Value.Date;
            DateTime end = dtpEndDate.Value.Date;

            if (end < start)
            {
                MessageBox.Show("The End Date cannot be before the Start Date.");
                return;
            }

            try
            {
                con.Open();

                // Check Max Duration
                SqlCommand maxCmd = new SqlCommand("SELECT MaxDuration FROM TypeOfLeaves WHERE TypeOfLeaveID = @id", con);
                maxCmd.Parameters.AddWithValue("@id", cmbLeaveType.SelectedValue);
                string maxDurationStr = maxCmd.ExecuteScalar().ToString(); // e.g., "10 Days"

                // Extract the number from the string
                string safeStr = maxDurationStr ?? "0 Days";
                int maxDays = Convert.ToInt32(System.Text.RegularExpressions.Regex.Match(safeStr, @"\d+").Value);
                int requestedDays = (end - start).Days + 1; // +1 to include both start and end day

                if (requestedDays > maxDays)
                {
                    MessageBox.Show($"You cannot request {requestedDays} days. The maximum for this leave type is {maxDays} days.");
                    con.Close();
                    return;
                }

                // --- NEW VALIDATION END ---

                SqlCommand cmd = new SqlCommand(
                    @"INSERT INTO Leaves
                (LeaveID, GuardID, StartDate, EndDate,
                 LeaveTypeID, LeaveReason, LeaveStatus)
              VALUES
                ((SELECT ISNULL(MAX(LeaveID),0) + 1 FROM Leaves),
                 @gid, @start, @end, @type, @reason, 'Pending')", con);

                cmd.Parameters.AddWithValue("@gid", Session.GuardID);
                cmd.Parameters.AddWithValue("@start", start);
                cmd.Parameters.AddWithValue("@end", end);
                cmd.Parameters.AddWithValue("@type", cmbLeaveType.SelectedValue);
                cmd.Parameters.AddWithValue("@reason", txtReason.Text);

                cmd.ExecuteNonQuery();

                MessageBox.Show("Leave request submitted. Awaiting approval.");
                con.Close();
                this.Close();
            }
            catch (Exception ex) { MessageBox.Show(ex.Message); }
         }
         

        private void btnCancel_Click_1(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}