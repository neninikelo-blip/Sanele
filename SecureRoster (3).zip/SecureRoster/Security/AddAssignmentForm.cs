﻿using System;
using System.Data;
using System.Windows.Forms;
using Microsoft.Data.SqlClient;

namespace Security
{
    public partial class AddAssignmentForm : Form
    {
        SqlConnection con = new SqlConnection("Data Source=DESKTOP-133OPA4\\SQLEXPRESS;Initial Catalog=SecureRoster;Integrated Security=True;Encrypt=False;");

        public AddAssignmentForm()
        {
            InitializeComponent();
        }

        private void AddAssignmentForm_Load(object sender, EventArgs e)
        {
            // Note: You will need to add 3 ComboBoxes to your Designer (cmbRosterDay, cmbShift, cmbGuard)

            // Load Roster Days (Only for this supervisor's site)
            DataTable dtDays = new DataTable();
            new SqlDataAdapter($@"SELECT rd.RosterDayID, rd.ShiftDate 
                                  FROM RosterDays rd 
                                  INNER JOIN Rosters r ON rd.Roster_ID = r.RosterID 
                                  WHERE r.SupervisorID = {Session.SupervisorID}", con).Fill(dtDays);
            cmbRosterDay.DataSource = dtDays;
            cmbRosterDay.DisplayMember = "ShiftDate";
            cmbRosterDay.ValueMember = "RosterDayID";

            // Load Regular Shifts (Only for this supervisor's site)
            DataTable dtShifts = new DataTable();
            new SqlDataAdapter($@"SELECT rs.RegularShiftID, rs.NameOfShift 
                                  FROM RegularShifts rs
                                  INNER JOIN Posts p ON rs.PostID = p.PostID
                                  INNER JOIN Sites s ON p.SiteID = s.SiteID
                                  INNER JOIN Supervisors sp ON s.SiteID = sp.SiteID
                                  WHERE sp.SupervisorID = {Session.SupervisorID}", con).Fill(dtShifts);
            cmbShift.DataSource = dtShifts;
            cmbShift.DisplayMember = "NameOfShift";
            cmbShift.ValueMember = "RegularShiftID";

            // Load Guards at this site
            DataTable dtGuards = new DataTable();
            new SqlDataAdapter($@"SELECT g.GuardID, p.FirstName + ' ' + p.LastName AS GuardName 
                                  FROM Guards g
                                  INNER JOIN Persons p ON g.PersonID = p.PersonID
                                  WHERE g.SiteID = {Session.SiteID}", con).Fill(dtGuards);
            cmbGuard.DataSource = dtGuards;
            cmbGuard.DisplayMember = "GuardName";
            cmbGuard.ValueMember = "GuardID";
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            if (cmbRosterDay.SelectedValue == null || cmbShift.SelectedValue == null || cmbGuard.SelectedValue == null) return;

            try
            {
                con.Open();
                SqlCommand cmd = new SqlCommand(
                    @"INSERT INTO RegularShiftsAssignments (AssignmentID, GuardID, RosterDayID, RegularShiftID)
                      VALUES (
                        (SELECT ISNULL(MAX(AssignmentID),0) + 1 FROM RegularShiftsAssignments), 
                        @guard, @day, @shift)", con);

                cmd.Parameters.AddWithValue("@guard", cmbGuard.SelectedValue);
                cmd.Parameters.AddWithValue("@day", cmbRosterDay.SelectedValue);
                cmd.Parameters.AddWithValue("@shift", cmbShift.SelectedValue);

                cmd.ExecuteNonQuery();
                MessageBox.Show("Guard assigned successfully.");
                this.Close();
            }
            catch (Exception ex) { MessageBox.Show("Error: " + ex.Message); } // Catches the double-booking unique constraint error
            finally { con.Close(); }
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }

}
/*

namespace Security
{
    public partial class AddAssignmentForm : Form
    {
        public AddAssignmentForm()
        {
            InitializeComponent();
        }

       
        
    }
}*/