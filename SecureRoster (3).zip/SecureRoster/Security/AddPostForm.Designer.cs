﻿namespace Security
{
    partial class AddPostForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            cmbSite = new ComboBox();
            cmbStatus = new ComboBox();
            comboBoxSecurityCompany = new ComboBox();
            label5 = new Label();
            label6 = new Label();
            btnCancel = new Button();
            btnSave = new Button();
            label3 = new Label();
            label2 = new Label();
            label1 = new Label();
            txtPostName = new TextBox();
            cmbNumberPerPost = new ComboBox();
            SuspendLayout();
            // 
            // cmbSite
            // 
            cmbSite.FormattingEnabled = true;
            cmbSite.Location = new Point(429, 100);
            cmbSite.Name = "cmbSite";
            cmbSite.Size = new Size(121, 23);
            cmbSite.TabIndex = 66;
            // 
            // cmbStatus
            // 
            cmbStatus.FormattingEnabled = true;
            cmbStatus.Location = new Point(429, 62);
            cmbStatus.Name = "cmbStatus";
            cmbStatus.Size = new Size(121, 23);
            cmbStatus.TabIndex = 65;
            // 
            // comboBoxSecurityCompany
            // 
            comboBoxSecurityCompany.FormattingEnabled = true;
            comboBoxSecurityCompany.Location = new Point(429, 12);
            comboBoxSecurityCompany.Name = "comboBoxSecurityCompany";
            comboBoxSecurityCompany.Size = new Size(121, 23);
            comboBoxSecurityCompany.TabIndex = 64;
            comboBoxSecurityCompany.SelectedIndexChanged += comboBoxSecurityCompany_SelectedIndexChanged;
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Location = new Point(309, 62);
            label5.Name = "label5";
            label5.Size = new Size(39, 15);
            label5.TabIndex = 63;
            label5.Text = "Status";
            // 
            // label6
            // 
            label6.Location = new Point(308, 15);
            label6.Name = "label6";
            label6.Size = new Size(100, 23);
            label6.TabIndex = 67;
            label6.Text = "Company";
            // 
            // btnCancel
            // 
            btnCancel.Location = new Point(342, 292);
            btnCancel.Name = "btnCancel";
            btnCancel.Size = new Size(75, 23);
            btnCancel.TabIndex = 62;
            btnCancel.Text = "Cancel";
            btnCancel.UseVisualStyleBackColor = true;
            btnCancel.Click += btnCancel_Click_1;
            // 
            // btnSave
            // 
            btnSave.Location = new Point(89, 292);
            btnSave.Name = "btnSave";
            btnSave.Size = new Size(75, 23);
            btnSave.TabIndex = 61;
            btnSave.Text = "Save";
            btnSave.UseVisualStyleBackColor = true;
            btnSave.Click += btnSave_Click_1;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(32, 62);
            label3.Name = "label3";
            label3.Size = new Size(97, 15);
            label3.TabIndex = 60;
            label3.Text = "Number Per Post";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(308, 103);
            label2.Name = "label2";
            label2.Size = new Size(26, 15);
            label2.TabIndex = 59;
            label2.Text = "Site";
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(32, 12);
            label1.Name = "label1";
            label1.Size = new Size(63, 15);
            label1.TabIndex = 58;
            label1.Text = "Post name";
            // 
            // txtPostName
            // 
            txtPostName.Location = new Point(174, 12);
            txtPostName.Name = "txtPostName";
            txtPostName.Size = new Size(100, 23);
            txtPostName.TabIndex = 56;
            // 
            // cmbNumberPerPost
            // 
            cmbNumberPerPost.FormattingEnabled = true;
            cmbNumberPerPost.Location = new Point(174, 54);
            cmbNumberPerPost.Name = "cmbNumberPerPost";
            cmbNumberPerPost.Size = new Size(100, 23);
            cmbNumberPerPost.TabIndex = 68;
            // 
            // AddPostForm
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.FromArgb(31, 45, 61);
            ClientSize = new Size(800, 450);
            Controls.Add(cmbNumberPerPost);
            Controls.Add(cmbSite);
            Controls.Add(cmbStatus);
            Controls.Add(comboBoxSecurityCompany);
            Controls.Add(label5);
            Controls.Add(label6);
            Controls.Add(btnCancel);
            Controls.Add(btnSave);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(label1);
            Controls.Add(txtPostName);
            Name = "AddPostForm";
            Text = "AddPostForm";
            Load += AddPostForm_Load;
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private ComboBox cmbSite;
        private ComboBox cmbStatus;
        private ComboBox comboBoxSecurityCompany;
        private Label label5;
        private Label label6;
        private Button btnCancel;
        private Button btnSave;
        private Label label3;
        private Label label2;
        private Label label1;
        private TextBox txtPostName;
        private ComboBox cmbNumberPerPost;
    }
}