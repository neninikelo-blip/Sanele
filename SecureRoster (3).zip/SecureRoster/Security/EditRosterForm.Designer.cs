﻿namespace Security
{
    partial class EditRosterForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            label7 = new Label();
            label5 = new Label();
            label3 = new Label();
            label4 = new Label();
            cmbStatus = new ComboBox();
            txtRosterName = new TextBox();
            dtpEndDate = new DateTimePicker();
            dtpStartDate = new DateTimePicker();
            label2 = new Label();
            label1 = new Label();
            btnCancel = new Button();
            btnSave = new Button();
            cmbSupervisor = new ComboBox();
            cmbSite = new ComboBox();
            SuspendLayout();
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Location = new Point(164, 207);
            label7.Name = "label7";
            label7.Size = new Size(39, 15);
            label7.TabIndex = 28;
            label7.Text = "Status";
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Location = new Point(174, 142);
            label5.Name = "label5";
            label5.Size = new Size(75, 15);
            label5.TabIndex = 27;
            label5.Text = "Roster Name";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(338, 89);
            label3.Name = "label3";
            label3.Size = new Size(54, 15);
            label3.TabIndex = 26;
            label3.Text = "End Date";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new Point(338, 20);
            label4.Name = "label4";
            label4.Size = new Size(58, 15);
            label4.TabIndex = 25;
            label4.Text = "Start Date";
            // 
            // cmbStatus
            // 
            cmbStatus.FormattingEnabled = true;
            cmbStatus.Location = new Point(284, 199);
            cmbStatus.Name = "cmbStatus";
            cmbStatus.Size = new Size(121, 23);
            cmbStatus.TabIndex = 24;
            // 
            // txtRosterName
            // 
            txtRosterName.Location = new Point(283, 134);
            txtRosterName.Name = "txtRosterName";
            txtRosterName.Size = new Size(100, 23);
            txtRosterName.TabIndex = 23;
            // 
            // dtpEndDate
            // 
            dtpEndDate.Location = new Point(415, 89);
            dtpEndDate.Name = "dtpEndDate";
            dtpEndDate.Size = new Size(200, 23);
            dtpEndDate.TabIndex = 22;
            // 
            // dtpStartDate
            // 
            dtpStartDate.Location = new Point(415, 12);
            dtpStartDate.Name = "dtpStartDate";
            dtpStartDate.Size = new Size(200, 23);
            dtpStartDate.TabIndex = 21;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(11, 62);
            label2.Name = "label2";
            label2.Size = new Size(62, 15);
            label2.TabIndex = 20;
            label2.Text = "Supervisor";
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(47, 22);
            label1.Name = "label1";
            label1.Size = new Size(26, 15);
            label1.TabIndex = 19;
            label1.Text = "Site";
            // 
            // btnCancel
            // 
            btnCancel.Location = new Point(248, 299);
            btnCancel.Name = "btnCancel";
            btnCancel.Size = new Size(75, 23);
            btnCancel.TabIndex = 18;
            btnCancel.Text = "Cancel";
            btnCancel.UseVisualStyleBackColor = true;
            btnCancel.Click += btnCancel_Click;
            // 
            // btnSave
            // 
            btnSave.Location = new Point(47, 299);
            btnSave.Name = "btnSave";
            btnSave.Size = new Size(75, 23);
            btnSave.TabIndex = 17;
            btnSave.Text = "Save";
            btnSave.UseVisualStyleBackColor = true;
            btnSave.Click += btnSave_Click;
            // 
            // cmbSupervisor
            // 
            cmbSupervisor.FormattingEnabled = true;
            cmbSupervisor.Location = new Point(108, 62);
            cmbSupervisor.Name = "cmbSupervisor";
            cmbSupervisor.Size = new Size(121, 23);
            cmbSupervisor.TabIndex = 16;
            // 
            // cmbSite
            // 
            cmbSite.FormattingEnabled = true;
            cmbSite.Location = new Point(108, 12);
            cmbSite.Name = "cmbSite";
            cmbSite.Size = new Size(121, 23);
            cmbSite.TabIndex = 15;
            // 
            // EditRosterForm
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.FromArgb(31, 45, 61);
            ClientSize = new Size(619, 331);
            Controls.Add(label7);
            Controls.Add(label5);
            Controls.Add(label3);
            Controls.Add(label4);
            Controls.Add(cmbStatus);
            Controls.Add(txtRosterName);
            Controls.Add(dtpEndDate);
            Controls.Add(dtpStartDate);
            Controls.Add(label2);
            Controls.Add(label1);
            Controls.Add(btnCancel);
            Controls.Add(btnSave);
            Controls.Add(cmbSupervisor);
            Controls.Add(cmbSite);
            Name = "EditRosterForm";
            Text = "EditRosterForm";
            Load += EditRosterForm_Load;
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label7;
        private Label label5;
        private Label label3;
        private Label label4;
        private ComboBox cmbStatus;
        private TextBox txtRosterName;
        private DateTimePicker dtpEndDate;
        private DateTimePicker dtpStartDate;
        private Label label2;
        private Label label1;
        private Button btnCancel;
        private Button btnSave;
        private ComboBox cmbSupervisor;
        private ComboBox cmbSite;
    }
}