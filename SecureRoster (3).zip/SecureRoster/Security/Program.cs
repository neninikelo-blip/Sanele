using System;
using System.Windows.Forms;

namespace Security


{
    internal static class Program
    {
        /// <summary>
        ///  The main entry point for the application.
        /// </summary>
        [STAThread]
        static void Main()
        {
            // To customize application configuration such as set high DPI settings or default font,
            // see https://aka.ms/applicationconfiguration.
            ApplicationConfiguration.Initialize();

            // TEMPORARY — remove after running once
            //SeedAdmin.CreateFirstAccounts();   // note the plural name

            Application.Run(new LoginForm());
        }
    }
}