﻿namespace Security
{
    partial class ManagerJB
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(ManagerJB));
            btnEdit = new Button();
            btnAdd = new Button();
            dataGridView1 = new DataGridView();
            panel2 = new Panel();
            button16 = new Button();
            button15 = new Button();
            button10 = new Button();
            button9 = new Button();
            btnBack = new Button();
            button12 = new Button();
            button13 = new Button();
            button2 = new Button();
            button11 = new Button();
            button8 = new Button();
            button3 = new Button();
            button7 = new Button();
            button4 = new Button();
            button6 = new Button();
            button5 = new Button();
            panel1 = new Panel();
            pictureBox1 = new PictureBox();
            label1 = new Label();
            btnSave = new Button();
            lblUsername = new Label();
            lblRole = new Label();
            btnDelete = new Button();
            ((System.ComponentModel.ISupportInitialize)dataGridView1).BeginInit();
            panel2.SuspendLayout();
            panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            SuspendLayout();
            // 
            // btnEdit
            // 
            btnEdit.BackColor = Color.FromArgb(192, 192, 255);
            btnEdit.FlatStyle = FlatStyle.Flat;
            btnEdit.Location = new Point(554, 128);
            btnEdit.Name = "btnEdit";
            btnEdit.Size = new Size(189, 33);
            btnEdit.TabIndex = 17;
            btnEdit.Text = "Edit";
            btnEdit.UseVisualStyleBackColor = false;
            btnEdit.Click += btnEdit_Click;
            // 
            // btnAdd
            // 
            btnAdd.BackColor = SystemColors.ActiveCaption;
            btnAdd.FlatStyle = FlatStyle.Flat;
            btnAdd.Location = new Point(217, 131);
            btnAdd.Name = "btnAdd";
            btnAdd.Size = new Size(189, 33);
            btnAdd.TabIndex = 16;
            btnAdd.Text = "Add";
            btnAdd.UseVisualStyleBackColor = false;
            btnAdd.Click += btnAdd_Click_1;
            // 
            // dataGridView1
            // 
            dataGridView1.BackgroundColor = Color.FromArgb(31, 45, 61);
            dataGridView1.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridView1.Location = new Point(217, 170);
            dataGridView1.Name = "dataGridView1";
            dataGridView1.Size = new Size(847, 479);
            dataGridView1.TabIndex = 15;
            dataGridView1.CellContentClick += dataGridView1_CellContentClick_1;
            // 
            // panel2
            // 
            panel2.Controls.Add(button16);
            panel2.Controls.Add(button15);
            panel2.Controls.Add(button10);
            panel2.Controls.Add(button9);
            panel2.Controls.Add(btnBack);
            panel2.Controls.Add(button12);
            panel2.Controls.Add(button13);
            panel2.Controls.Add(button2);
            panel2.Controls.Add(button11);
            panel2.Controls.Add(button8);
            panel2.Controls.Add(button3);
            panel2.Controls.Add(button7);
            panel2.Controls.Add(button4);
            panel2.Controls.Add(button6);
            panel2.Controls.Add(button5);
            panel2.Location = new Point(2, 125);
            panel2.Name = "panel2";
            panel2.Size = new Size(200, 580);
            panel2.TabIndex = 14;
            // 
            // button16
            // 
            button16.BackColor = Color.White;
            button16.FlatStyle = FlatStyle.Flat;
            button16.Location = new Point(3, 42);
            button16.Name = "button16";
            button16.Size = new Size(189, 33);
            button16.TabIndex = 14;
            button16.Text = "Security Companies   >";
            button16.TextAlign = ContentAlignment.MiddleLeft;
            button16.UseVisualStyleBackColor = false;
            button16.Click += button16_Click;
            // 
            // button15
            // 
            button15.BackColor = Color.White;
            button15.FlatStyle = FlatStyle.Flat;
            button15.Location = new Point(3, 427);
            button15.Name = "button15";
            button15.Size = new Size(189, 33);
            button15.TabIndex = 9;
            button15.Text = "Attendances   >";
            button15.TextAlign = ContentAlignment.MiddleLeft;
            button15.UseVisualStyleBackColor = false;
            button15.Click += button15_Click_1;
            // 
            // button10
            // 
            button10.BackColor = Color.White;
            button10.FlatStyle = FlatStyle.Flat;
            button10.Location = new Point(3, 155);
            button10.Name = "button10";
            button10.Size = new Size(189, 33);
            button10.TabIndex = 13;
            button10.Text = "Supervisors   >";
            button10.TextAlign = ContentAlignment.MiddleLeft;
            button10.UseVisualStyleBackColor = false;
            button10.Click += button10_Click_1;
            // 
            // button9
            // 
            button9.BackColor = Color.White;
            button9.FlatStyle = FlatStyle.Flat;
            button9.Location = new Point(3, 81);
            button9.Name = "button9";
            button9.Size = new Size(189, 33);
            button9.TabIndex = 12;
            button9.Text = "Client Companies     >";
            button9.TextAlign = ContentAlignment.MiddleLeft;
            button9.UseVisualStyleBackColor = false;
            button9.Click += button9_Click_1;
            // 
            // btnBack
            // 
            btnBack.Location = new Point(3, 3);
            btnBack.Name = "btnBack";
            btnBack.Size = new Size(46, 33);
            btnBack.TabIndex = 4;
            btnBack.Text = "<";
            btnBack.UseVisualStyleBackColor = true;
            btnBack.Click += btnBack_Click_1;
            // 
            // button12
            // 
            button12.BackColor = Color.White;
            button12.FlatStyle = FlatStyle.Flat;
            button12.Location = new Point(3, 505);
            button12.Name = "button12";
            button12.Size = new Size(189, 33);
            button12.TabIndex = 6;
            button12.Text = "Leave Applications   >";
            button12.TextAlign = ContentAlignment.MiddleLeft;
            button12.UseVisualStyleBackColor = false;
            button12.Click += button12_Click_1;
            // 
            // button13
            // 
            button13.BackColor = Color.White;
            button13.FlatStyle = FlatStyle.Flat;
            button13.Location = new Point(3, 544);
            button13.Name = "button13";
            button13.Size = new Size(189, 33);
            button13.TabIndex = 7;
            button13.Text = "My Profile   >";
            button13.TextAlign = ContentAlignment.MiddleLeft;
            button13.UseVisualStyleBackColor = false;
            button13.Click += button13_Click_1;
            // 
            // button2
            // 
            button2.BackColor = Color.White;
            button2.FlatStyle = FlatStyle.Flat;
            button2.Location = new Point(3, 118);
            button2.Name = "button2";
            button2.Size = new Size(189, 33);
            button2.TabIndex = 5;
            button2.Text = "Guards   >";
            button2.TextAlign = ContentAlignment.MiddleLeft;
            button2.UseVisualStyleBackColor = false;
            button2.Click += button2_Click_1;
            // 
            // button11
            // 
            button11.BackColor = Color.White;
            button11.FlatStyle = FlatStyle.Flat;
            button11.Location = new Point(3, 466);
            button11.Name = "button11";
            button11.Size = new Size(189, 33);
            button11.TabIndex = 5;
            button11.Text = "Type of Leaves   >";
            button11.TextAlign = ContentAlignment.MiddleLeft;
            button11.UseVisualStyleBackColor = false;
            button11.Click += button11_Click_1;
            // 
            // button8
            // 
            button8.BackColor = Color.White;
            button8.FlatStyle = FlatStyle.Flat;
            button8.Location = new Point(3, 388);
            button8.Name = "button8";
            button8.Size = new Size(189, 33);
            button8.TabIndex = 11;
            button8.Text = "Rosters   >";
            button8.TextAlign = ContentAlignment.MiddleLeft;
            button8.UseVisualStyleBackColor = false;
            button8.Click += button8_Click_1;
            // 
            // button3
            // 
            button3.BackColor = Color.White;
            button3.FlatStyle = FlatStyle.Flat;
            button3.Location = new Point(3, 194);
            button3.Name = "button3";
            button3.Size = new Size(189, 33);
            button3.TabIndex = 6;
            button3.Text = "Sites   >";
            button3.TextAlign = ContentAlignment.MiddleLeft;
            button3.UseVisualStyleBackColor = false;
            button3.Click += button3_Click_1;
            // 
            // button7
            // 
            button7.BackColor = Color.White;
            button7.FlatStyle = FlatStyle.Flat;
            button7.Location = new Point(3, 349);
            button7.Name = "button7";
            button7.Size = new Size(189, 33);
            button7.TabIndex = 10;
            button7.Text = "Special Shifts   >";
            button7.TextAlign = ContentAlignment.MiddleLeft;
            button7.UseVisualStyleBackColor = false;
            button7.Click += button7_Click_1;
            // 
            // button4
            // 
            button4.BackColor = Color.White;
            button4.FlatStyle = FlatStyle.Flat;
            button4.Location = new Point(3, 233);
            button4.Name = "button4";
            button4.Size = new Size(189, 33);
            button4.TabIndex = 7;
            button4.Text = "Posts    >";
            button4.TextAlign = ContentAlignment.MiddleLeft;
            button4.UseVisualStyleBackColor = false;
            button4.Click += button4_Click_1;
            // 
            // button6
            // 
            button6.BackColor = Color.White;
            button6.FlatStyle = FlatStyle.Flat;
            button6.Location = new Point(3, 310);
            button6.Name = "button6";
            button6.Size = new Size(189, 33);
            button6.TabIndex = 9;
            button6.Text = "Regular Shifts   >";
            button6.TextAlign = ContentAlignment.MiddleLeft;
            button6.UseVisualStyleBackColor = false;
            button6.Click += button6_Click_1;
            // 
            // button5
            // 
            button5.BackColor = Color.White;
            button5.FlatStyle = FlatStyle.Flat;
            button5.Location = new Point(3, 272);
            button5.Name = "button5";
            button5.Size = new Size(189, 33);
            button5.TabIndex = 8;
            button5.Text = "Type of Shifts   >";
            button5.TextAlign = ContentAlignment.MiddleLeft;
            button5.UseVisualStyleBackColor = false;
            button5.Click += button5_Click_1;
            // 
            // panel1
            // 
            panel1.Controls.Add(pictureBox1);
            panel1.Location = new Point(2, 2);
            panel1.Name = "panel1";
            panel1.Size = new Size(874, 117);
            panel1.TabIndex = 13;
            // 
            // pictureBox1
            // 
            pictureBox1.Dock = DockStyle.Fill;
            pictureBox1.Image = (Image)resources.GetObject("pictureBox1.Image");
            pictureBox1.Location = new Point(0, 0);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(874, 117);
            pictureBox1.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox1.TabIndex = 3;
            pictureBox1.TabStop = false;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(315, 35);
            label1.Name = "label1";
            label1.Size = new Size(38, 15);
            label1.TabIndex = 12;
            label1.Text = "label1";
            // 
            // btnSave
            // 
            btnSave.BackColor = SystemColors.ActiveCaption;
            btnSave.FlatStyle = FlatStyle.Flat;
            btnSave.Location = new Point(875, 128);
            btnSave.Name = "btnSave";
            btnSave.Size = new Size(189, 33);
            btnSave.TabIndex = 18;
            btnSave.Text = "Save";
            btnSave.UseVisualStyleBackColor = false;
            btnSave.Click += btnSave_Click;
            // 
            // lblUsername
            // 
            lblUsername.AutoSize = true;
            lblUsername.Font = new Font("Microsoft Sans Serif", 9.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            lblUsername.ForeColor = Color.White;
            lblUsername.Location = new Point(882, 9);
            lblUsername.Name = "lblUsername";
            lblUsername.Size = new Size(40, 16);
            lblUsername.TabIndex = 19;
            lblUsername.Text = "User";
            // 
            // lblRole
            // 
            lblRole.AutoSize = true;
            lblRole.Font = new Font("Microsoft Sans Serif", 8F);
            lblRole.ForeColor = Color.LightGray;
            lblRole.Location = new Point(882, 28);
            lblRole.Name = "lblRole";
            lblRole.Size = new Size(29, 13);
            lblRole.TabIndex = 20;
            lblRole.Text = "Role";
            // 
            // btnDelete
            // 
            btnDelete.BackColor = SystemColors.ActiveCaption;
            btnDelete.FlatStyle = FlatStyle.Flat;
            btnDelete.Location = new Point(554, 655);
            btnDelete.Name = "btnDelete";
            btnDelete.Size = new Size(189, 33);
            btnDelete.TabIndex = 19;
            btnDelete.Text = "Delete";
            btnDelete.UseVisualStyleBackColor = false;
            btnDelete.Click += btnDelete_Click;
            // 
            // ManagerJB
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.FromArgb(31, 45, 61);
            ClientSize = new Size(1066, 749);
            Controls.Add(btnDelete);
            Controls.Add(lblRole);
            Controls.Add(lblUsername);
            Controls.Add(btnSave);
            Controls.Add(btnEdit);
            Controls.Add(btnAdd);
            Controls.Add(dataGridView1);
            Controls.Add(panel2);
            Controls.Add(panel1);
            Controls.Add(label1);
            Name = "ManagerJB";
            Text = "ManagerJB";
            Load += ManagerJB_Load;
            ((System.ComponentModel.ISupportInitialize)dataGridView1).EndInit();
            panel2.ResumeLayout(false);
            panel1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion
        private Button btnEdit;
        private Button btnAdd;
        private DataGridView dataGridView1;
        private Panel panel2;
        private Button button15;
        private Button button10;
        private Button button1;
        private Button button13;
        private Button button9;
        private Button button12;
        private Button button2;
        private Button button11;
        private Button button8;
        private Button button3;
        private Button button7;
        private Button button4;
        private Button button6;
        private Button button5;
        private Panel panel1;
        private Label label1;
        private Button button16;
        private Button btnSave;
        private Label lblUsername;
        private Label lblRole;
        private PictureBox pictureBox1;
        private Button btnDelete;
        private Button btnBack;
    }
}