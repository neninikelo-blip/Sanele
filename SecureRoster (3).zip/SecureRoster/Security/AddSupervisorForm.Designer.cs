﻿namespace Security
{
    partial class AddSupervisorForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            comboBoxSite = new ComboBox();
            label9 = new Label();
            txtIDNumber = new TextBox();
            label8 = new Label();
            txtCell = new TextBox();
            label4 = new Label();
            label7 = new Label();
            txtUsername = new TextBox();
            txtEmail = new TextBox();
            comboBoxSuburb = new ComboBox();
            label5 = new Label();
            label6 = new Label();
            btnCancel = new Button();
            btnSave = new Button();
            label3 = new Label();
            label2 = new Label();
            label1 = new Label();
            txtLastName = new TextBox();
            txtFirstName = new TextBox();
            label10 = new Label();
            txtPassword = new TextBox();
            cmbGender = new ComboBox();
            SuspendLayout();
            // 
            // comboBoxSite
            // 
            comboBoxSite.FormattingEnabled = true;
            comboBoxSite.Location = new Point(427, 189);
            comboBoxSite.Name = "comboBoxSite";
            comboBoxSite.Size = new Size(121, 23);
            comboBoxSite.TabIndex = 85;
            // 
            // label9
            // 
            label9.AutoSize = true;
            label9.Location = new Point(306, 192);
            label9.Name = "label9";
            label9.Size = new Size(31, 15);
            label9.TabIndex = 84;
            label9.Text = "Sites";
            // 
            // txtIDNumber
            // 
            txtIDNumber.Location = new Point(427, 106);
            txtIDNumber.Name = "txtIDNumber";
            txtIDNumber.Size = new Size(100, 23);
            txtIDNumber.TabIndex = 83;
            // 
            // label8
            // 
            label8.AutoSize = true;
            label8.Location = new Point(307, 106);
            label8.Name = "label8";
            label8.Size = new Size(65, 15);
            label8.TabIndex = 82;
            label8.Text = "ID Number";
            // 
            // txtCell
            // 
            txtCell.Location = new Point(427, 62);
            txtCell.Name = "txtCell";
            txtCell.Size = new Size(100, 23);
            txtCell.TabIndex = 81;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new Point(30, 153);
            label4.Name = "label4";
            label4.Size = new Size(60, 15);
            label4.TabIndex = 80;
            label4.Text = "Username";
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Location = new Point(30, 103);
            label7.Name = "label7";
            label7.Size = new Size(45, 15);
            label7.TabIndex = 79;
            label7.Text = "Gender";
            // 
            // txtUsername
            // 
            txtUsername.Location = new Point(172, 150);
            txtUsername.Name = "txtUsername";
            txtUsername.Size = new Size(100, 23);
            txtUsername.TabIndex = 78;
            // 
            // txtEmail
            // 
            txtEmail.Location = new Point(427, 9);
            txtEmail.Name = "txtEmail";
            txtEmail.Size = new Size(100, 23);
            txtEmail.TabIndex = 76;
            // 
            // comboBoxSuburb
            // 
            comboBoxSuburb.FormattingEnabled = true;
            comboBoxSuburb.Location = new Point(427, 145);
            comboBoxSuburb.Name = "comboBoxSuburb";
            comboBoxSuburb.Size = new Size(121, 23);
            comboBoxSuburb.TabIndex = 74;
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Location = new Point(307, 62);
            label5.Name = "label5";
            label5.Size = new Size(74, 15);
            label5.TabIndex = 73;
            label5.Text = "Cell Number";
            // 
            // label6
            // 
            label6.Location = new Point(306, 15);
            label6.Name = "label6";
            label6.Size = new Size(100, 23);
            label6.TabIndex = 75;
            label6.Text = "Email";
            // 
            // btnCancel
            // 
            btnCancel.Location = new Point(340, 292);
            btnCancel.Name = "btnCancel";
            btnCancel.Size = new Size(75, 23);
            btnCancel.TabIndex = 72;
            btnCancel.Text = "Cancel";
            btnCancel.UseVisualStyleBackColor = true;
            btnCancel.Click += btnCancel_Click_1;
            // 
            // btnSave
            // 
            btnSave.Location = new Point(87, 292);
            btnSave.Name = "btnSave";
            btnSave.Size = new Size(75, 23);
            btnSave.TabIndex = 71;
            btnSave.Text = "Save";
            btnSave.UseVisualStyleBackColor = true;
            btnSave.Click += btnSave_Click_1;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(30, 62);
            label3.Name = "label3";
            label3.Size = new Size(63, 15);
            label3.TabIndex = 70;
            label3.Text = "Last Name";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(306, 148);
            label2.Name = "label2";
            label2.Size = new Size(45, 15);
            label2.TabIndex = 69;
            label2.Text = "Suburb";
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(30, 12);
            label1.Name = "label1";
            label1.Size = new Size(62, 15);
            label1.TabIndex = 68;
            label1.Text = "First name";
            // 
            // txtLastName
            // 
            txtLastName.Location = new Point(172, 59);
            txtLastName.Name = "txtLastName";
            txtLastName.Size = new Size(100, 23);
            txtLastName.TabIndex = 67;
            // 
            // txtFirstName
            // 
            txtFirstName.Location = new Point(172, 12);
            txtFirstName.Name = "txtFirstName";
            txtFirstName.Size = new Size(100, 23);
            txtFirstName.TabIndex = 66;
            // 
            // label10
            // 
            label10.AutoSize = true;
            label10.Location = new Point(30, 195);
            label10.Name = "label10";
            label10.Size = new Size(57, 15);
            label10.TabIndex = 87;
            label10.Text = "Password";
            // 
            // txtPassword
            // 
            txtPassword.Location = new Point(172, 192);
            txtPassword.Name = "txtPassword";
            txtPassword.Size = new Size(100, 23);
            txtPassword.TabIndex = 86;
            // 
            // cmbGender
            // 
            cmbGender.FormattingEnabled = true;
            cmbGender.Location = new Point(172, 106);
            cmbGender.Name = "cmbGender";
            cmbGender.Size = new Size(100, 23);
            cmbGender.TabIndex = 88;
            // 
            // AddSupervisorForm
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.FromArgb(31, 45, 61);
            ClientSize = new Size(585, 362);
            Controls.Add(cmbGender);
            Controls.Add(label10);
            Controls.Add(txtPassword);
            Controls.Add(comboBoxSite);
            Controls.Add(label9);
            Controls.Add(txtIDNumber);
            Controls.Add(label8);
            Controls.Add(txtCell);
            Controls.Add(label4);
            Controls.Add(label7);
            Controls.Add(txtUsername);
            Controls.Add(txtEmail);
            Controls.Add(comboBoxSuburb);
            Controls.Add(label5);
            Controls.Add(label6);
            Controls.Add(btnCancel);
            Controls.Add(btnSave);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(label1);
            Controls.Add(txtLastName);
            Controls.Add(txtFirstName);
            Name = "AddSupervisorForm";
            Text = "AddSupervisorForm";
            Load += AddSupervisorForm_Load;
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private ComboBox comboBoxSite;
        private Label label9;
        private TextBox txtIDNumber;
        private Label label8;
        private TextBox txtCell;
        private Label label4;
        private Label label7;
        private TextBox txtUsername;
        private TextBox txtEmail;
        private ComboBox comboBoxSuburb;
        private Label label5;
        private Label label6;
        private Button btnCancel;
        private Button btnSave;
        private Label label3;
        private Label label2;
        private Label label1;
        private TextBox txtLastName;
        private TextBox txtFirstName;
        private Label label10;
        private TextBox txtPassword;
        private ComboBox cmbGender;
    }
}