﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using Microsoft.Data.SqlClient;
namespace Security
{
    public partial class EditAttendanceForm : Form
    {
        SqlConnection con = new SqlConnection(
            "Data Source=DESKTOP-133OPA4\\SQLEXPRESS;" +
            "Initial Catalog=SecureRoster;" +
            "Integrated Security=True;" +
            "Encrypt=False;");
        private int attendanceID;
        public EditAttendanceForm(int id)
        {
            InitializeComponent();
            attendanceID = id;
        }

        private void EditAttendanceForm_Load(object sender, EventArgs e)
        {
            string[] times = { "00H00", "06H00", "06H03", "12H00", "18H00", "18H03" };
            cmbCheckIn.Items.Clear(); cmbCheckIn.Items.AddRange(times);
            cmbCheckOut.Items.Clear(); cmbCheckOut.Items.AddRange(times);

            cmbStatus.Items.Clear();
            cmbStatus.Items.AddRange(new object[] { "P", "A", "L" });
            cmbStatus.DropDownStyle = ComboBoxStyle.DropDownList;
            DataTable dt = new DataTable();
            new SqlDataAdapter(
                @"SELECT rsa.AssignmentID,
                         p.FirstName + ' ' + p.LastName + ' | ' + rs.NameOfShift AS Label
                  FROM RegularShiftsAssignments rsa
                  INNER JOIN Guards g ON rsa.GuardID = g.GuardID
                  INNER JOIN Persons p ON g.PersonID = p.PersonID
                  INNER JOIN RegularShifts rs ON rsa.RegularShiftID = rs.RegularShiftID",
                con).Fill(dt);

            cmbAssignment.DataSource = dt;
            cmbAssignment.DisplayMember = "Label";
            cmbAssignment.ValueMember = "AssignmentID";

            try
            {
                con.Open();
                SqlCommand cmd = new SqlCommand(
                    @"SELECT CheckInTime, CheckOutTime, AttendanceStatus, AssignmentID
                      FROM Attendances WHERE AttendanceID = @id", con);
                cmd.Parameters.AddWithValue("@id", attendanceID);

                SqlDataReader dr = cmd.ExecuteReader();
                if (dr.Read())
                {
                    cmbCheckIn.Text = dr["CheckInTime"].ToString();   
                    cmbCheckOut.Text = dr["CheckOutTime"].ToString();  
                    cmbStatus.Text = dr["AttendanceStatus"].ToString();
                    if (dr["AssignmentID"] != DBNull.Value)
                        cmbAssignment.SelectedValue = Convert.ToInt32(dr["AssignmentID"]);
                }
                dr.Close();
                con.Close();
            }
            catch (Exception ex) { MessageBox.Show(ex.Message); }
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            if (cmbAssignment.SelectedValue == null ||
                cmbAssignment.SelectedValue is DataRowView) return;

            if (cmbCheckIn.Text == cmbCheckOut.Text)
            {
                MessageBox.Show("Check-In time and Check-Out time cannot be the same.");
                return;
            }

            try
            {
                con.Open();

            
                // Validating that the assignment actually exists
                SqlCommand checkCmd = new SqlCommand("SELECT COUNT(*) FROM RegularShiftsAssignments WHERE AssignmentID = @aid", con);
                checkCmd.Parameters.AddWithValue("@aid", cmbAssignment.SelectedValue);
                int exists = Convert.ToInt32(checkCmd.ExecuteScalar());

                if (exists == 0)
                {
                    MessageBox.Show("Invalid assignment selected.");
                    con.Close();
                    return;
                }

                SqlCommand cmd = new SqlCommand(
                    @"UPDATE Attendances
              SET CheckInTime      = @in,
                  CheckOutTime     = @out,
                  AttendanceStatus = @status,
                  AssignmentID     = @assignment
              WHERE AttendanceID = @id", con);

                cmd.Parameters.AddWithValue("@in", cmbCheckIn.Text);
                cmd.Parameters.AddWithValue("@out", cmbCheckOut.Text);
                cmd.Parameters.AddWithValue("@status", cmbStatus.Text);
                cmd.Parameters.AddWithValue("@assignment", cmbAssignment.SelectedValue);
                cmd.Parameters.AddWithValue("@id", attendanceID);

                cmd.ExecuteNonQuery();

                MessageBox.Show("Attendance Updated");
                con.Close();
                this.Close();
            }
            catch (Exception ex) { MessageBox.Show(ex.Message); }
         }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
/**/