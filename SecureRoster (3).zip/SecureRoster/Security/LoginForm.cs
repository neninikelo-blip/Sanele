﻿using System;
using System.Data;
using System.Windows.Forms;
using Microsoft.Data.SqlClient;

namespace Security
{
    public partial class LoginForm : Form
    {
        //  SqlConnection con = new SqlConnection( "Data Source=DESKTOP-133OPA4\\SQLEXPRESS;" + "Initial Catalog=SecureRoster;" + "Integrated Security=True;" +"Encrypt=False;");
        SqlConnection con = new SqlConnection("Data Source=DESKTOP-133OPA4\\SQLEXPRESS;" + "Initial Catalog=SecureRoster;" + "Integrated Security=True;" + "Encrypt=False;" + "Connect Timeout=60;");

        public LoginForm()
        {
            InitializeComponent();
        }

        private void LoginForm_Load(object sender, EventArgs e)
        {
            cmbRole.Items.Clear();
            cmbRole.Items.Add("Guard");
            cmbRole.Items.Add("Supervisor");
            cmbRole.Items.Add("Manager");
            cmbRole.Items.Add("ITAdmin");
            cmbRole.SelectedIndex = 0;
        }





        private void btnLogin_Click_1(object sender, EventArgs e)
        {
            string username = txtUsername.Text.Trim();
            string password = txtPassword.Text;
            string role = cmbRole.Text;

            if (username == "" || password == "")
            {
                MessageBox.Show("Please enter username and password.");
                return;
            }

            try
            {
                con.Open();

                SqlCommand cmd = new SqlCommand(
                    @"SELECT AccountID, PersonID,
                     PasswordSalt, PasswordHash, Role_
              FROM Accounts
              WHERE Username = @user", con);

                cmd.Parameters.AddWithValue("@user", username);

                SqlDataReader dr = cmd.ExecuteReader();

                if (!dr.Read())
                {
                    MessageBox.Show("User not found.");
                    dr.Close();
                    con.Close();
                    return;
                }

                int accountID = Convert.ToInt32(dr["AccountID"]);
                int personID = Convert.ToInt32(dr["PersonID"]);
                string storedSalt = dr["PasswordSalt"].ToString() ?? "";
                string storedHash = dr["PasswordHash"].ToString() ?? "";
                string storedRole = dr["Role_"].ToString() ?? "";

                dr.Close();
                con.Close();

                if (!PasswordHasher.Verify(password, storedSalt, storedHash))
                {
                    MessageBox.Show("Incorrect password.");
                    return;
                }

                if (!string.Equals(storedRole, role, StringComparison.OrdinalIgnoreCase))
                {
                    MessageBox.Show("You are not registered under that role.");
                    return;
                }

                // ---- Fill the Session ----
                Session.AccountID = accountID;
                Session.PersonID = personID;
                Session.Username = username;
                Session.Role = storedRole;

                // ---- Lookup the role-specific IDs (THIS is the missing part) ----
                con.Open();

                if (storedRole == "Guard")
                {
                    SqlCommand g = new SqlCommand(
                        "SELECT GuardID, SiteID FROM Guards WHERE PersonID = @pid", con);
                    g.Parameters.AddWithValue("@pid", personID);

                    SqlDataReader gdr = g.ExecuteReader();
                    if (gdr.Read())
                    {
                        Session.GuardID = Convert.ToInt32(gdr["GuardID"]);
                        Session.SiteID = Convert.ToInt32(gdr["SiteID"]);
                    }
                    gdr.Close();
                }
                else if (storedRole == "Supervisor")
                {
                    SqlCommand s = new SqlCommand(
                        "SELECT SupervisorID, SiteID FROM Supervisors WHERE PersonID = @pid", con);
                    s.Parameters.AddWithValue("@pid", personID);

                    SqlDataReader sdr = s.ExecuteReader();
                    if (sdr.Read())
                    {
                        Session.SupervisorID = Convert.ToInt32(sdr["SupervisorID"]);
                        Session.SiteID = Convert.ToInt32(sdr["SiteID"]);
                    }
                    sdr.Close();
                }
                else if (storedRole == "Manager")
                {
                    SqlCommand m = new SqlCommand(
                        "SELECT ManagerID, CompanyID FROM Managers WHERE PersonID = @pid", con);
                    m.Parameters.AddWithValue("@pid", personID);

                    SqlDataReader mdr = m.ExecuteReader();
                    if (mdr.Read())
                    {
                        Session.ManagerID = Convert.ToInt32(mdr["ManagerID"]);
                        Session.CompanyID = Convert.ToInt32(mdr["CompanyID"]);
                    }
                    mdr.Close();
                }
                else if (storedRole == "ITAdmin")
                {
                    SqlCommand it = new SqlCommand(
                        "SELECT ITAdminID, CompanyID FROM ITAdmins WHERE PersonID = @pid", con);
                    it.Parameters.AddWithValue("@pid", personID);

                    SqlDataReader idr = it.ExecuteReader();
                    if (idr.Read())
                    {
                        Session.ITAdminID = Convert.ToInt32(idr["ITAdminID"]);
                        Session.CompanyID = Convert.ToInt32(idr["CompanyID"]);
                    }
                    idr.Close();
                }

                con.Close();

                // ---- Route to the correct dashboard ----
                if (storedRole == "Manager") new ManagerJB().Show();
                else if (storedRole == "Supervisor") new SupervisorJB().Show();
                else if (storedRole == "ITAdmin") new ITAdminForm().Show();
                else new GuardJB1().Show();

                this.Hide();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        
        }

        private void btnCancel_Click_1(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void chkShowPassword_CheckedChanged(object sender, EventArgs e)
        {

            if (chkShowPassword.Checked)
            {
                // Show plain text
                txtPassword.UseSystemPasswordChar = false;
                txtPassword.PasswordChar = '\0';   // no masking character
            }
            else
            {
                // Hide again
                txtPassword.UseSystemPasswordChar = true;
            }
        }
    
    }
}