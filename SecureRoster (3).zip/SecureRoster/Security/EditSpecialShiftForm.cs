﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using Microsoft.Data.SqlClient;
namespace Security
{
    public partial class EditSpecialShiftForm : Form
    {
        private int specialShiftID;
        public EditSpecialShiftForm(int id)
        {
            InitializeComponent();
            specialShiftID = id;
        }
        SqlConnection con = new SqlConnection(
           "Data Source=DESKTOP-133OPA4\\SQLEXPRESS;" +
           "Initial Catalog=SecureRoster;" +
           "Integrated Security=True;" +
           "Encrypt=False;");

        private void EditSpecialShiftForm_Load(object sender, EventArgs e)
        {
            DataTable dtPost = new DataTable();
            new SqlDataAdapter("SELECT PostID, PostName FROM Posts", con).Fill(dtPost);
            cmbPost.DataSource = dtPost;
            cmbPost.DisplayMember = "PostName";
            cmbPost.ValueMember = "PostID";
            string[] times = { "00H00", "06H00", "12H00", "18H00", "22H00", "23H59" };
            cmbStartTime.Items.Clear(); cmbStartTime.Items.AddRange(times);
            cmbEndTime.Items.Clear(); cmbEndTime.Items.AddRange(times);
            try
            {
                con.Open();
                SqlCommand cmd = new SqlCommand(
                    @"SELECT PostID, NameOfShift, StartTime, EndTime, SpecialShiftDate
                      FROM SpecialShifts WHERE SpecialShiftID = @id", con);
                cmd.Parameters.AddWithValue("@id", specialShiftID);

                SqlDataReader dr = cmd.ExecuteReader();
                if (dr.Read())
                {
                    txtNameOfShift.Text = dr["NameOfShift"].ToString();
                    cmbStartTime.Text = dr["StartTime"].ToString();
                    cmbEndTime.Text = dr["EndTime"].ToString();
                    dtpSpecialShiftDate.Value = Convert.ToDateTime(dr["SpecialShiftDate"]);
                    cmbPost.SelectedValue = Convert.ToInt32(dr["PostID"]);
                }
                dr.Close();
                con.Close();
            }
            catch (Exception ex) { MessageBox.Show(ex.Message); }
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            if (cmbPost.SelectedValue == null ||
             cmbPost.SelectedValue is DataRowView) return;

            try
            {
                con.Open();
                SqlCommand cmd = new SqlCommand(
                    @"UPDATE SpecialShifts
                      SET PostID            = @post,
                          NameOfShift       = @name,
                          StartTime         = @start,
                          EndTime           = @end,
                          SpecialShiftDate  = @date
                      WHERE SpecialShiftID = @id", con);

                cmd.Parameters.AddWithValue("@post", cmbPost.SelectedValue);
                cmd.Parameters.AddWithValue("@name", txtNameOfShift.Text);
                cmd.Parameters.AddWithValue("@start", cmbStartTime.Text);
                cmd.Parameters.AddWithValue("@end", cmbEndTime.Text);
                cmd.Parameters.AddWithValue("@date", dtpSpecialShiftDate.Value.Date);
                cmd.Parameters.AddWithValue("@id", specialShiftID);

                cmd.ExecuteNonQuery();

                MessageBox.Show("Special Shift Updated");
                con.Close();
                this.Close();
            }
            catch (Exception ex) { MessageBox.Show(ex.Message); }
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
/*

        private void EditSpecialShiftForm_Load(object sender, EventArgs e)
        {
           
        }

        private void btnSave_Click_1(object sender, EventArgs e)
        {
         
        }

        private void btnCancel_Click_1(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}*/