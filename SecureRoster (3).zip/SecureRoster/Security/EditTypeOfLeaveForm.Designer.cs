﻿namespace Security
{
    partial class EditTypeOfLeaveForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            btnCancel = new Button();
            btnSave = new Button();
            label3 = new Label();
            label1 = new Label();
            txtMaxDuration = new TextBox();
            txtTypeOfLeave = new TextBox();
            SuspendLayout();
            // 
            // btnCancel
            // 
            btnCancel.Location = new Point(256, 211);
            btnCancel.Name = "btnCancel";
            btnCancel.Size = new Size(75, 23);
            btnCancel.TabIndex = 60;
            btnCancel.Text = "Cancel";
            btnCancel.UseVisualStyleBackColor = true;
            btnCancel.Click += btnCancel_Click;
            // 
            // btnSave
            // 
            btnSave.Location = new Point(3, 211);
            btnSave.Name = "btnSave";
            btnSave.Size = new Size(75, 23);
            btnSave.TabIndex = 59;
            btnSave.Text = "Save";
            btnSave.UseVisualStyleBackColor = true;
            btnSave.Click += btnSave_Click;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(6, 62);
            label3.Name = "label3";
            label3.Size = new Size(82, 15);
            label3.TabIndex = 58;
            label3.Text = "Mximum days";
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(6, 12);
            label1.Name = "label1";
            label1.Size = new Size(84, 15);
            label1.TabIndex = 57;
            label1.Text = "Type of Leaves";
            // 
            // txtMaxDuration
            // 
            txtMaxDuration.Location = new Point(148, 59);
            txtMaxDuration.Name = "txtMaxDuration";
            txtMaxDuration.Size = new Size(100, 23);
            txtMaxDuration.TabIndex = 56;
            // 
            // txtTypeOfLeave
            // 
            txtTypeOfLeave.Location = new Point(148, 12);
            txtTypeOfLeave.Name = "txtTypeOfLeave";
            txtTypeOfLeave.Size = new Size(100, 23);
            txtTypeOfLeave.TabIndex = 55;
            // 
            // EditTypeOfLeaveForm
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.FromArgb(31, 45, 61);
            ClientSize = new Size(337, 256);
            Controls.Add(btnCancel);
            Controls.Add(btnSave);
            Controls.Add(label3);
            Controls.Add(label1);
            Controls.Add(txtMaxDuration);
            Controls.Add(txtTypeOfLeave);
            Name = "EditTypeOfLeaveForm";
            Text = "EditTypeOfLeaveForm";
            Load += EditTypeOfLeaveForm_Load;
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Button btnCancel;
        private Button btnSave;
        private Label label3;
        private Label label1;
        private TextBox txtMaxDuration;
        private TextBox txtTypeOfLeave;
    }
}