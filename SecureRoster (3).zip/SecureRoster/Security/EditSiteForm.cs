﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using Microsoft.Data.SqlClient;
namespace Security
{
    public partial class EditSiteForm : Form
    {
        SqlConnection con = new SqlConnection("Data Source=DESKTOP-133OPA4\\SQLEXPRESS;" + "Initial Catalog=SecureRoster;" + "Integrated Security=True;" + "Encrypt=False;");

        private int siteID;
        public EditSiteForm(int id)
        {
            InitializeComponent();
            siteID = id;
        }

        private void EditSiteForm_Load(object sender, EventArgs e)
        {
            try
            {
                // 1. CLIENTS (Joined with Companies to show the Name)
                DataTable dtClient = new DataTable();
                SqlDataAdapter daClient = new SqlDataAdapter(
                    @"SELECT cc.ClientCompID, c.CompanyName 
              FROM ClientCompanies cc
              INNER JOIN Companies c ON cc.CompanyID = c.CompanyID", con);

                daClient.Fill(dtClient);
                cmbClientCompany.DataSource = dtClient;
                cmbClientCompany.DisplayMember = "CompanyName"; // <--- Displays Name
                cmbClientCompany.ValueMember = "ClientCompID";  // <--- Saves ID

                // 2. SECURITY
                DataTable dtSecurity = new DataTable();
                SqlDataAdapter daSecurity = new SqlDataAdapter(
                    @"SELECT SECURITYCOMP_ID, COMPANYNAME FROM SecurityCompaniesView", con);
                daSecurity.Fill(dtSecurity);
                cmbSecurityCompany.DataSource = dtSecurity;
                cmbSecurityCompany.DisplayMember = "COMPANYNAME";
                cmbSecurityCompany.ValueMember = "SECURITYCOMP_ID";

                // 3. SUBURBS
                DataTable dtSuburb = new DataTable();
                SqlDataAdapter daSuburb = new SqlDataAdapter(
                    @"SELECT SuburbID, SuburbName FROM Suburbs", con);
                daSuburb.Fill(dtSuburb);
                cmbSuburb.DataSource = dtSuburb;
                cmbSuburb.DisplayMember = "SuburbName";
                cmbSuburb.ValueMember = "SuburbID";

                // 4. LOAD THE SITE DATA
                con.Open();
                SqlCommand cmd = new SqlCommand(
                    @"SELECT SITE_ID, NAMEOFSITE, SITECAPACITY, CLIENTCOMP_ID, SECURITYCOMP_ID, SUBURB_ID
              FROM SitesView WHERE SITE_ID = @id", con);
                cmd.Parameters.AddWithValue("@id", siteID);

                SqlDataReader dr = cmd.ExecuteReader();
                if (dr.Read())
                {
                    txtSiteName.Text = dr["NAMEOFSITE"].ToString();
                    txtCapacity.Text = dr["SITECAPACITY"].ToString();

                    cmbClientCompany.SelectedValue = dr["CLIENTCOMP_ID"];
                    cmbSecurityCompany.SelectedValue = dr["SECURITYCOMP_ID"];

                    if (dr["SUBURB_ID"] != DBNull.Value)
                        cmbSuburb.SelectedValue = dr["SUBURB_ID"];
                }
                dr.Close();
                con.Close();
            }
            catch (Exception ex) { MessageBox.Show(ex.Message); }
         }

        private void btnSave_Click(object sender, EventArgs e)
        {

            try
            {
                con.Open();

                SqlCommand cmd =
                    new SqlCommand(
                    @"UPDATE Sites
              SET
                NameOfSite = @name,
                SiteCapacity = @capacity,
                ClientCompID = @client,
                SecurityCompID = @security,
                SuburbID = @suburb
              WHERE SiteID = @id",
                    con);

                cmd.Parameters.AddWithValue(
                    "@name",
                    txtSiteName.Text);

                cmd.Parameters.AddWithValue(
                    "@capacity",
                    txtCapacity.Text);

                cmd.Parameters.AddWithValue(
                    "@client",
                    cmbClientCompany.SelectedValue);

                cmd.Parameters.AddWithValue(
                    "@security",
                    cmbSecurityCompany.SelectedValue);

                cmd.Parameters.AddWithValue(
                    "@suburb",
                    cmbSuburb.SelectedValue);

                cmd.Parameters.AddWithValue(
                    "@id",
                    siteID);

                cmd.ExecuteNonQuery();

                MessageBox.Show(
                    "Site Updated Successfully");

                con.Close();

                this.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }

        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
