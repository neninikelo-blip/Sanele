﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using Microsoft.Data.SqlClient;

namespace Security
{/*
      */
    public partial class GuardJB1 : Form
    {
        public GuardJB1()
        {
            InitializeComponent();
        }
        SqlConnection con = new SqlConnection("Data Source=DESKTOP-133OPA4\\SQLEXPRESS;" + "Initial Catalog=SecureRoster;" + "Integrated Security=True;" + "Encrypt=False;" + "Connect Timeout=60;");
        private string currentTable = "";

        // ------------------------------------------------------------------
        // Updated LoadData to accept SQL parameters safely (prevents errors)
        // ------------------------------------------------------------------
        private void LoadData(string query, SqlParameter[] parameters = null)
        {
            try
            {
                SqlDataAdapter da = new SqlDataAdapter(query, con);

                if (parameters != null)
                {
                    da.SelectCommand.Parameters.AddRange(parameters);
                }

                DataTable dt = new DataTable();
                da.Fill(dt);
                dataGridView1.DataSource = dt;

                // Adds a title to the form showing what they are looking at
                this.Text = "Guard Portal - " + (currentTable == "" ? "Dashboard" : currentTable);

                // AUTO-HIDE ID COLUMNS (Same fix as Manager/Supervisor)
                foreach (DataGridViewColumn col in dataGridView1.Columns)
                {
                    if (col.Name.EndsWith("_ID") || col.Name.ToUpper() == "ID" || col.Name.ToUpper() == "IDNUMBER")
                    {
                        col.Visible = false;
                    }
                }
            }
            catch (Exception ex) { MessageBox.Show(ex.Message); }
        }

        private void btnLogout_Click(object sender, EventArgs e)
        {
            Session.AccountID = 0;
            Session.PersonID = 0;
            Session.Username = "";
            Session.Role = "";
            Session.GuardID = 0;
            Session.SupervisorID = 0;
            Session.ManagerID = 0;
            Session.ITAdminID = 0;
            Session.CompanyID = 0;
            Session.SiteID = 0;

            LoginForm frm = new LoginForm();
            frm.Show();
            this.Hide();
        }
        // ------------------------------------------------------------------
        // Isolated Queries for each button
        // ------------------------------------------------------------------


        private void btnRegularShifts_Click(object sender, EventArgs e)
        { 
            currentTable = "Regular Shifts";
            LoadData("SELECT * FROM GuardRegularShiftView WHERE USERNAME = @user",
                     new[] { new SqlParameter("@user", Session.Username) });
        }


        private void btnSpecial_Click(object sender, EventArgs e)
        { 
            currentTable = "Special Shifts";
            LoadData("SELECT * FROM GuardSpecialShifts WHERE USERNAME = @user",
                     new[] { new SqlParameter("@user", Session.Username) });
        }


        private void Attendances_Click(object sender, EventArgs e)
        { 
            currentTable = "Attendances";
            LoadData("SELECT * FROM GuardAttendanceDetails WHERE USERNAME = @user",
                     new[] { new SqlParameter("@user", Session.Username) });
        }



        private void btnLeaves_Click(object sender, EventArgs e)
        { 
            currentTable = "Leaves";

            // Updated view to match your request
            string sql = @"SELECT LEAVE_ID, USERNAME, FIRSTNAME, LASTNAME, TYPEOFLEAVE, 
                                  STARTDATE, ENDDATE, LEAVEREASON, MAXDAYS, CELLNUMBER
                           FROM GuardLeaveApplicationDetails
                           WHERE UPPER(USERNAME) = UPPER(@user)";

            LoadData(sql, new[] { new SqlParameter("@user", Session.Username) });
        }


        private void btnProfile_Click(object sender, EventArgs e)
        { 
            currentTable = "Profile";
            LoadData("SELECT * FROM GuardsProfile WHERE USERNAME = @user",
                     new[] { new SqlParameter("@user", Session.Username) });
        }




        private void btnAdd_Click(object sender, EventArgs e)
        {
            if (currentTable == "Leaves")
            {
                new AddLeaveForm().ShowDialog();
                btnLeaves_Click(sender, e);   // reload the filtered list
            }
            else
            {
                MessageBox.Show("You can only add new Leave requests.");
            }
        }
        private void GuardJB1_Load(object sender, EventArgs e)
        {   dataGridView1.ReadOnly = true;
            dataGridView1.AllowUserToAddRows = false;
            dataGridView1.AllowUserToDeleteRows = false;
            dataGridView1.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            dataGridView1.MultiSelect = false;

            lblUsername.Text = Session.Username.ToUpper() + " ▼";
            lblRole.Text = Session.Role.ToUpper();
        }


        private void btnEdit_Click(object sender, EventArgs e)
        {
            if (currentTable == "Leaves")
            {
                if (dataGridView1.SelectedRows.Count == 0) return;

                // Because the column is hidden visually, the data is still safe in the background
                int leaveID = Convert.ToInt32(dataGridView1.SelectedRows[0].Cells["LEAVE_ID"].Value);

                new EditLeaveForm(leaveID).ShowDialog();
                btnLeaves_Click(sender, e);
            }
            else if (currentTable == "Profile")
            {
                new EditProfileForm().ShowDialog();
                btnProfile_Click(sender, e);
            }
            else
            {
                MessageBox.Show("Select Leaves or Profile to edit.");
            }
        }

        private void btnDelete_Click(object sender, EventArgs e)
        { 
            if (currentTable != "Leaves")
            {
                MessageBox.Show("You can only delete pending leave requests.");
                return;
            }
            if (dataGridView1.SelectedRows.Count == 0) return;

            int leaveID = Convert.ToInt32(dataGridView1.SelectedRows[0].Cells["LEAVE_ID"].Value);

            if (MessageBox.Show("Withdraw this leave request?", "Confirm",
                MessageBoxButtons.YesNo) != DialogResult.Yes) return;

            try
            {
                using (SqlConnection c = new SqlConnection(
                    "Data Source=DESKTOP-133OPA4\\SQLEXPRESS;Initial Catalog=SecureRoster;" +
                    "Integrated Security=True;Encrypt=False;"))
                {
                    c.Open();

                    SqlCommand cmd = new SqlCommand(
                        @"DELETE FROM Leaves
                          WHERE LeaveID = @id
                            AND GuardID = @gid
                            AND LeaveStatus = 'Pending'", c);
                    cmd.Parameters.AddWithValue("@id", leaveID);
                    cmd.Parameters.AddWithValue("@gid", Session.GuardID);

                    int rows = cmd.ExecuteNonQuery();
                    if (rows == 0)
                        MessageBox.Show("Cannot delete: request may already be approved/rejected.");
                    else
                        MessageBox.Show("Leave request withdrawn.");
                }

                btnLeaves_Click(sender, e);
            }
            catch (Exception ex) { MessageBox.Show(ex.Message); }
        }


        private void panel2_Paint(object sender, PaintEventArgs e)
        {

        }
    }

}
