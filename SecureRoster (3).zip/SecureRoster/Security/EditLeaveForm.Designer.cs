﻿namespace Security
{
    partial class EditLeaveForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            cmbGuard = new ComboBox();
            label5 = new Label();
            label4 = new Label();
            cmbLeaveType = new ComboBox();
            btnCancel = new Button();
            btnSave = new Button();
            label3 = new Label();
            label2 = new Label();
            label1 = new Label();
            txtReason = new TextBox();
            dtpEndDate = new DateTimePicker();
            dtpStartDate = new DateTimePicker();
            SuspendLayout();
            // 
            // cmbGuard
            // 
            cmbGuard.FormattingEnabled = true;
            cmbGuard.Items.AddRange(new object[] { "Potsdam Campus", "College Street Campus" });
            cmbGuard.Location = new Point(430, 53);
            cmbGuard.Name = "cmbGuard";
            cmbGuard.Size = new Size(121, 23);
            cmbGuard.TabIndex = 48;
            cmbGuard.SelectedIndexChanged += cmbGuard_SelectedIndexChanged;
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Location = new Point(289, 59);
            label5.Name = "label5";
            label5.Size = new Size(39, 15);
            label5.TabIndex = 47;
            label5.Text = "Guard";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new Point(288, 12);
            label4.Name = "label4";
            label4.Size = new Size(65, 15);
            label4.TabIndex = 46;
            label4.Text = "Leave Type";
            // 
            // cmbLeaveType
            // 
            cmbLeaveType.FormattingEnabled = true;
            cmbLeaveType.Items.AddRange(new object[] { "Potsdam Campus", "College Street Campus" });
            cmbLeaveType.Location = new Point(430, 12);
            cmbLeaveType.Name = "cmbLeaveType";
            cmbLeaveType.Size = new Size(121, 23);
            cmbLeaveType.TabIndex = 45;
            // 
            // btnCancel
            // 
            btnCancel.Location = new Point(322, 289);
            btnCancel.Name = "btnCancel";
            btnCancel.Size = new Size(75, 23);
            btnCancel.TabIndex = 44;
            btnCancel.Text = "Cancel";
            btnCancel.UseVisualStyleBackColor = true;
            btnCancel.Click += btnCancel_Click_1;
            // 
            // btnSave
            // 
            btnSave.Location = new Point(69, 289);
            btnSave.Name = "btnSave";
            btnSave.Size = new Size(75, 23);
            btnSave.TabIndex = 43;
            btnSave.Text = "Save";
            btnSave.UseVisualStyleBackColor = true;
            btnSave.Click += btnSave_Click_1;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(12, 103);
            label3.Name = "label3";
            label3.Size = new Size(78, 15);
            label3.TabIndex = 42;
            label3.Text = "Leave Reason";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(12, 53);
            label2.Name = "label2";
            label2.Size = new Size(54, 15);
            label2.TabIndex = 41;
            label2.Text = "End Date";
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(12, 9);
            label1.Name = "label1";
            label1.Size = new Size(58, 15);
            label1.TabIndex = 40;
            label1.Text = "Start Date";
            // 
            // txtReason
            // 
            txtReason.Location = new Point(176, 95);
            txtReason.Name = "txtReason";
            txtReason.Size = new Size(100, 23);
            txtReason.TabIndex = 39;
            // 
            // dtpEndDate
            // 
            dtpEndDate.Location = new Point(76, 53);
            dtpEndDate.Name = "dtpEndDate";
            dtpEndDate.Size = new Size(200, 23);
            dtpEndDate.TabIndex = 50;
            // 
            // dtpStartDate
            // 
            dtpStartDate.Location = new Point(76, 9);
            dtpStartDate.Name = "dtpStartDate";
            dtpStartDate.Size = new Size(200, 23);
            dtpStartDate.TabIndex = 49;
            // 
            // EditLeaveForm
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.FromArgb(31, 45, 61);
            ClientSize = new Size(565, 505);
            Controls.Add(dtpEndDate);
            Controls.Add(dtpStartDate);
            Controls.Add(cmbGuard);
            Controls.Add(label5);
            Controls.Add(label4);
            Controls.Add(cmbLeaveType);
            Controls.Add(btnCancel);
            Controls.Add(btnSave);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(label1);
            Controls.Add(txtReason);
            Name = "EditLeaveForm";
            Text = "EditLeaveForm";
            Load += EditLeaveForm_Load;
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private ComboBox cmbGuard;
        private Label label5;
        private Label label4;
        private ComboBox cmbLeaveType;
        private Button btnCancel;
        private Button btnSave;
        private Label label3;
        private Label label2;
        private Label label1;
        private TextBox txtReason;
        private DateTimePicker dtpEndDate;
        private DateTimePicker dtpStartDate;
    }
}