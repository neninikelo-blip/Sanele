﻿using System;
using System.Data;
using System.Windows.Forms;
using Microsoft.Data.SqlClient;

namespace Security
{
    public partial class AddPostForm : Form
    {
        SqlConnection con = new SqlConnection(
            "Data Source=DESKTOP-133OPA4\\SQLEXPRESS;" +
            "Initial Catalog=SecureRoster;" +
            "Integrated Security=True;" +
            "Encrypt=False;");

        public AddPostForm()
        {
            InitializeComponent();
        }

        private void AddPostForm_Load(object sender, EventArgs e)
        {
            cmbNumberPerPost.Items.Clear();
            cmbNumberPerPost.Items.AddRange(new object[] { "1", "2", "3", "4", "5", "6", "7", "8", "9", "10" });
            cmbNumberPerPost.DropDownStyle = ComboBoxStyle.DropDownList;

            cmbStatus.Items.Clear();
            cmbStatus.Items.AddRange(new object[] { "Active", "Temporary", "Inactive" });
            cmbStatus.DropDownStyle = ComboBoxStyle.DropDownList;

            // SECURITY COMPANIES
            DataTable dtSecurity = new DataTable();
            SqlDataAdapter daSecurity = new SqlDataAdapter(
                @"SELECT SECURITYCOMP_ID, SECURITYCOMPANYNAME
          FROM PostsView
          GROUP BY SECURITYCOMP_ID, SECURITYCOMPANYNAME
          ORDER BY SECURITYCOMPANYNAME", con);
            daSecurity.Fill(dtSecurity);

            comboBoxSecurityCompany.DataSource = dtSecurity;
            comboBoxSecurityCompany.DisplayMember = "SECURITYCOMPANYNAME";
            comboBoxSecurityCompany.ValueMember = "SECURITYCOMP_ID";
            comboBoxSecurityCompany.SelectedIndex = -1;

            // Wire up the change event AFTER the combo is bound (THIS IS THE FIX)
            comboBoxSecurityCompany.SelectedIndexChanged += comboBoxSecurityCompany_SelectedIndexChanged;

            cmbSite.DataSource = null;
        }

        





        private void btnSave_Click_1(object sender, EventArgs e)
        {
            // Guards BEFORE anything else
            if (cmbSite.SelectedValue == null || cmbSite.SelectedValue is DataRowView)
            {
                MessageBox.Show("Please select a site.");
                return;
            }
            if (string.IsNullOrWhiteSpace(txtPostName.Text))
            {
                MessageBox.Show("Please enter the post name.");
                return;
            }
            if (string.IsNullOrWhiteSpace(cmbNumberPerPost.Text))
            {
                MessageBox.Show("Please enter the number per post.");
                return;
            }

            try
            {
                con.Open();

                SqlCommand cmd = new SqlCommand(
                    @"INSERT INTO Posts
                    (PostID, SiteID, PostName, NumberPerPost, PStatus)
                  VALUES
                    ((SELECT ISNULL(MAX(PostID),0) + 1 FROM Posts),
                     @siteid, @postname, @number, @status)", con);

                cmd.Parameters.AddWithValue("@siteid", cmbSite.SelectedValue);
                cmd.Parameters.AddWithValue("@postname", txtPostName.Text);
                cmd.Parameters.AddWithValue("@number", cmbNumberPerPost.Text);
                cmd.Parameters.AddWithValue("@status", cmbStatus.Text);

                cmd.ExecuteNonQuery();

                MessageBox.Show("Post Added Successfully");
                con.Close();
                this.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        

          
        
        }

        

        private void btnCancel_Click_1(object sender, EventArgs e)
        {
            this.Close();
        }

        private void comboBoxSecurityCompany_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (comboBoxSecurityCompany.SelectedValue == null || comboBoxSecurityCompany.SelectedValue is DataRowView) return;

            int secID;
            if (!int.TryParse(comboBoxSecurityCompany.SelectedValue.ToString(), out secID)) return;

            SqlDataAdapter da = new SqlDataAdapter(
                "SELECT SiteID, NameOfSite FROM Sites WHERE SecurityCompID = @secid", con);
            da.SelectCommand.Parameters.AddWithValue("@secid", secID);

            DataTable dt = new DataTable();
            da.Fill(dt);

            cmbSite.DataSource = dt;
            cmbSite.DisplayMember = "NameOfSite";
            cmbSite.ValueMember = "SiteID";
        }
    
    


    /*

*/
}
}