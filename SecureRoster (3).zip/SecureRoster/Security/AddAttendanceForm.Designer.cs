﻿namespace Security
{
    partial class AddAttendanceForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            cmbAssignment = new ComboBox();
            cmbStatus = new ComboBox();
            label5 = new Label();
            label6 = new Label();
            btnCancel = new Button();
            btnSave = new Button();
            label3 = new Label();
            label1 = new Label();
            cmbCheckOut = new ComboBox();
            cmbCheckIn = new ComboBox();
            SuspendLayout();
            // 
            // cmbAssignment
            // 
            cmbAssignment.FormattingEnabled = true;
            cmbAssignment.Location = new Point(458, 71);
            cmbAssignment.Name = "cmbAssignment";
            cmbAssignment.Size = new Size(142, 23);
            cmbAssignment.TabIndex = 90;
            // 
            // cmbStatus
            // 
            cmbStatus.FormattingEnabled = true;
            cmbStatus.Location = new Point(458, 21);
            cmbStatus.Name = "cmbStatus";
            cmbStatus.Size = new Size(121, 23);
            cmbStatus.TabIndex = 89;
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Location = new Point(323, 71);
            label5.Name = "label5";
            label5.Size = new Size(70, 15);
            label5.TabIndex = 88;
            label5.Text = "Assignment";
            // 
            // label6
            // 
            label6.Location = new Point(322, 24);
            label6.Name = "label6";
            label6.Size = new Size(109, 23);
            label6.TabIndex = 91;
            label6.Text = "Attendance Status";
            // 
            // btnCancel
            // 
            btnCancel.Location = new Point(322, 301);
            btnCancel.Name = "btnCancel";
            btnCancel.Size = new Size(75, 23);
            btnCancel.TabIndex = 87;
            btnCancel.Text = "Cancel";
            btnCancel.UseVisualStyleBackColor = true;
            btnCancel.Click += btnCancel_Click;
            // 
            // btnSave
            // 
            btnSave.Location = new Point(69, 301);
            btnSave.Name = "btnSave";
            btnSave.Size = new Size(75, 23);
            btnSave.TabIndex = 86;
            btnSave.Text = "Save";
            btnSave.UseVisualStyleBackColor = true;
            btnSave.Click += btnSave_Click;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(12, 71);
            label3.Name = "label3";
            label3.Size = new Size(63, 15);
            label3.TabIndex = 85;
            label3.Text = "Check Out";
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(12, 21);
            label1.Name = "label1";
            label1.Size = new Size(83, 15);
            label1.TabIndex = 83;
            label1.Text = "Check In Time";
            // 
            // cmbCheckOut
            // 
            cmbCheckOut.FormattingEnabled = true;
            cmbCheckOut.Items.AddRange(new object[] { "Potsdam Campus", "College Street Campus" });
            cmbCheckOut.Location = new Point(112, 67);
            cmbCheckOut.Name = "cmbCheckOut";
            cmbCheckOut.Size = new Size(121, 23);
            cmbCheckOut.TabIndex = 93;
            // 
            // cmbCheckIn
            // 
            cmbCheckIn.FormattingEnabled = true;
            cmbCheckIn.Items.AddRange(new object[] { "Potsdam Campus", "College Street Campus" });
            cmbCheckIn.Location = new Point(112, 13);
            cmbCheckIn.Name = "cmbCheckIn";
            cmbCheckIn.Size = new Size(121, 23);
            cmbCheckIn.TabIndex = 92;
            // 
            // AddAttendanceForm
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.FromArgb(31, 45, 61);
            ClientSize = new Size(635, 385);
            Controls.Add(cmbCheckOut);
            Controls.Add(cmbCheckIn);
            Controls.Add(cmbAssignment);
            Controls.Add(cmbStatus);
            Controls.Add(label5);
            Controls.Add(label6);
            Controls.Add(btnCancel);
            Controls.Add(btnSave);
            Controls.Add(label3);
            Controls.Add(label1);
            Name = "AddAttendanceForm";
            Text = "AddAttendanceForm";
            Load += AddAttendanceForm_Load;
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion
        private ComboBox cmbAssignment;
        private ComboBox cmbStatus;
        private Label label5;
        private Label label6;
        private Button btnCancel;
        private Button btnSave;
        private Label label3;
        private Label label1;
        private TextBox txtCheckOut;
        private TextBox txtCheckIn;
        private ComboBox cmbSuburb;
        private ComboBox cmbCompany;
        private ComboBox cmbCheckOut;
        private ComboBox cmbCheckin;
        private ComboBox cmbCheckIn;
    }
}