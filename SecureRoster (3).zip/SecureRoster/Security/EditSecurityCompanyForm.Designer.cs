﻿namespace Security
{
    partial class EditSecurityCompanyForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            cmbSuburb = new ComboBox();
            cmbCompany = new ComboBox();
            label5 = new Label();
            label6 = new Label();
            btnCancel = new Button();
            btnSave = new Button();
            label3 = new Label();
            label2 = new Label();
            label1 = new Label();
            txtCompanyCell = new TextBox();
            txtCompanyEmail = new TextBox();
            txtCompanyName = new TextBox();
            SuspendLayout();
            // 
            // cmbSuburb
            // 
            cmbSuburb.FormattingEnabled = true;
            cmbSuburb.Location = new Point(430, 100);
            cmbSuburb.Name = "cmbSuburb";
            cmbSuburb.Size = new Size(121, 23);
            cmbSuburb.TabIndex = 54;
            // 
            // cmbCompany
            // 
            cmbCompany.FormattingEnabled = true;
            cmbCompany.Location = new Point(430, 12);
            cmbCompany.Name = "cmbCompany";
            cmbCompany.Size = new Size(121, 23);
            cmbCompany.TabIndex = 52;
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Location = new Point(30, 23);
            label5.Name = "label5";
            label5.Size = new Size(94, 15);
            label5.TabIndex = 51;
            label5.Text = "Company Name";
            // 
            // label6
            // 
            label6.Location = new Point(324, 15);
            label6.Name = "label6";
            label6.Size = new Size(100, 23);
            label6.TabIndex = 55;
            label6.Text = "Company";
            // 
            // btnCancel
            // 
            btnCancel.Location = new Point(343, 292);
            btnCancel.Name = "btnCancel";
            btnCancel.Size = new Size(75, 23);
            btnCancel.TabIndex = 50;
            btnCancel.Text = "Cancel";
            btnCancel.UseVisualStyleBackColor = true;
            btnCancel.Click += btnCancel_Click;
            // 
            // btnSave
            // 
            btnSave.Location = new Point(90, 292);
            btnSave.Name = "btnSave";
            btnSave.Size = new Size(75, 23);
            btnSave.TabIndex = 49;
            btnSave.Text = "Save";
            btnSave.UseVisualStyleBackColor = true;
            btnSave.Click += btnSave_Click;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(29, 115);
            label3.Name = "label3";
            label3.Size = new Size(82, 15);
            label3.TabIndex = 48;
            label3.Text = "Company Cell";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(324, 103);
            label2.Name = "label2";
            label2.Size = new Size(45, 15);
            label2.TabIndex = 47;
            label2.Text = "Suburb";
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(29, 65);
            label1.Name = "label1";
            label1.Size = new Size(91, 15);
            label1.TabIndex = 46;
            label1.Text = "Company Email";
            // 
            // txtCompanyCell
            // 
            txtCompanyCell.Location = new Point(171, 112);
            txtCompanyCell.Name = "txtCompanyCell";
            txtCompanyCell.Size = new Size(132, 23);
            txtCompanyCell.TabIndex = 45;
            // 
            // txtCompanyEmail
            // 
            txtCompanyEmail.Location = new Point(171, 65);
            txtCompanyEmail.Name = "txtCompanyEmail";
            txtCompanyEmail.Size = new Size(132, 23);
            txtCompanyEmail.TabIndex = 44;
            // 
            // txtCompanyName
            // 
            txtCompanyName.Location = new Point(171, 15);
            txtCompanyName.Name = "txtCompanyName";
            txtCompanyName.Size = new Size(132, 23);
            txtCompanyName.TabIndex = 56;
            // 
            // EditSecurityCompanyForm
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.FromArgb(31, 45, 61);
            ClientSize = new Size(587, 330);
            Controls.Add(txtCompanyName);
            Controls.Add(cmbSuburb);
            Controls.Add(cmbCompany);
            Controls.Add(label5);
            Controls.Add(label6);
            Controls.Add(btnCancel);
            Controls.Add(btnSave);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(label1);
            Controls.Add(txtCompanyCell);
            Controls.Add(txtCompanyEmail);
            Name = "EditSecurityCompanyForm";
            Text = "EditSecurityCompanyForm";
            Load += EditSecurityCompanyForm_Load;
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private ComboBox cmbSuburb;
        private ComboBox cmbCompany;
        private Label label5;
        private Label label6;
        private Button btnCancel;
        private Button btnSave;
        private Label label3;
        private Label label2;
        private Label label1;
        private TextBox txtCompanyCell;
        private TextBox txtCompanyEmail;
        private TextBox txtCompanyName;
    }
}