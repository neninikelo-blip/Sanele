﻿namespace Security
{
    partial class AddRosterForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            cmbSite = new ComboBox();
            cmbSupervisor = new ComboBox();
            btnSave = new Button();
            btnCancel = new Button();
            label1 = new Label();
            label2 = new Label();
            dtpStartDate = new DateTimePicker();
            dtpEndDate = new DateTimePicker();
            txtRosterName = new TextBox();
            cmbStatus = new ComboBox();
            label3 = new Label();
            label4 = new Label();
            label5 = new Label();
            label7 = new Label();
            SuspendLayout();
            // 
            // cmbSite
            // 
            cmbSite.FormattingEnabled = true;
            cmbSite.Location = new Point(105, 12);
            cmbSite.Name = "cmbSite";
            cmbSite.Size = new Size(121, 23);
            cmbSite.TabIndex = 0;
            // 
            // cmbSupervisor
            // 
            cmbSupervisor.FormattingEnabled = true;
            cmbSupervisor.Location = new Point(105, 62);
            cmbSupervisor.Name = "cmbSupervisor";
            cmbSupervisor.Size = new Size(121, 23);
            cmbSupervisor.TabIndex = 1;
            // 
            // btnSave
            // 
            btnSave.Location = new Point(79, 308);
            btnSave.Name = "btnSave";
            btnSave.Size = new Size(75, 23);
            btnSave.TabIndex = 2;
            btnSave.Text = "Save";
            btnSave.UseVisualStyleBackColor = true;
            btnSave.Click += btnSave_Click;
            // 
            // btnCancel
            // 
            btnCancel.Location = new Point(280, 308);
            btnCancel.Name = "btnCancel";
            btnCancel.Size = new Size(75, 23);
            btnCancel.TabIndex = 3;
            btnCancel.Text = "Cancel";
            btnCancel.UseVisualStyleBackColor = true;
            btnCancel.Click += btnCancel_Click;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(44, 22);
            label1.Name = "label1";
            label1.Size = new Size(26, 15);
            label1.TabIndex = 4;
            label1.Text = "Site";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(8, 62);
            label2.Name = "label2";
            label2.Size = new Size(62, 15);
            label2.TabIndex = 5;
            label2.Text = "Supervisor";
            // 
            // dtpStartDate
            // 
            dtpStartDate.Location = new Point(412, 12);
            dtpStartDate.Name = "dtpStartDate";
            dtpStartDate.Size = new Size(200, 23);
            dtpStartDate.TabIndex = 6;
            // 
            // dtpEndDate
            // 
            dtpEndDate.Location = new Point(412, 89);
            dtpEndDate.Name = "dtpEndDate";
            dtpEndDate.Size = new Size(200, 23);
            dtpEndDate.TabIndex = 7;
            // 
            // txtRosterName
            // 
            txtRosterName.Location = new Point(315, 143);
            txtRosterName.Name = "txtRosterName";
            txtRosterName.Size = new Size(100, 23);
            txtRosterName.TabIndex = 8;
            // 
            // cmbStatus
            // 
            cmbStatus.FormattingEnabled = true;
            cmbStatus.Location = new Point(316, 208);
            cmbStatus.Name = "cmbStatus";
            cmbStatus.Size = new Size(121, 23);
            cmbStatus.TabIndex = 9;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(335, 89);
            label3.Name = "label3";
            label3.Size = new Size(54, 15);
            label3.TabIndex = 11;
            label3.Text = "End Date";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new Point(335, 20);
            label4.Name = "label4";
            label4.Size = new Size(58, 15);
            label4.TabIndex = 10;
            label4.Text = "Start Date";
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Location = new Point(206, 151);
            label5.Name = "label5";
            label5.Size = new Size(75, 15);
            label5.TabIndex = 13;
            label5.Text = "Roster Name";
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Location = new Point(196, 216);
            label7.Name = "label7";
            label7.Size = new Size(39, 15);
            label7.TabIndex = 14;
            label7.Text = "Status";
            // 
            // AddRosterForm
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.FromArgb(31, 45, 61);
            ClientSize = new Size(637, 353);
            Controls.Add(label7);
            Controls.Add(label5);
            Controls.Add(label3);
            Controls.Add(label4);
            Controls.Add(cmbStatus);
            Controls.Add(txtRosterName);
            Controls.Add(dtpEndDate);
            Controls.Add(dtpStartDate);
            Controls.Add(label2);
            Controls.Add(label1);
            Controls.Add(btnCancel);
            Controls.Add(btnSave);
            Controls.Add(cmbSupervisor);
            Controls.Add(cmbSite);
            Name = "AddRosterForm";
            Text = "AddRosterForm";
            Load += AddRosterForm_Load;
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private ComboBox cmbSite;
        private ComboBox cmbSupervisor;
        private Button btnSave;
        private Button btnCancel;
        private Label label1;
        private Label label2;
        private DateTimePicker dtpStartDate;
        private DateTimePicker dtpEndDate;
        private TextBox txtRosterName;
        private ComboBox cmbStatus;
        private Label label3;
        private Label label4;
        private Label label5;
        private Label label7;
    }
}