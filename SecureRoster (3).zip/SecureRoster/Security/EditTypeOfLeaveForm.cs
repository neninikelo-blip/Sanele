﻿using System;
using System.Data;
using System.Windows.Forms;
using Microsoft.Data.SqlClient;

namespace Security
{
    public partial class EditTypeOfLeaveForm : Form
    {
        SqlConnection con = new SqlConnection(
            "Data Source=DESKTOP-133OPA4\\SQLEXPRESS;" +
            "Initial Catalog=SecureRoster;" +
            "Integrated Security=True;" +
            "Encrypt=False;");

        private int leaveTypeID;

        public EditTypeOfLeaveForm(int id)
        {
            InitializeComponent();
            leaveTypeID = id;
        }

        private void EditTypeOfLeaveForm_Load(object sender, EventArgs e)
        {
            try
            {
                con.Open();

                SqlCommand cmd = new SqlCommand(
                    @"SELECT TypeOfLeave, MaxDuration
                      FROM TypeOfLeaves
                      WHERE TypeOfLeaveID = @id", con);

                cmd.Parameters.AddWithValue("@id", leaveTypeID);

                SqlDataReader dr = cmd.ExecuteReader();

                if (dr.Read())
                {
                    txtTypeOfLeave.Text = dr["TypeOfLeave"].ToString();
                    txtMaxDuration.Text = dr["MaxDuration"].ToString();
                }

                dr.Close();
                con.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

       

  

        private void btnSave_Click(object sender, EventArgs e)
        {
           
            try
            {
                if (string.IsNullOrWhiteSpace(txtTypeOfLeave.Text))
                {
                    MessageBox.Show("Please enter the type of leave.");
                    return;
                }
                if (string.IsNullOrWhiteSpace(txtMaxDuration.Text))
                {
                    MessageBox.Show("Please enter the max duration.");
                    return;
                }

                con.Open();

                SqlCommand cmd = new SqlCommand(
                    @"UPDATE TypeOfLeaves
                      SET TypeOfLeave = @type,
                          MaxDuration = @max
                      WHERE TypeOfLeaveID = @id", con);

                cmd.Parameters.AddWithValue("@type", txtTypeOfLeave.Text);
                cmd.Parameters.AddWithValue("@max", txtMaxDuration.Text);
                cmd.Parameters.AddWithValue("@id", leaveTypeID);

                cmd.ExecuteNonQuery();

                MessageBox.Show("Type of Leave Updated Successfully");
                con.Close();
                this.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    
    }
}