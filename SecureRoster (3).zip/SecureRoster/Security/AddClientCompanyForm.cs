﻿using System;
using System.Data;
using System.Windows.Forms;
using Microsoft.Data.SqlClient;

namespace Security
{
    public partial class AddClientCompanyForm : Form
    {
        SqlConnection con = new SqlConnection(
            "Data Source=DESKTOP-133OPA4\\SQLEXPRESS;" +
            "Initial Catalog=SecureRoster;" +
            "Integrated Security=True;" +
            "Encrypt=False;");

        public AddClientCompanyForm()
        {
            InitializeComponent();
        }

        private void AddClientCompanyForm_Load(object sender, EventArgs e)
        {
            SqlDataAdapter da = new SqlDataAdapter(
                @"SELECT CompanyID, CompanyName 
                  FROM Companies
                  WHERE CompanyID NOT IN (SELECT CompanyID FROM SecurityCompanies)", con);

            DataTable dt = new DataTable();
            da.Fill(dt);

            comboBoxCompany.DataSource = dt;
            comboBoxCompany.DisplayMember = "CompanyName";
            comboBoxCompany.ValueMember = "CompanyID";

            SqlDataAdapter da2 = new SqlDataAdapter(
                "SELECT SuburbID, SuburbName FROM Suburbs", con);

            DataTable dt2 = new DataTable();
            da2.Fill(dt2);

            comboBoxSuburb.DataSource = dt2;
            comboBoxSuburb.DisplayMember = "SuburbName";
            comboBoxSuburb.ValueMember = "SuburbID";
        }






        private void btnSave_Click_1(object sender, EventArgs e)
        {
            try
            {
                // Open connection safely
                if (con.State != ConnectionState.Open) con.Open();

                SqlCommand idCmd = new SqlCommand(
                    "SELECT ISNULL(MAX(ClientCompID),0) + 1 FROM ClientCompanies", con);

                int clientCompID = Convert.ToInt32(idCmd.ExecuteScalar());

                SqlCommand cmd = new SqlCommand(
                    @"INSERT INTO ClientCompanies
                        (ClientCompID, CompanyID, SuburbID)
                      VALUES
                        (@clientid, @companyid, @suburbid)", con);

                cmd.Parameters.AddWithValue("@clientid", clientCompID);
                cmd.Parameters.AddWithValue("@companyid", comboBoxCompany.SelectedValue);
                cmd.Parameters.AddWithValue("@suburbid", comboBoxSuburb.SelectedValue);

                cmd.ExecuteNonQuery();

                MessageBox.Show("Client Company Added Successfully");
                this.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
                // ALWAYS close the connection, even if there's an error!
                if (con.State == ConnectionState.Open)
                {
                    con.Close();
                }
            }
         }

        private void btnCancel_Click_1(object sender, EventArgs e)
        {
            this.Close();
        
        }
    }
}
/**/