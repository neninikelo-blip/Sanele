﻿using System;
using System.Data;
using System.Windows.Forms;
using Microsoft.Data.SqlClient;

namespace Security
{
    public partial class EditClientCompanyForm : Form
    {
        SqlConnection con = new SqlConnection(
            "Data Source=DESKTOP-133OPA4\\SQLEXPRESS;" +
            "Initial Catalog=SecureRoster;" +
            "Integrated Security=True;" +
            "Encrypt=False;");

        private int clientCompID;

        public EditClientCompanyForm(int id)
        {
            InitializeComponent();
            clientCompID = id;
        }

        private void EditClientCompanyForm_Load(object sender, EventArgs e)
        {
            // 1. Load Suburbs
            SqlDataAdapter da = new SqlDataAdapter(
                "SELECT SuburbID, SuburbName FROM Suburbs", con);
            DataTable dt = new DataTable();
            da.Fill(dt);
            comboBoxSuburb.DataSource = dt;
            comboBoxSuburb.DisplayMember = "SuburbName";
            comboBoxSuburb.ValueMember = "SuburbID";

            // 2. Load ONLY valid Client Companies
            SqlDataAdapter da2 = new SqlDataAdapter(
                @"SELECT c.CompanyID, c.CompanyName 
          FROM Companies c
          WHERE c.CompanyID NOT IN (SELECT CompanyID FROM SecurityCompanies)
          OR c.CompanyID = (SELECT CompanyID FROM ClientCompanies WHERE ClientCompID = @id)", con);

            da2.SelectCommand.Parameters.AddWithValue("@id", clientCompID);

            DataTable dt2 = new DataTable();
            da2.Fill(dt2);
            comboBoxCompany.DataSource = dt2;
            comboBoxCompany.DisplayMember = "CompanyName";
            comboBoxCompany.ValueMember = "CompanyID";

            // 3. Load existing data into the form (FIXED QUERY)
            try
            {
                con.Open();

                // We just query the view directly using CLIENTCOMP_ID
                SqlCommand cmd = new SqlCommand(
                    @"SELECT COMPANY_ID, COMPANYNAME, COMPANYCELL, COMPANYEMAIL 
              FROM ManagerClientCompanyDetails 
              WHERE CLIENTCOMP_ID = @id", con);

                cmd.Parameters.AddWithValue("@id", clientCompID);

                SqlDataReader dr = cmd.ExecuteReader();

                if (dr.Read())
                {
                    txtCompanyName.Text = dr["COMPANYNAME"].ToString();
                    txtCompanyCell.Text = dr["COMPANYCELL"].ToString();
                    txtCompanyEmail.Text = dr["COMPANYEMAIL"].ToString();

                    comboBoxCompany.SelectedValue = Convert.ToInt32(dr["COMPANY_ID"]);
                }
                dr.Close();

                // 4. Get the SuburbID separately from the ClientCompanies table
                SqlCommand subCmd = new SqlCommand(
                    "SELECT SuburbID FROM ClientCompanies WHERE ClientCompID = @id", con);
                subCmd.Parameters.AddWithValue("@id", clientCompID);

                object subResult = subCmd.ExecuteScalar();
                if (subResult != DBNull.Value && subResult != null)
                {
                    comboBoxSuburb.SelectedValue = Convert.ToInt32(subResult);
                }

                con.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
                if (con.State == ConnectionState.Open) con.Close();
            }
         }



   

        private void btnSave_Click_1(object sender, EventArgs e)
        {
            try
            {
                con.Open();

                SqlCommand cmd = new SqlCommand(
                    @"UPDATE Companies
                      SET CompanyName  = @name,
                          CompanyCell  = @cell,
                          CompanyEmail = @email
                      WHERE CompanyID = @companyid", con);

                cmd.Parameters.AddWithValue("@name", txtCompanyName.Text);
                cmd.Parameters.AddWithValue("@cell", txtCompanyCell.Text);
                cmd.Parameters.AddWithValue("@email", txtCompanyEmail.Text);
                cmd.Parameters.AddWithValue("@companyid", comboBoxCompany.SelectedValue);

                cmd.ExecuteNonQuery();

                SqlCommand ccCmd = new SqlCommand(
                    @"UPDATE ClientCompanies
                      SET SuburbID = @suburbid
                      WHERE ClientCompID = @id", con);

                ccCmd.Parameters.AddWithValue("@suburbid", comboBoxSuburb.SelectedValue);
                ccCmd.Parameters.AddWithValue("@id", clientCompID);

                ccCmd.ExecuteNonQuery();

                MessageBox.Show("Client Company Updated Successfully");
                con.Close();
                this.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }

        }

        private void btnCancel_Click_1(object sender, EventArgs e)
        {
            this.Close();
        
        }
    }
}