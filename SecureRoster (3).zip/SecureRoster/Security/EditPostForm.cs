﻿using Microsoft.Data.SqlClient;
using System;
using System.Data;
using System.Windows.Forms;
using System.Windows.Forms.VisualStyles;

namespace Security
{
    public partial class EditPostForm : Form
    {
        SqlConnection con = new SqlConnection(
            "Data Source=DESKTOP-133OPA4\\SQLEXPRESS;" +
            "Initial Catalog=SecureRoster;" +
            "Integrated Security=True;" +
            "Encrypt=False;");

        private int postID;

        public EditPostForm(int id)
        {
            InitializeComponent();
            postID = id;
        }

        private void EditPostForm_Load(object sender, EventArgs e)
        {
            cmbNumberPerPost.Items.Clear();
            cmbNumberPerPost.Items.AddRange(new object[] { "1", "2", "3", "4", "5", "6", "7", "8", "9", "10" });
            cmbNumberPerPost.DropDownStyle = ComboBoxStyle.DropDownList;

            cmbStatus.Items.Clear();
            cmbStatus.Items.AddRange(new object[] { "Active", "Temporary", "Inactive" });
            cmbStatus.DropDownStyle = ComboBoxStyle.DropDownList;
            // SECURITY COMPANIES (from the view)
            DataTable dtSecurity = new DataTable();
            SqlDataAdapter daSecurity = new SqlDataAdapter(
                @"SELECT SECURITYCOMP_ID, SECURITYCOMPANYNAME
                  FROM PostsView
                  GROUP BY SECURITYCOMP_ID, SECURITYCOMPANYNAME
                  ORDER BY SECURITYCOMPANYNAME", con);
            daSecurity.Fill(dtSecurity);

            cmbSecurityCompany.DataSource = dtSecurity;
            cmbSecurityCompany.DisplayMember = "SECURITYCOMPANYNAME";
            cmbSecurityCompany.ValueMember = "SECURITYCOMP_ID";

            // Wire up AFTER binding
            cmbSecurityCompany.SelectedIndexChanged +=
                cmbSecurityCompany_SelectedIndexChanged;

            // Start site combo empty
            cmbSite.DataSource = null;

            LoadPostData();
        


        }





        private void btnSave_Click_1(object sender, EventArgs e)
        {
        
            if (cmbSite.SelectedValue == null || cmbSite.SelectedValue is DataRowView)
            {
                MessageBox.Show("Please select a site.");
                return;
            }
            if (string.IsNullOrWhiteSpace(txtPostName.Text))
            {
                MessageBox.Show("Please enter the post name.");
                return;
            }
            if (string.IsNullOrWhiteSpace(cmbNumberPerPost.Text))
            {
                MessageBox.Show("Please enter the number per post.");
                return;
            }

            try
            {
                con.Open();

                SqlCommand cmd = new SqlCommand(
                    @"UPDATE Posts
                      SET SiteID        = @siteid,
                          PostName      = @postname,
                          NumberPerPost = @number,
                          PStatus       = @status
                      WHERE PostID = @id", con);

                cmd.Parameters.AddWithValue("@siteid", cmbSite.SelectedValue);
                cmd.Parameters.AddWithValue("@postname", txtPostName.Text);
                cmd.Parameters.AddWithValue("@number", cmbNumberPerPost.Text);
                cmd.Parameters.AddWithValue("@status", cmbStatus.Text);
                cmd.Parameters.AddWithValue("@id", postID);

                cmd.ExecuteNonQuery();

                MessageBox.Show("Post Updated Successfully");
                con.Close();
                this.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        

 
        }



        private void btnCancel_Click_1(object sender, EventArgs e)
        {
            this.Close();

        }

        private void cmbSecurityCompany_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (cmbSecurityCompany.SelectedValue == null) return;
            if (cmbSecurityCompany.SelectedValue is DataRowView) return;

            int secID;
            if (!int.TryParse(cmbSecurityCompany.SelectedValue.ToString(), out secID))
                return;

            LoadSitesForSecurityCompany(secID, null);
        }

        private void LoadSitesForSecurityCompany(int secID, int? preselectSiteID)
        {
            SqlDataAdapter da = new SqlDataAdapter(
                "SELECT SiteID, NameOfSite FROM Sites WHERE SecurityCompID = @secid", con);
            da.SelectCommand.Parameters.AddWithValue("@secid", secID);

            DataTable dt = new DataTable();
            da.Fill(dt);

            cmbSite.DataSource = dt;
            cmbSite.DisplayMember = "NameOfSite";
            cmbSite.ValueMember = "SiteID";

            if (preselectSiteID.HasValue)
                cmbSite.SelectedValue = preselectSiteID.Value;
        }
        private void LoadPostData()
        {
            try
            {
                con.Open();

                // 1) Read the post from PostsView (has SECURITYCOMP_ID + SECURITYCOMPANYNAME)
                SqlCommand cmd = new SqlCommand(
                    @"SELECT POSTNAME, NUMBERPERPOST, POSTSTATUS,
                             POSTID, SECURITYCOMP_ID
                      FROM PostsView
                      WHERE POSTID = @id", con);

                cmd.Parameters.AddWithValue("@id", postID);

                string postName = "";
                string numberPerPost = "";
                string status = "";
                int secID = 0;

                SqlDataReader dr = cmd.ExecuteReader();

                if (dr.Read())
                {
                    postName = dr["POSTNAME"].ToString();
                    numberPerPost = dr["NUMBERPERPOST"].ToString();
                    status = dr["POSTSTATUS"].ToString();
                    secID = Convert.ToInt32(dr["SECURITYCOMP_ID"]);
                }
                dr.Close();

                // 2) Read the raw SiteID from Posts (view doesn't expose it)
                SqlCommand siteCmd = new SqlCommand(
                    "SELECT SiteID FROM Posts WHERE PostID = @id", con);
                siteCmd.Parameters.AddWithValue("@id", postID);

                object siteResult = siteCmd.ExecuteScalar();
                int siteID = (siteResult == null) ? 0 : Convert.ToInt32(siteResult);

                con.Close();

                // 3) Fill form fields
                txtPostName.Text = postName;
                cmbNumberPerPost.Text = numberPerPost;
                cmbStatus.Text = status;

                // 4) Preselect the security company, then load + preselect its sites
                cmbSecurityCompany.SelectedValue = secID;
                LoadSitesForSecurityCompany(secID, siteID);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        /*
        
       

      
       

        

        
    }
}*/
    }
}