﻿using System;
using System.Data;
using System.Windows.Forms;
using Microsoft.Data.SqlClient;

namespace Security
{
    public partial class EditRegularShiftForm : Form
    {
        SqlConnection con = new SqlConnection(
            "Data Source=DESKTOP-133OPA4\\SQLEXPRESS;" +
            "Initial Catalog=SecureRoster;" +
            "Integrated Security=True;" +
            "Encrypt=False;");

        private int regularShiftID;

        public EditRegularShiftForm(int id)
        {
            InitializeComponent();
            regularShiftID = id;
        }

        private void EditRegularShiftForm_Load(object sender, EventArgs e)
        {
            // Type of shifts
            DataTable dtType = new DataTable();
            // Added DISTINCT
            new SqlDataAdapter("SELECT DISTINCT TypeShiftID, TypeOfShift FROM TypeOfShifts", con).Fill(dtType);
            cmbTypeShift.DataSource = dtType;
            cmbTypeShift.DisplayMember = "TypeOfShift";
            cmbTypeShift.ValueMember = "TypeShiftID";

            // Posts
            DataTable dtPost = new DataTable();
            new SqlDataAdapter("SELECT PostID, PostName FROM Posts", con).Fill(dtPost);
            cmbPost.DataSource = dtPost;
            cmbPost.DisplayMember = "PostName";
            cmbPost.ValueMember = "PostID";

            try
            {
                con.Open();
                SqlCommand cmd = new SqlCommand(
                    @"SELECT TypeShiftID, PostID, NameOfShift
                      FROM RegularShifts WHERE RegularShiftID = @id", con);
                cmd.Parameters.AddWithValue("@id", regularShiftID);

                SqlDataReader dr = cmd.ExecuteReader();
                if (dr.Read())
                {
                    txtNameOfShift.Text = dr["NameOfShift"].ToString();
                    cmbTypeShift.SelectedValue = Convert.ToInt32(dr["TypeShiftID"]);
                    cmbPost.SelectedValue = Convert.ToInt32(dr["PostID"]);
                }
                dr.Close();
                con.Close();
            }
            catch (Exception ex) { MessageBox.Show(ex.Message); }
        }




        private void btnSave_Click(object sender, EventArgs e)
        {
            if (cmbTypeShift.SelectedValue == null ||
                cmbTypeShift.SelectedValue is DataRowView) return;
            if (cmbPost.SelectedValue == null ||
                cmbPost.SelectedValue is DataRowView) return;

            try
            {
                con.Open();
                SqlCommand cmd = new SqlCommand(
                    @"UPDATE RegularShifts
                      SET TypeShiftID = @type,
                          PostID      = @post,
                          NameOfShift = @name
                      WHERE RegularShiftID = @id", con);

                cmd.Parameters.AddWithValue("@type", cmbTypeShift.SelectedValue);
                cmd.Parameters.AddWithValue("@post", cmbPost.SelectedValue);
                cmd.Parameters.AddWithValue("@name", txtNameOfShift.Text);
                cmd.Parameters.AddWithValue("@id", regularShiftID);

                cmd.ExecuteNonQuery();

                MessageBox.Show("Regular Shift Updated");
                con.Close();
                this.Close();
            }
            catch (Exception ex) { MessageBox.Show(ex.Message); }
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    
    }
}