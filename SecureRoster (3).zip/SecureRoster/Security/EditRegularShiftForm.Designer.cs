﻿namespace Security
{
    partial class EditRegularShiftForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            cmbPost = new ComboBox();
            cmbTypeShift = new ComboBox();
            btnCancel = new Button();
            btnSave = new Button();
            label3 = new Label();
            label2 = new Label();
            label1 = new Label();
            txtNameOfShift = new TextBox();
            SuspendLayout();
            // 
            // cmbPost
            // 
            cmbPost.FormattingEnabled = true;
            cmbPost.Location = new Point(159, 56);
            cmbPost.Name = "cmbPost";
            cmbPost.Size = new Size(121, 23);
            cmbPost.TabIndex = 31;
            // 
            // cmbTypeShift
            // 
            cmbTypeShift.FormattingEnabled = true;
            cmbTypeShift.Location = new Point(159, 12);
            cmbTypeShift.Name = "cmbTypeShift";
            cmbTypeShift.Size = new Size(121, 23);
            cmbTypeShift.TabIndex = 30;
            // 
            // btnCancel
            // 
            btnCancel.Location = new Point(272, 253);
            btnCancel.Name = "btnCancel";
            btnCancel.Size = new Size(75, 23);
            btnCancel.TabIndex = 29;
            btnCancel.Text = "Cancel";
            btnCancel.UseVisualStyleBackColor = true;
            btnCancel.Click += btnCancel_Click;
            // 
            // btnSave
            // 
            btnSave.Location = new Point(19, 253);
            btnSave.Name = "btnSave";
            btnSave.Size = new Size(75, 23);
            btnSave.TabIndex = 28;
            btnSave.Text = "Save";
            btnSave.UseVisualStyleBackColor = true;
            btnSave.Click += btnSave_Click;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(17, 106);
            label3.Name = "label3";
            label3.Size = new Size(80, 15);
            label3.TabIndex = 27;
            label3.Text = "Name of Shift";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(17, 56);
            label2.Name = "label2";
            label2.Size = new Size(30, 15);
            label2.TabIndex = 26;
            label2.Text = "Post";
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(17, 12);
            label1.Name = "label1";
            label1.Size = new Size(75, 15);
            label1.TabIndex = 25;
            label1.Text = "Type Of Shift";
            // 
            // txtNameOfShift
            // 
            txtNameOfShift.Location = new Point(159, 103);
            txtNameOfShift.Name = "txtNameOfShift";
            txtNameOfShift.Size = new Size(121, 23);
            txtNameOfShift.TabIndex = 24;
            // 
            // EditRegularShiftForm
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.FromArgb(31, 45, 61);
            ClientSize = new Size(363, 362);
            Controls.Add(cmbPost);
            Controls.Add(cmbTypeShift);
            Controls.Add(btnCancel);
            Controls.Add(btnSave);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(label1);
            Controls.Add(txtNameOfShift);
            Name = "EditRegularShiftForm";
            Text = "EditRegularShiftForm";
            Load += EditRegularShiftForm_Load;
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private ComboBox cmbPost;
        private ComboBox cmbTypeShift;
        private Button btnCancel;
        private Button btnSave;
        private Label label3;
        private Label label2;
        private Label label1;
        private TextBox txtNameOfShift;
    }
}