
--USE master;
IF DB_ID('SecureRoster') IS NULL
    CREATE DATABASE SecureRoster;
GO
USE SecureRoster;
GO

-- COMPANIES
drop table Companies;
CREATE TABLE Companies (
    CompanyID INT PRIMARY KEY,
    CompanyName VARCHAR(50) NOT NULL,
    CompanyCell VARCHAR(20),
    CompanyEmail VARCHAR(50)
);
GO
--SET IDENTITY_INSERT Companies ON;
INSERT INTO Companies
(CompanyID, CompanyName, CompanyCell, CompanyEmail)
VALUES
(2,'Proper Security Solutions', '084 056 8124', 'propersolutions1@gmail.com'),
(10,'iYuniversity Walter Sisulu', '043 708 5200', 'enquiries@wsu.ac.za'),
(3,'Likunga Protection and Security Services', '043 722 8515', 'admin@likungaprotection.com'),
(1,'Silver Solutions', '043 721 0676', 'silversecurity@webmail.co.za'),
(11,'Eastern Cape Department of Health','080 033 2364','callcenter@echealth.gov.za'),
(161, 'Growthpoint Properties', '011 944 6000', 'csi@growthpoint.co.za'),
(142,'Billion Group','011 511 5626','info@billiongroup.co.za'),
(181,'Proper manamegent company', '000 000 0000','propermanagementcomp@gmail.com');
--SET IDENTITY_INSERT Companies ON;
select*from Companies;


-- COUNTRIES

CREATE TABLE Countries (
    CountryID INT PRIMARY KEY,
    CountryName VARCHAR(20) NOT NULL UNIQUE
);
GO
insert into Countries values(1,'South Africa');



-- PROVINCES
CREATE TABLE Provinces (
    ProvinceID INT IDENTITY(1,1) PRIMARY KEY,
    ProvinceName VARCHAR(20) NOT NULL,
    CountryID INT NOT NULL
);
GO

ALTER TABLE Provinces
ADD CONSTRAINT FK_Provinces_Countries
FOREIGN KEY (CountryID)
REFERENCES Countries(CountryID)
ON DELETE CASCADE;
GO
insert into Provinces values ('Eastern Cape',1);



--SUBURBS
CREATE TABLE Suburbs
(
    SuburbID INT PRIMARY KEY,
    SuburbName VARCHAR(20) NOT NULL,
    TownID INT NOT NULL
);
GO

ALTER TABLE Suburbs ADD CONSTRAINT FK_Suburbs_Towns FOREIGN KEY (TownID) REFERENCES Towns(TownID) ON DELETE CASCADE;
GO
insert into Suburbs(SuburbID,SuburbName,TownID) values (22,'Potsdam Road',1),
(263,'Duncan Village',21),(266,'Scenery Park',21),(269,'NU-3',1),
(285,'Buffalo Flats',21),(265,'Vincent',21),(288,'Bonnie Doon',21),
(271,'Beacon Bay',21),(301,'the one and only',41),(302,'the second and other',41),
(21,'Southernwood',21),(262,'Nahoon',21),(270,'Reeston',21),
(1,'Baysville',21),(23,'Argyle',21),(61,'BCC',21),
(81,'Quigney',21),(142,'East London',21),(284,'Mdantsane',21),
(261,'North End',21),(289,'Haven Hills',21),(41,'West Drive',22),
(283,'Amalinda',21),(286,'Berea',21),(267,'Cambridge West',21),
(268,'Braelyn',21),(287,'Summerpride',21),(321,'chisselhurts',21);



-- MUNICIPALITIES
CREATE TABLE Municipalities (
    MunicipalityID INT PRIMARY KEY,
    MunicipalityName VARCHAR(100) NOT NULL,
    ProvinceID INT NOT NULL);
GO

ALTER TABLE Municipalities ADD CONSTRAINT FK_Municipalities_Provinces FOREIGN KEY (ProvinceID) REFERENCES Provinces(ProvinceID) ON DELETE CASCADE; GO

insert into Municipalities values(1,'Buffalo City Metropolitan Municipality',1),(25,'Elundini Local Municipality',1),(3,'Great Kei Local Municipality',1),(6,'Ngqushwa Local Municipality',1),
(7,'Emalahleni Local Municipality',1),(9,'Intsika Yethu Local Municipality',1);
insert into Municipalities values(2,'Amahlathi Local Municipality',1),(4,'Mbhashe Local Municipality',1),(8,'Engcobo Local Municipality',1),(10,'Inxuba Yethemba Local Municipality',1),
(12,'King Sabata Dalindyebo Local Municipality',1),(16,'Dr Beyers Naudé Local Municipality',1);

insert into Municipalities values(17,'Kouga Local Municipality',1),(18,'Kou-Kamma Local Municipality',1),(21,'Nelson Mandela Bay Metropolitan Municipality',1),(5,'MNquma Local Municipality',1),
(23,'Enoch Mgijima Local Municipality',1),(22,'Raymond Mhlaba Local Municipality',1),(24,'Sakhisizwe Local Municipality',1),(26,'Senqu Local Municipality',1),(27,'Ingquza Hill Local Municipality',1),
(19,'Ndlambe Local Municipality',1),(13,'Matatiele Local Municipality',1),(14,'Umzimvubu Local Municipality',1);

insert into Municipalities values(15,'Blue Crane Route Local Municipality',1),(30,'Port St Johns Local Municipality',1),(33,'Makana Local Municipality',1),
(34,'Sundays River Valley Local Municipality',1),(28,'Mhlontlo Local Municipality',1),(31,'Ntabankulu Local Municipality',1),(32,'Winnie Madikizela-Mandela Local Municipality',1),
(29,'Nyandeni Local Municipality',1);


-- CITIES
CREATE TABLE Cities (
    CityID INT PRIMARY KEY,
    CityName VARCHAR(20) NOT NULL,
    MunicipalityID INT NOT NULL
);
GO

ALTER TABLE Cities
ADD CONSTRAINT FK_Cities_Municipalities
FOREIGN KEY (MunicipalityID)
REFERENCES Municipalities(MunicipalityID)
ON DELETE CASCADE;
GO

insert into Cities(CityID,CityName,MunicipalityID) 
values(22,'Komga',3),(25,'Butterworth',5),(47,'Engcobo',8),
(23,'Gqeberha',21),(46,'Komani',23),(1,'East London',1),
(41,'Maclear',25),(42,'Peddie',6),(43,'Lady Frere',7),
(45,'Peddie',6),(26,'Alice',22),(44,'Stutterheim',2),
(24,'Dutywa',4),(27,'Cofimvaba',9);



--TOWNS
CREATE TABLE Towns (
    TownID INT  PRIMARY KEY,
    TownName VARCHAR(100) NOT NULL,
    CityID INT NOT NULL
);
GO

ALTER TABLE Towns
ADD CONSTRAINT FK_Towns_Cities
FOREIGN KEY (CityID)
REFERENCES Cities(CityID)
ON DELETE CASCADE;
GO

insert into Towns values(21,'East London',1),(41,'Bisho',1),(42,'Berlin',1),(1,'Mdantsane',1),(22,'Qonce',1);



-- SECURITYCOMPANIES
CREATE TABLE SecurityCompanies
(
    SecurityCompID INT PRIMARY KEY,
    CompanyID INT ,
    SuburbID INT,

    CONSTRAINT UQ_SecurityCompanies_CompanyID
        UNIQUE (CompanyID)
);
GO

ALTER TABLE SecurityCompanies ADD CONSTRAINT FK_SecurityCompanies_Companies FOREIGN KEY (CompanyID) REFERENCES Companies(CompanyID) ON DELETE CASCADE;
GO

ALTER TABLE SecurityCompanies ADD CONSTRAINT FK_SecurityCompanies_Suburbs FOREIGN KEY (SuburbID) REFERENCES Suburbs(SuburbID) ON DELETE CASCADE;
GO

INSERT INTO SecurityCompanies
(
    SecurityCompID,CompanyID,SuburbID)
VALUES
(3, 3, 21),(1, 1, 1),(2, 2, 23);

GO



CREATE TABLE ClientCompanies
(
    ClientCompID INT PRIMARY KEY,
    CompanyID INT NOT NULL,
    SuburbID INT NULL,

    CONSTRAINT UQ_ClientCompanies_CompanyID
        UNIQUE (CompanyID)
);
GO

ALTER TABLE ClientCompanies ADD CONSTRAINT FK_ClientCompanies_Companies FOREIGN KEY (CompanyID) REFERENCES Companies(CompanyID) ON DELETE CASCADE;
GO

ALTER TABLE ClientCompanies ADD CONSTRAINT FK_ClientCompanies_SuburbsFOREIGN KEY (SuburbID)REFERENCES Suburbs(SuburbID) ON DELETE CASCADE;
GO

INSERT INTO ClientCompanies
( ClientCompID,CompanyID, SuburbID)
VALUES
(2,11,142),(142,142,142),(1,10,22),(161,161,142),(121,181,NULL);

GO

-- SITES
CREATE TABLE Sites
( SiteID INT PRIMARY KEY,
    NameOfSite VARCHAR(90),
    SiteCapacity INT,
    ClientCompID INT,
    SecurityCompID INT,
    SuburbID INT,

    CONSTRAINT CK_Sites_Capacity
        CHECK (SiteCapacity > 0),

    CONSTRAINT UQ_Sites_ClientCompany_SiteName
        UNIQUE (ClientCompID, NameOfSite));
GO

ALTER TABLE SitesADD CONSTRAINT FK_Sites_ClientCompaniesFOREIGN KEY (ClientCompID)REFERENCES ClientCompanies(ClientCompID)ON DELETE CASCADE;
GO

ALTER TABLE Sites ADD CONSTRAINT FK_Sites_SecurityCompanies FOREIGN KEY (SecurityCompID) REFERENCES SecurityCompanies(SecurityCompID) ON DELETE CASCADE; GO

ALTER TABLE SitesADD CONSTRAINT FK_Sites_SuburbsFOREIGN KEY (SuburbID)REFERENCES Suburbs(SuburbID)ON DELETE CASCADE;
GO

INSERT INTO Sites
(SiteID,NameOfSite,SiteCapacity,ClientCompID,SecurityCompID,SuburbID)VALUES
(302,'Jabuvo Street Clinic',10,2,2,1),(301,'Cambridge Clinic',10,2,2,1),(323,'Vincent Park Mall',10,161,3,1),(181,'College Street Campus',10,1,1,22),
(1,'Potsdam Campus',10,1,1,22),(324,'Mdantsane City Shopping Centre',10,142,3,1);

GO

-- PERSONS

CREATE TABLE Persons (
    PersonID INT PRIMARY KEY, FirstName VARCHAR(50), LastName VARCHAR(50),  Email VARCHAR(50), Gender VARCHAR(1),
    Username VARCHAR(50), CellNumber VARCHAR(15) DEFAULT '0',D_Number VARCHAR(20),    SUBURB_ID INT,    DESCRIPTION_ VARCHAR(30)
);
GO
 
INSERT INTO Persons
(PersonID, FirstName, LastName, Email, Gender, Username, CellNumber, ID_Number,SUBURB_ID,DESCRIPTION_)
VALUES

(3,'Lerato','Zondo','leratozondo@gmail.com','F','leratozondo','0784579856','0112225023086',21,'SilverPotsdamGuard1'),(1,'John','Brown','johnbrown@gmail.com','M','johnbrown','0947854249','9604151427589',22, 'SilverPotsdamSupervisor1'),
(4,'Thabiso','Mokwena','thabisomokwena@gmail.com','M','thabisomokwena','0797154784','9102317598467',22,'SilverManager1'),(2,'Zintle','Khumalo','zintlekhumalo@gmail.com','F','zintlekhumalo','0758486759','9503240157867',21,'SilverPotsdamGuard2'),
(9,'Base','Tsana','BaseTsana@gmail.com','F','BASETSANA','0487594867','8508250764895',22,'SilverPotsdamGuard3'),(19,'Lihle','Ndaba','lihlendaba@gmail.com','F','LihleNdaba','0487594768','8709120974867',21,'SilverPotsdamGuard4'),
(6,'James','Malvin','jamesmalvin@gmail.com','M','jamal5ITAdmin','0797154784','9707075124083',21,'SilverITAdmin1');
INSERT INTO Persons(PersonID, FirstName, LastName, Email, Gender, Username, CellNumber, ID_Number,SUBURB_ID,DESCRIPTION_)
VALUES(87,'Bongani','Khumalo','bonganikhumalo@gmail.com','M','bonganikhumalo','0767891006','8806065006086',284,'ProperCambridgeGuard8'),(110,'Nandi','Buthelezi','nandibuthelezi@gmail.com','F','nandibuthelezi','0879123017','9708175017097',288,'ProperJabavuGuard1'),
(114,'Khanyisa','Tshabalala','khanyisatshabalala@gmail.com','F','khanyisatshabalala','0892345019','9410195019099',289,'ProperJabavuGuard2'),(85,'Ayanda','Dlamini','ayanda.dlamini@gmail.com','F','AyandaDlamini','0756789005','9305055005085',283,'ProperCambridgeGuard10'),
(108,'Vuyo','Mabena','vuyomabena@gmail.com','M', 'vuyomabena', '0868912016', '9007165016096', 287, 'ProperJabuvoGuard8'),(120,'Olwethu','Msimang','olwethu.msimang@gmail.com','M','olwethumsimang','0725678022','9202225022022',81,'ProperJabavuGuard4'),
(118,'Liyema','Jacobs','liyemajacobs@gmail.com','F','liyemajacobs','0714567021','9501215021021',21,'ProperJabavuGuard5'),(100,'Siyabonga','Cele','siyabonga.cele@gmail.com','M','siyabongacele','0824567012','9203125012092',286,'ProperCambridgeGuard4'),
(95,'Themba','Sithole','thembasithole@gmail.com','M','thembasithole','0802345010','8701105010090',285,'SilverCollegeGuard1'),(65,'Themba','Mhlongo','themba.mhlongo@gmail.com','M','thembaM','0826789012','8902025801081',22,'SilverPotsdamGuard7'),
(130,'Thando','Mbeki','thando.mbeki@gmail.com','M','thando.mbeki','0712345001','0001015001081',81,'SilverCollegeSupervisor1'),(68,'Mandla','Gcaba','mandla.gcaba@gmail.com','M','mandlaG','0769012345','8705055801384',23,'SilverPotsdamGuard10'),
(116,'Mthokozisi','Gumede','mthokozisigumede@gmail.com','M','mthokozisigumede','0903456020','8811205020100',270,'ProperJabavuGuard7'),(124,'Siyanda','Peterson','siyandapeterson@gmail.com','M','siyandapeterson','0747891024','9004245024024',271,'ProperCambridgeSupervisor1'),
(101,'Ntandokazi','Mavuso','ntandokazimavuso@gmail.com','F','NtandokaziMavuso','0874597864','980521547854',1,'ProperManager1'),(106,'Asanda','Gqoboka','asandagqoboka@gmail.com','F','asandagqoboka','0857891015','9306155015095',268,'ProperJabavuGuard8'),
(122,'Anathi','Radebe','anathi.radebe@gmail.com','F','anathiradebe','0736789023','9603235023023',283,'ProperJabavuGuard9'),(72,'Buhle','Mbatha','buhle.mbatha@gmail.com','F','buhleM','0790123456','9406064801485',23,'SilverPotsdamGuard5'),
(32,'Thandi','Dlamini','thandidlamini@gmail.com','F','ThandiDlamini','0876598465','9202150187084',22,'SilverPotsdamGuard6'),(201,'Nomsa','Zulu','nomsazulu@gmail.com','F','NomsaZulu','0831234567','8906064800586',1,'LikunguManager1'),
(91,'Lunga','Ntuli','lungantuli@test.com','M','lungantuli','0789123008','9108085008088',262,'ProperCambridgeGuard2'),(102,'Nosipho','Jali','nosiphojali@gmail.com','F','nosiphojali','0835678013','9504135013093',266,'ProperCambridgeGuard1'),
(104,'Mandla','Hadebe','mandlahadebe@gmail.com','M','mandlahadebe','0846789014','8905145014094',267,'ProperCambridgeGuard7'),(112,'Sibusiso','Maseko','sibusisomaseko@gmail.com','M','sibusisomaseko','0881234018','9109185018098',269,'SilverCollegeGuard2'),
(33,'Sipho','Matlala','siphomatlala@gmail.com','M','siphom03','0457894357','8803305231081',21,'SilverPotsdamGuard7'),(98,'Precious','Molefe','preciousmolefe@gmail.com','F','preciousmolefe','0813456011','9602115011091',265,'ProperCambridgeGuard6'),
(81,'Sipho','Ndlovu','siphondlovu@gmail.com','M','SiphoNdlovu','0734567003','8903035003083',261,'ProperCambridgeGuard9'),(125,'Yanga','Mthethwa','yangamthethwa@gmail.com','F','yangamthethwa','0758912025','9305255025025',21,'ProperJabavuSupervisor1'),
(89,'Zanele','Mthembu','zanelemthembu@gmail.com','F','zanelemthembu','0778912007','9507075007087',81,'ProperCambridgeGuard5'),(67,'Lethabo','Phiri','lethabo.phiri@gmail.com','F','lethaboP','0818901234','9604044801283',23,'SilverPotsdamGuard9'),
(93,'Nokuthula','Mkhize','nokuthulamkhize@gmail.com','F','nokuthulamkhize','0791234009','9409095009089',263,'ProperCambridgeGuard3');

GO

-- ITADMINS
CREATE TABLE ITAdmins (
    ITAdminID INT PRIMARY KEY,
    PersonID INT NOT NULL,
    CompanyID INT NOT NULL
);
GO
ALTER TABLE ITAdmins ADD CONSTRAINT FK_ITAdmins_Persons FOREIGN KEY (PersonID)
    REFERENCES Persons(PersonID) ON DELETE CASCADE;
ALTER TABLE ITAdmins
ADD CONSTRAINT FK_ITAdmins_SecurityCompanies FOREIGN KEY (CompanyID)
    REFERENCES SecurityCompanies(SecurityCompID);
GO

insert into ITAdmins(ITAdminID,PersonID, CompanyID) values(1,6,1);


-- MANAGERS
CREATE TABLE Managers (
    ManagerID INT PRIMARY KEY,
    PersonID INT NOT NULL,
    CompanyID INT NOT NULL
);
GO
ALTER TABLE Managers
ADD CONSTRAINT FK_Managers_Persons FOREIGN KEY (PersonID)
    REFERENCES Persons(PersonID) ON DELETE CASCADE;
ALTER TABLE Managers
ADD CONSTRAINT FK_Managers_SecurityCompanies FOREIGN KEY (CompanyID)
    REFERENCES SecurityCompanies(SecurityCompID) ON DELETE CASCADE;
GO

insert into Managers(ManagerID,PersonID,CompanyID) values(42,201,3),
(61,101,2),(1,4,1);

select*from Managers;

-- SUPERVISORS
CREATE TABLE Supervisors (
    SupervisorID INT PRIMARY KEY,
    PersonID INT ,
    SiteID INT
);
GO
ALTER TABLE Supervisors
ADD CONSTRAINT FK_Supervisors_Persons FOREIGN KEY (PersonID)
    REFERENCES Persons(PersonID) ON DELETE CASCADE;
ALTER TABLE Supervisors
ADD CONSTRAINT FK_Supervisors_Sites FOREIGN KEY (SiteID)
    REFERENCES Sites(SiteID) ON DELETE CASCADE;
GO

insert into Supervisors(SupervisorID,PersonID,SiteID) values(1,1,1);
insert into Supervisors(SupervisorID,PersonID,SiteID) values
(142,125,302),
(141,124,301),
(161,130,181);

select*from Supervisors;

-- GUARDS

CREATE TABLE Guards (
    GuardID INT PRIMARY KEY,
    PersonID INT NOT NULL,
    SiteID INT NOT NULL);
GO
ALTER TABLE Guards
ADD CONSTRAINT FK_Guards_Persons FOREIGN KEY (PersonID)
    REFERENCES Persons(PersonID) ON DELETE CASCADE;
ALTER TABLE Guards
ADD CONSTRAINT FK_Guards_Sites FOREIGN KEY (SiteID)
    REFERENCES Sites(SiteID) ON DELETE CASCADE;
GO

SET IDENTITY_INSERT Guards ON;
insert  into Guards(GuardID,PersonID,SiteID) values(90,89,301),(36,33,1),(76,67,1),(94,93,301),(103,102,301),(113,112,181),(74,72,1),(96,95,181),(99,98,301),
(111,110,302),(3,9,1),(70,19,1),(73,32,1),(75,68,1),( 92,91,301),(117,116,302),(119,118,302),(82,81,301),(35,32,1),(1,2,1),(88,87,301),(115,114,302),(121,120,302),
(86,85,301),(69,3,1),(101,100,301),(105,104,302),(107,106,302),(109,108,302),(123,122,302);

insert into Guards(GuardID,PersonID,SiteID) values(35,32,1),(1,2,1);
SET IDENTITY_INSERT Guards OFF;


-- POSTS
CREATE TABLE Posts (
    PostID INT PRIMARY KEY,
    SiteID INT NOT NULL,
    PostName VARCHAR(20),
    NumberPerPost INT,
    PStatus VARCHAR(10) DEFAULT 'ACTIVE');
GO
ALTER TABLE Posts ADD CONSTRAINT FK_Posts_Sites FOREIGN KEY (SiteID)  REFERENCES Sites(SiteID); GO
ALTER TABLE Posts ADD CONSTRAINT FK_Posts_Sites FOREIGN KEY (SiteID) REFERENCES Sites(SiteID) ON DELETE CASCADE; GO

INSERT INTO Posts
(PostID,SiteID, PostName, NumberPerPost, PStatus)
VALUES
(1,1,'New Residence',4,'Active'),(21,1,'Field',4,'Temporary'),
(2,1,'Library',2,'Active'),(181,301,'Main Entrance',2,'Active'),
(182,301,'Emergency Room',2,'Active'),(22,1,'SisaDukashe Stadium',5,'Temporary'),
(201,301,'Phamarcy',2,'Active'),(3,1,'Old Residence',4,'Active');



-- TYPEOFSHIFTS
CREATE TABLE TypeOfShifts (
    TypeShiftID INT IDENTITY(1,1) PRIMARY KEY,
    TypeOfShift VARCHAR(20),
    StartTime VARCHAR(5),
    EndTime VARCHAR(5)
);
GO
insert into TypeOfShifts(TypeOfShift,StartTime,EndTime) values
('Day','06H00','18H00'),
('Night','18H00','06H00'),
('Overtime Day','06H00','18H00'),
('Overtime Night','18H00','06H00');

select*from TypeOfShifts;

-- REGULARSHIFTS
CREATE TABLE RegularShifts (
    RegularShiftID INT PRIMARY KEY,
    TypeShiftID INT NOT NULL,
    PostID INT NULL,
    NameOfShift VARCHAR(40)
);
GO
ALTER TABLE RegularShifts ADD CONSTRAINT FK_RegularShifts_TypeOfShifts FOREIGN KEY (TypeShiftID) REFERENCES TypeOfShifts(TypeShiftID);
ALTER TABLE RegularShifts ADD CONSTRAINT FK_RegularShifts_Posts FOREIGN KEY(PostID) REFERENCES Posts(PostID); GO

insert into RegularShifts(RegularShiftID,TypeShiftID,PostID,NameOfShift) values
(1,1,1,'Day At New Residence'),
(3,1,2,'Day At the Library'),
(2,2,1,'Night At New Residence'),
(10,3,1,'Overtime Day At Library'),
(11,4,1,'Overtime Night At New Residence'),
(4,2,2,'Night At the Library'),
(12,3,2,'Overtime Day At Library');
go


-- SPECIALSHIFTS
CREATE TABLE SpecialShifts (
    SpecialShiftID INT PRIMARY KEY,
    PostID INT NULL,
    NameOfShift VARCHAR(20),
    StartTime VARCHAR(5),
    EndTime VARCHAR(5),
    SpecialShiftDate varchar(20)
);
GO
ALTER TABLE SpecialShifts ADD CONSTRAINT FK_SpecialShifts_Posts FOREIGN KEY(PostID) REFERENCES Posts(PostID);

insert into SpecialShifts(SpecialShiftID,PostID,NameOfShift,StartTime,EndTime,SpecialShiftDate) values(61,21,'Soccer Tournament','13H00','15H00','20/07/2026'),
(1,21,'Fresher Bash','17H00','00H00','25/03/2026'),(2,22,'Rugby Tournament','15H00','22H00','14/02/2026');




select*from Rosters;

CREATE TABLE Rosters
(   RosterID INT PRIMARY KEY,
    StartDate DATE,
    EndDate DATE,
    RosterName VARCHAR(100),
    SiteID INT,
    SupervisorID INT,
    CreatedDate DATE,
    RosterStatus VARCHAR(50)
);
GO

ALTER TABLE Rosters ADD CONSTRAINT FK_Rosters_Sites FOREIGN KEY (SiteID) REFERENCES Sites(SiteID) ON DELETE CASCADE; GO
ALTER TABLE Rosters ADD CONSTRAINT FK_Rosters_Supervisors FOREIGN KEY (SupervisorID) REFERENCES Supervisors(SupervisorID) ON DELETE NO ACTION; GO

INSERT INTO Rosters
(RosterID,StartDate,EndDate,RosterName,SiteID,SupervisorID,CreatedDate,RosterStatus)
VALUES
(381,'2026-09-13','2026-09-19','3rd week of September',1,1,'2026-09-19','WORKING ON IT!'); GO



-- REGULARSHIFTASSIGNMENTS
CREATE TABLE RegularShiftsAssignments
(
    AssignmentID INT  PRIMARY KEY,
    GuardID INT NOT NULL,
    RosterDayID INT NOT NULL,
    RegularShiftID INT NULL,
    CONSTRAINT UQ_RegularShiftsAssignments_Guard_RosterDay  UNIQUE (GuardID, RosterDayID),
    CONSTRAINT UQ_RegularShiftsAssignments_RosterDay_Shift_Guard  UNIQUE (RosterDayID, RegularShiftID, GuardID) );
GO
ALTER TABLE RegularShiftsAssignments ADD CONSTRAINT FK_RegularShiftsAssignments_Guards FOREIGN KEY (GuardID) REFERENCES Guards(GuardID) ON DELETE CASCADE; GO
ALTER TABLE RegularShiftsAssignmentsADD CONSTRAINT FK_RegularShiftsAssignments_RosterDaysFOREIGN KEY (RosterDayID)REFERENCES RosterDays(RosterDayID) ON DELETE CASCADE; GO
ALTER TABLE RegularShiftsAssignments ADD CONSTRAINT FK_RegularShiftsAssignments_RegularShiftsFOREIGN KEY (RegularShiftID)REFERENCES RegularShifts(RegularShiftID) ON DELETE CASCADE; GO
--SET IDENTITY_INSERT RegularShiftAssignments ON;
INSERT INTO RegularShiftsAssignments
(AssignmentID,GuardID, RosterDayID, RegularShiftID)VALUES
(446,69,327,3),(447,76,327,3),(443,76,322,3),( 445,75,323,3),( 444,70,323,3),( 452,35,321,1),( 442,69,322,3),( 454, 70,324,4),(451, 1,321, 1);
INSERT INTO RegularShiftsAssignments
(AssignmentID,GuardID, RosterDayID, RegularShiftID)
VALUES (441,74,321,3),(453,73,322,4),(424,35,325,3),(422,36,324,3),(433,69,323,4),(434,75,324,4),(425,1,325,3),(430,36,322,4),(421,3,321,3),(427,74,326,3),(423,73,324,3),(426,3,326,3),(432,76,323,4);
--SET IDENTITY_INSERT RegularShiftAssignments Off;


-- ATTENDANCES
CREATE TABLE Attendances (
    AttendanceID INT PRIMARY KEY,
    CheckInTime VARCHAR(5) DEFAULT '00H00',
    CheckOutTime VARCHAR(5) DEFAULT '00H00',
    AttendanceStatus VARCHAR(10),
    AssignmentID INT NULL);
GO
ALTER TABLE Attendances DROP CONSTRAINT FK_Attendances_RegularShiftsAssignments; GO
ALTER TABLE Attendances ADD CONSTRAINT FK_Attendances_RegularShiftsAssignments FOREIGN KEY (AssignmentID) REFERENCES RegularShiftsAssignments(AssignmentID) ON DELETE CASCADE; GO

insert into Attendances values(361,'18H00','06H00','P',453),
(341,'06H00','18H03','P',442),
(343,'18H00','06H00','P',430),
(344,'06H00','18H03','P',444),(342,'06H00','18H03','P',443);


/*-- OVERTIMES
CREATE TABLE Overtimes (
    OvertimeID INT PRIMARY KEY,
    AssignmentID INT NULL,
    CheckInTime VARCHAR(5) DEFAULT '00H00',
    CheckOutTime VARCHAR(5) DEFAULT '00H00',
    OStatus VARCHAR(10) DEFAULT 'PENDING');
GO
ALTER TABLE Overtimes DROP CONSTRAINT FK_Overtimes_RegularShiftsAssignments; GO

ALTER TABLE Overtimes
ADD CONSTRAINT FK_Overtimes_RegularShiftsAssignments FOREIGN KEY (AssignmentID)
REFERENCES RegularShiftsAssignments(AssignmentID)
ON DELETE CASCADE;
GO

insert into Overtimes values(1,446,'17H55','06H00','Accepted');
drop table overtimes;*/

-- TYPEOFLEAVES
CREATE TABLE TypeOfLeaves (
    TypeOfLeaveID INT PRIMARY KEY,
    TypeOfLeave VARCHAR(20),
    MaxDuration VARCHAR(20)
);
GO
--SET IDENTITY_INSERT TypeOfLeaves ON;
INSERT INTO TypeOfLeaves(TypeOfLeaveID, TypeOfLeave, MaxDuration)
VALUES(1,'Sick Leave','10 Days'),
(23,'Study Leave','60 Days'),
(2,'Annual Leave','21 Days'),
(4,'Paternity Leave','14 Days'),
(21,'Maternity Leave','90 Days'),
(22,'Unpaid Leave','30 Days'),
(24,'Overtime Rest','2 Days');
--SET IDENTITY_INSERT TypeOfLeaves Off;
select*from TypeOfLeaves;

-- LEAVES
CREATE TABLE Leaves (
    LeaveID INT PRIMARY KEY,
    GuardID INT NOT NULL,
    StartDate VARCHAR(10),
    EndDate VARCHAR(10),
    LeaveTypeID INT,
    LeaveReason VARCHAR(100),
    LeaveStatus varchar(10) );
GO
ALTER TABLE Leaves
ADD CONSTRAINT FK_Leaves_Guards FOREIGN KEY (GuardID)
    REFERENCES Guards(GuardID) ON DELETE CASCADE;
GO
ALTER TABLE Leaves
ADD CONSTRAINT FK_Leaves_TypeOfLeaves FOREIGN KEY (LeaveTypeID)
REFERENCES TypeOfLeaves(TypeOfLeaveID);

insert into Leaves(LeaveID,GuardID,StartDate,EndDate,LeaveTypeID,LeaveReason,LeaveStatus) values(241,3,'19/09/2026','21/09/2026',1,'NEEDED','NULL');



-- ROSTERDAYS
CREATE TABLE RosterDays (
    RosterDayID INT PRIMARY KEY,
    Roster_ID INT NOT NULL,
    ShiftDate DATE NOT NULL
);
GO
ALTER TABLE RosterDays ADD CONSTRAINT FK_RosterDays_Rosters
FOREIGN KEY (Roster_ID) REFERENCES Rosters(Roster_ID) ON DELETE CASCADE;
GO
insert into RosterDays(RosterDayID, Roster_ID, ShiftDate) values(7, 65, '8/10/2026'),
(8, 65, '8/11/2026'),(9, 65, '8/12/2026'),(10, 65, '8/13/2026'),(11, 65, '8/14/2026'),
(12, 65, '8/15/2026'),(13, 65, '8/16/2026'),(14, 66, '8/10/2026'),(15, 66, '8/11/2026'),
(16, 66, '8/12/2026'),(17, 66, '8/13/2026'),(18, 66, '8/14/2026'),(19, 66, '8/15/2026'),
(20, 66, '8/16/2026'),(28, 81, '8/18/2026'),(29, 81, '8/19/2026'),(27, 81, '8/17/2026'),
(30, 81, '8/20/2026'),(31, 81, '8/21/2026'),(32, 81, '8/22/2026'),(33, 81, '8/23/2026'),
(34, 82, '8/17/2026'),(35, 82, '8/18/2026'),(36, 82, '8/19/2026'),(37, 82, '8/20/2026'),
(38, 82, '8/21/2026'),(39, 82, '8/22/2026'),(40, 82, '8/23/2026'),(322,381,'9/14/2026'),
(323,381,'9/15/2026'),(321,381,'9/13/2026'),(324,381,'9/16/2026'),(325,381,'9/17/2026'),
(326,381,'9/18/2026'),(327,381,'9/19/2026');



--SPECIALSHIFTSASSIGNMENTS
CREATE TABLE SpecialShiftsAssignments
(
    SpecialShiftAssignID INT PRIMARY KEY,
    GuardID INT NOT NULL,
    SpecialShiftID INT NOT NULL
);
GO

ALTER TABLE SpecialShiftsAssignmentsADD CONSTRAINT FK_SpecialShiftsAssignments_Guards
FOREIGN KEY (GuardID)REFERENCES Guards(GuardID)
ON DELETE CASCADE;
GO

ALTER TABLE SpecialShiftsAssignmentsADD CONSTRAINT FK_SpecialShiftsAssignments_SpecialShifts
FOREIGN KEY (SpecialShiftID)REFERENCES SpecialShifts(SpecialShiftID)
ON DELETE CASCADE;
GO
insert into SpecialShiftsAssignments(SpecialShiftAssignID,GuardID,SpecialShiftID) values(1,1,61),(2,69,1);


CREATE OR ALTER VIEW GuardsView
AS
SELECT
    g.GuardID AS GUARD_ID,
    g.PersonID AS PERSON_ID,
    g.SiteID AS SITE_ID,
    p.FirstName AS FIRSTNAME,
    p.LastName AS LASTNAME,
    p.ID_Number AS IDNUMBER,
    p.Gender AS GENDER,
    p.CellNumber AS CELLNUMBER,
    cc.ClientCompID AS CLIENTCOMP_ID,
    c.CompanyName AS COMPANYNAME,
    s.NameOfSite AS NAMEOFSITE,
    sc.SecurityCompID AS SECURITYCOMP_ID
FROM Guards g
INNER JOIN Persons p
    ON g.PersonID = p.PersonID
INNER JOIN Sites s
    ON g.SiteID = s.SiteID
INNER JOIN ClientCompanies cc
    ON s.ClientCompID = cc.ClientCompID
INNER JOIN SecurityCompanies sc
    ON s.SecurityCompID = sc.SecurityCompID
INNER JOIN Companies c
    ON cc.CompanyID = c.CompanyID;
GO
SELECT * FROM GuardsView;

CREATE OR ALTER VIEW GuardAttendanceDetails
AS
SELECT
    a.AttendanceID AS ATTENDANCE_ID,
    p.Username AS USERNAME,
    p.FirstName AS FIRSTNAME,
    p.LastName AS LASTNAME,
    rd.ShiftDate AS SHIFTDATE,
    rs.NameOfShift AS NAMEOFSHIFT,
    ts.StartTime AS STARTTIME,
    a.CheckInTime AS CHECKINTIME,
    ts.EndTime AS ENDTIME,
    a.CheckOutTime AS CHECKOUTTIME,
    po.PostName AS POSTNAME,
    s.NameOfSite AS NAMEOFSITE,
    a.AttendanceStatus AS ATTENDANCESTATUS
FROM Attendances a
INNER JOIN RegularShiftsAssignments rsa
    ON a.AssignmentID = rsa.AssignmentID
INNER JOIN Guards g
    ON rsa.GuardID = g.GuardID
INNER JOIN Persons p
    ON g.PersonID = p.PersonID
INNER JOIN RosterDays rd
    ON rsa.RosterDayID = rd.RosterDayID
INNER JOIN RegularShifts rs
    ON rsa.RegularShiftID = rs.RegularShiftID
INNER JOIN Posts po
    ON rs.PostID = po.PostID
INNER JOIN Sites s
    ON po.SiteID = s.SiteID
INNER JOIN TypeOfShifts ts
    ON rs.TypeShiftID = ts.TypeShiftID;
GO
select* from GuardLeaveDetails;

CREATE OR ALTER VIEW GuardLeaveDetails
AS
SELECT
    p.Username AS USERNAME,
    p.FirstName AS FIRSTNAME,
    p.LastName AS LASTNAME,
    tol.TypeOfLeave AS TYPEOFLEAVE,
    l.StartDate AS STARTDATE,
    l.EndDate AS ENDDATE,
    p.CellNumber AS CELLNUMBER,
    l.LeaveTypeID AS LEAVETYPE_ID,
    l.LeaveReason AS LEAVEREASON
FROM Leaves l
INNER JOIN Guards g
    ON l.GuardID = g.GuardID
INNER JOIN Persons p
    ON g.PersonID = p.PersonID
INNER JOIN TypeOfLeaves tol
    ON l.LeaveTypeID = tol.TypeOfLeaveID;
GO


CREATE OR ALTER VIEW GuardLeaveApplicationDetails
AS
SELECT 
    l.LeaveID AS LEAVE_ID,
    p.Username AS USERNAME,
    p.FirstName AS FIRSTNAME,
    p.LastName AS LASTNAME,
    tol.TypeOfLeave AS TYPEOFLEAVE,
    l.StartDate AS STARTDATE,
    l.EndDate AS ENDDATE,
    l.LeaveReason AS LEAVEREASON,
    tol.MaxDuration AS MAXDAYS,
    p.CellNumber AS CELLNUMBER,
    l.LeaveStatus AS LEAVESTATUS
FROM Leaves l
INNER JOIN Guards g ON l.GuardID = g.GuardID
INNER JOIN Persons p ON g.PersonID = p.PersonID
INNER JOIN TypeOfLeaves tol ON l.LeaveTypeID = tol.TypeOfLeaveID;
GO


select*from GuardRegularShiftsDetails;
CREATE OR ALTER VIEW GuardRegularShiftsDetails
AS
SELECT
    rd.ShiftDate AS SHIFTDATE,
    p.Username AS USERNAME,
    p.FirstName AS FIRSTNAME,
    p.LastName AS LASTNAME,
    rs.NameOfShift AS NAMEOFSHIFT,
    ts.TypeOfShift AS TYPEOFSHIFT,
    s.NameOfSite AS NAMEOFSITE,
    po.PostName AS POSTNAME,
    r.StartDate AS STARTDATE,
    r.EndDate AS ENDDATE,
    ts.StartTime AS STARTTIME,
    ts.EndTime AS ENDTIME
FROM RegularShiftsAssignments rsa
INNER JOIN Guards g
    ON rsa.GuardID = g.GuardID
INNER JOIN Persons p
    ON g.PersonID = p.PersonID
INNER JOIN RosterDays rd
    ON rsa.RosterDayID = rd.RosterDayID
INNER JOIN Rosters r
    ON rd.Roster_ID = r.RosterID
INNER JOIN RegularShifts rs
    ON rsa.RegularShiftID = rs.RegularShiftID
INNER JOIN Posts po
    ON rs.PostID = po.PostID
INNER JOIN Sites s
    ON po.SiteID = s.SiteID
INNER JOIN TypeOfShifts ts
    ON rs.TypeShiftID = ts.TypeShiftID;
GO


CREATE OR ALTER VIEW GuardsDetails
AS
SELECT
    p.Username AS USERNAME,
    p.FirstName AS FIRSTNAME,
    p.LastName AS LASTNAME,
    p.Email AS EMAIL,
    p.Gender AS GENDER,
    p.CellNumber AS CELLNUMBER,
    p.ID_Number AS IDNUMBER,
    s.NameOfSite AS NAMEOFSITE,
    c.CompanyName AS COMPANYNAME
FROM Guards g
INNER JOIN Persons p
    ON g.PersonID = p.PersonID
INNER JOIN Sites s
    ON g.SiteID = s.SiteID
INNER JOIN SecurityCompanies sc
    ON s.SecurityCompID = sc.SecurityCompID
INNER JOIN Companies c
    ON sc.CompanyID = c.CompanyID;
GO
select*from GuardSpecialShifts;

CREATE OR ALTER VIEW GuardSpecialShifts
AS
SELECT
    g.GuardID AS GUARD_ID,
    ss.SpecialShiftDate AS SPECIALSHIFTDATE,
    p.Username AS USERNAME,
    p.FirstName AS FIRSTNAME,
    p.LastName AS LASTNAME,
    ss.NameOfShift AS NAMEOFSHIFT,
    ss.StartTime AS STARTTIME,
    ss.EndTime AS ENDTIME,
    po.PostName AS POSTNAME
FROM SpecialShiftsAssignments ssa
INNER JOIN Guards g
    ON ssa.GuardID = g.GuardID
INNER JOIN Persons p
    ON g.PersonID = p.PersonID
INNER JOIN SpecialShifts ss
    ON ssa.SpecialShiftID = ss.SpecialShiftID
INNER JOIN Posts po
    ON ss.PostID = po.PostID;
GO
select*from GuardsProfile;
CREATE OR ALTER VIEW GuardsProfile
AS
SELECT
    p.PersonID AS PERSON_ID,
    p.FirstName AS FIRSTNAME,
    p.LastName AS LASTNAME,
    p.Email AS EMAIL,
    p.Gender AS GENDER,
    p.Username AS USERNAME,
    p.CellNumber AS CELLNUMBER,
    p.ID_Number AS IDNUMBER,
    s.NameOfSite AS NAMEOFSITE,
    c.CompanyName AS COMPANYNAME
FROM Persons p
INNER JOIN Guards g
    ON p.PersonID = g.PersonID
INNER JOIN Sites s
    ON g.SiteID = s.SiteID
INNER JOIN SecurityCompanies sc
    ON s.SecurityCompID = sc.SecurityCompID
INNER JOIN Companies c
    ON sc.CompanyID = c.CompanyID;
GO

CREATE OR ALTER VIEW ManagerClientCompany
AS
SELECT
    c.CompanyName AS COMPANYNAME,
    c.CompanyCell AS COMPANYCELL,
    c.CompanyEmail AS COMPANYEMAIL
FROM ClientCompanies cc
INNER JOIN Companies c
    ON cc.CompanyID = c.CompanyID;
GO

CREATE OR ALTER VIEW ManagerClientCompanyDetails
AS
SELECT
    c.CompanyID AS COMPANY_ID,
    c.CompanyName AS COMPANYNAME,
    c.CompanyCell AS COMPANYCELL,
    c.CompanyEmail AS COMPANYEMAIL
FROM Companies c
INNER JOIN ClientCompanies cc
    ON c.CompanyID = cc.CompanyID;
GO


USE SecureRoster;
GO

-- Drop the broken view
DROP VIEW IF EXISTS ManagerLeaveApplicationDetails;
GO

-- Recreate it with the correct JOINs
CREATE VIEW ManagerLeaveApplicationDetails
AS
SELECT
    l.LeaveID AS LEAVE_ID,
    p.Username AS USERNAME,
    p.FirstName AS FIRSTNAME,
    p.LastName AS LASTNAME,
    tol.TypeOfLeave AS TYPEOFLEAVE,
    l.StartDate AS STARTDATE,
    l.EndDate AS ENDDATE,
    l.LeaveReason AS LEAVEREASON,
    tol.MaxDuration AS MAXDAYS,
    p.CellNumber AS CELLNUMBER,
    l.LeaveStatus AS LEAVESTATUS
FROM Leaves l
INNER JOIN Guards g ON l.GuardID = g.GuardID
INNER JOIN Persons p ON g.PersonID = p.PersonID
INNER JOIN TypeOfLeaves tol ON l.LeaveTypeID = tol.TypeOfLeaveID;
GO

-- Test it to make sure it works
SELECT * FROM ManagerLeaveApplicationDetails;

CREATE OR ALTER VIEW ManagersDetailsView
AS
SELECT
    p.PersonID,
    p.FirstName,
    p.LastName,
    p.Email,
    p.Gender,
    p.Username,
    p.CellNumber,
    p.ID_Number,
    p.Suburb_ID,
    s.SuburbName,
    s.TownID,
    t.TownName,
    t.CityID,
    c.CityName,
    m.ManagerID,
    sc.SecurityCompID,
    co.CompanyID,
    co.CompanyName,
    co.CompanyCell,
    co.CompanyEmail
FROM Managers m
INNER JOIN Persons p
    ON m.PersonID = p.PersonID
INNER JOIN Suburbs s
    ON p.Suburb_ID = s.SuburbID
INNER JOIN Towns t
    ON s.TownID = t.TownID
INNER JOIN Cities c
    ON t.CityID = c.CityID
INNER JOIN SecurityCompanies sc
    ON m.CompanyID = sc.SecurityCompID
INNER JOIN Companies co
    ON sc.CompanyID = co.CompanyID;
GO

CREATE OR ALTER VIEW ManagerClientCompanyDetails
AS
SELECT
    c.CompanyID,
    c.CompanyName,
    c.CompanyCell,
    c.CompanyEmail
FROM ClientCompanies cc
INNER JOIN Companies c
    ON cc.CompanyID = c.CompanyID;
GO
USE SecureRoster;
GO

CREATE OR ALTER VIEW ManagerClientCompanyDetails
AS
SELECT
    cc.ClientCompID     AS CLIENTCOMP_ID,
    c.CompanyID         AS COMPANY_ID,
    c.CompanyName       AS COMPANYNAME,
    c.CompanyCell       AS COMPANYCELL,
    c.CompanyEmail      AS COMPANYEMAIL
FROM ClientCompanies cc
INNER JOIN Companies c
    ON cc.CompanyID = c.CompanyID;
GO


-- 1. ManagerTypeOfShiftDetails (Modified to work without SITE_ID in TypeOfShifts)
CREATE OR ALTER VIEW ManagerTypeOfShiftDetails
AS
SELECT 
    t.TypeShiftID AS TYPESHIFT_ID,
    s.SiteID AS SITE_ID,
    sc.SecurityCompID AS SECURITYCOMP_ID,
    c.CompanyID AS COMPANY_ID,
    t.TypeOfShift AS TYPEOFSHIFT,
    t.StartTime AS STARTTIME,
    t.EndTime AS ENDTIME,
    s.NameOfSite AS NAMEOFSITE,
    c.CompanyName AS COMPANYNAME
FROM TypeOfShifts t
LEFT JOIN RegularShifts rs ON rs.TypeShiftID = t.TypeShiftID
LEFT JOIN Posts p ON p.PostID = rs.PostID
LEFT JOIN Sites s ON s.SiteID = p.SiteID
LEFT JOIN SecurityCompanies sc ON s.SecurityCompID = sc.SecurityCompID
LEFT JOIN Companies c ON sc.CompanyID = c.CompanyID;
GO

-- 2. ManagerRegularShiftDetails
CREATE OR ALTER VIEW ManagerRegularShiftDetails
AS
SELECT
    rs.RegularShiftID AS REGULARSHIFT_ID,
    t.TypeShiftID AS TYPESHIFT_ID,
    p.PostID AS POST_ID,
    s.SiteID AS SITE_ID,
    sc.SecurityCompID AS SECURITYCOMP_ID,
    c.CompanyID AS COMPANY_ID,
    rs.NameOfShift AS NAMEOFSHIFT,
    t.TypeOfShift AS TYPEOFSHIFT,
    t.StartTime AS STARTTIME,
    t.EndTime AS ENDTIME,
    p.PostName AS POSTNAME,
    s.NameOfSite AS NAMEOFSITE,
    c.CompanyName AS COMPANYNAME,
    p.NumberPerPost AS NUMBERPERPOST
FROM Companies c
INNER JOIN SecurityCompanies sc ON c.CompanyID = sc.CompanyID
INNER JOIN Sites s ON sc.SecurityCompID = s.SecurityCompID
INNER JOIN Posts p ON s.SiteID = p.SiteID
INNER JOIN RegularShifts rs ON p.PostID = rs.PostID
INNER JOIN TypeOfShifts t ON rs.TypeShiftID = t.TypeShiftID;
GO

-- 3. ManagerSpecialShiftDetails
CREATE OR ALTER VIEW ManagerSpecialShiftDetails
AS
SELECT
    ss.SpecialShiftID AS SPECIALSHIFT_ID,
    p.PostID AS POST_ID,
    s.SiteID AS SITE_ID,
    sc.SecurityCompID AS SECURITYCOMP_ID,
    c.CompanyID AS COMPANY_ID,
    ss.SpecialShiftDate AS SPECIALSHIFTDATE,
    ss.NameOfShift AS NAMEOFSHIFT,
    ss.StartTime AS STARTTIME,
    ss.EndTime AS ENDTIME,
    p.PostName AS POSTNAME,
    p.NumberPerPost AS NUMBERPERPOST,
    s.NameOfSite AS NAMEOFSITE,
    c.CompanyName AS COMPANYNAME
FROM Companies c
INNER JOIN SecurityCompanies sc ON c.CompanyID = sc.CompanyID
INNER JOIN Sites s ON sc.SecurityCompID = s.SecurityCompID
INNER JOIN Posts p ON s.SiteID = p.SiteID
INNER JOIN SpecialShifts ss ON p.PostID = ss.PostID;
GO

-- 4. ManagerAttendanceDetails
CREATE OR ALTER VIEW ManagerAttendanceDetails
AS
SELECT
    rd.ShiftDate AS SHIFTDATE,
    p.FirstName AS FIRSTNAME,
    p.LastName AS LASTNAME,
    rs.NameOfShift AS NAMEOFSHIFT,
    po.PostName AS POSTNAME,
    t.StartTime AS STARTTIME,
    a.CheckInTime AS CHECKINTIME,
    t.EndTime AS ENDTIME,
    a.CheckOutTime AS CHECKOUTTIME,
    a.AttendanceStatus AS ATTENDANCESTATUS,
    s.SiteID AS SITE_ID,
    s.NameOfSite AS NAMEOFSITE,
    s.SecurityCompID AS SECURITYCOMP_ID,
    t.TypeOfShift AS TYPEOFSHIFT,
    rsa.AssignmentID AS ASSIGNMENT_ID,
    rd.RosterDayID AS ROSTERDAY_ID
FROM TypeOfShifts t
INNER JOIN RegularShifts rs ON rs.TypeShiftID = t.TypeShiftID
INNER JOIN Posts po ON po.PostID = rs.PostID
INNER JOIN Sites s ON s.SiteID = po.SiteID
INNER JOIN RegularShiftsAssignments rsa ON rsa.RegularShiftID = rs.RegularShiftID
INNER JOIN RosterDays rd ON rd.RosterDayID = rsa.RosterDayID
INNER JOIN Rosters r ON r.RosterID = rd.Roster_ID
INNER JOIN Guards g ON g.GuardID = rsa.GuardID
INNER JOIN Persons p ON p.PersonID = g.PersonID
INNER JOIN Attendances a ON a.AssignmentID = rsa.AssignmentID;
GO

-- 5. ManagerTypeOfLeaveDetails
CREATE OR ALTER VIEW ManagerTypeOfLeaveDetails
AS
SELECT 
    tl.TypeOfLeaveID AS TYPEOFLEAVE_ID,
    tl.TypeOfLeave AS TYPEOFLEAVE,
    tl.MaxDuration AS MAXDAYS,
    sc.SecurityCompID AS SECURITYCOMP_ID,
    c.CompanyID AS COMPANY_ID,
    c.CompanyName AS COMPANYNAME
FROM TypeOfLeaves tl
INNER JOIN SecurityCompanies sc ON sc.SecurityCompID = 1 -- Assuming default company mapping
INNER JOIN Companies c ON c.CompanyID = sc.CompanyID;
GO

select*from  ManagerSpecialShiftsRoster;
CREATE OR ALTER VIEW ManagerSpecialShiftsRoster
AS
SELECT
    c.CompanyName,
    p.FirstName,
    p.LastName,
    ss.NameOfShift,
    ss.StartTime,
    ss.EndTime,
    po.PostName,
    s.NameOfSite,
    s.SiteCapacity
FROM Guards g
INNER JOIN Persons p
    ON g.PersonID = p.PersonID
INNER JOIN SpecialShiftsAssignments ssa
    ON g.GuardID = ssa.GuardID
INNER JOIN SpecialShifts ss
    ON ssa.SpecialShiftID = ss.SpecialShiftID
INNER JOIN Posts po
    ON ss.PostID = po.PostID
INNER JOIN Sites s
    ON po.SiteID = s.SiteID
INNER JOIN SecurityCompanies sc
    ON s.SecurityCompID = sc.SecurityCompID
INNER JOIN Companies c
    ON sc.CompanyID = c.CompanyID;
GO
select * from PostsView;

/*CREATE OR ALTER VIEW PostsView
AS
SELECT
    p.PostName,
    s.NameOfSite,
    p.NumberPerPost,
    p.PStatus AS PostStatus,
    p.PostID,
    s.SecurityCompID
FROM Posts p
INNER JOIN Sites s
    ON p.SiteID = s.SiteID;
GO*/

CREATE OR ALTER VIEW PostsView
AS
SELECT
    p.PostName          AS POSTNAME,
    s.NameOfSite        AS NAMEOFSITE,
    p.NumberPerPost     AS NUMBERPERPOST,
    p.PStatus           AS POSTSTATUS,
    p.PostID            AS POSTID,
    s.SecurityCompID    AS SECURITYCOMP_ID,
    c.CompanyName       AS SECURITYCOMPANYNAME
FROM Posts p
INNER JOIN Sites s
    ON p.SiteID = s.SiteID
LEFT JOIN SecurityCompanies sc
    ON s.SecurityCompID = sc.SecurityCompID
LEFT JOIN Companies c
    ON sc.CompanyID = c.CompanyID;
GO


select * from RegularRosterWithGuard;
CREATE OR ALTER VIEW RegularRosterWithGuard
AS
SELECT
    rd.ShiftDate,
    ts.TypeOfShift,
    ts.StartTime,
    ts.EndTime,
    pst.PostName,
    pr.PersonID,
    pr.FirstName,
    pr.Username
FROM RegularShiftsAssignments rsa
INNER JOIN Guards g
    ON rsa.GuardID = g.GuardID
INNER JOIN Persons pr
    ON g.PersonID = pr.PersonID
INNER JOIN RosterDays rd
    ON rsa.RosterDayID = rd.RosterDayID
INNER JOIN RegularShifts rs
    ON rsa.RegularShiftID = rs.RegularShiftID
INNER JOIN TypeOfShifts ts
    ON rs.TypeShiftID = ts.TypeShiftID
INNER JOIN Posts pst
    ON rs.PostID = pst.PostID;
GO


CREATE OR ALTER VIEW RegularShiftAssignedGuards
AS
SELECT
    rsa.Assignment_ID,
    rd.ShiftDate,
    p.FirstName,
    p.LastName,
    ts.TypeOfShift,
    po.PostName,
    si.Site_ID
FROM RegularShiftsAssignments rsa
INNER JOIN Guards g ON rsa.Guard_ID = g.Guard_ID
INNER JOIN Persons p ON g.Person_ID = p.Person_ID
INNER JOIN RosterDays rd ON rsa.RosterDay_ID = rd.RosterDay_ID
INNER JOIN Rosters r ON rd.Roster_ID = r.Roster_ID
INNER JOIN RegularShifts rs ON rsa.RegularShift_ID = rs.RegularShift_ID
INNER JOIN TypeOfShifts ts ON rs.TypeShift_ID = ts.TypeShift_ID
INNER JOIN Posts po ON rs.Post_ID = po.Post_ID
INNER JOIN Sites si ON po.Site_ID = si.Site_ID;
GO


CREATE OR ALTER VIEW RostersDetails
AS
SELECT
    r.RosterID,
    r.StartDate,
    r.EndDate,
    r.RosterName,
    r.SiteID,
    r.SupervisorID,
    r.CreatedDate,
    r.RosterStatus,
    s.NameOfSite,
    p.FirstName,
    p.LastName,
    p.PersonID
FROM Rosters r
INNER JOIN Sites s
    ON r.SiteID = s.SiteID
INNER JOIN Supervisors sp
    ON r.SupervisorID = sp.SupervisorID
INNER JOIN Persons p
    ON sp.PersonID = p.PersonID;
GO

select*from RostersDetails;

/* CREATE OR ALTER VIEW SupervisorView
AS
SELECT
    p.Username,
    p.FirstName,
    p.LastName,
    p.CellNumber,
    p.Email,
    p.Gender,
    s.NameOfSite,
    p.PersonID,
    s.ClientCompID,
    s.SecurityCompID,
    s.SiteID,
    cc.CompanyID,
    sp.SupervisorID,
    c.CompanyName
FROM Supervisors sp
INNER JOIN Persons p
    ON sp.PersonID = p.PersonID
INNER JOIN Sites s
    ON sp.SiteID = s.SiteID
INNER JOIN ClientCompanies cc
    ON s.ClientCompID = cc.ClientCompID
INNER JOIN Companies c
    ON cc.CompanyID = c.CompanyID;
GO*/
select*from SupervisorView;
ALTER VIEW SupervisorView
AS
SELECT
    p.Username,
    p.FirstName,
    p.LastName,
    p.CellNumber,
    p.Email,
    p.Gender,
    p.ID_Number AS ID_Number,
    s.NameOfSite,
    p.PersonID,
    s.ClientCompID,
    s.SecurityCompID AS SECURITYCOMP_ID, -- <--- FIXED: Explicitly named
    s.SiteID,
    cc.CompanyID,
    sp.SupervisorID,
    c.CompanyName
FROM Supervisors sp
INNER JOIN Persons p ON sp.PersonID = p.PersonID
INNER JOIN Sites s ON sp.SiteID = s.SiteID
INNER JOIN ClientCompanies cc ON s.ClientCompID = cc.ClientCompID
INNER JOIN Companies c ON cc.CompanyID = c.CompanyID;
GO


select*from RegularShiftAssignedGuards;
CREATE OR ALTER VIEW RegularShiftAssignedGuards
AS
SELECT
    rsa.AssignmentID,
    rd.ShiftDate,
    p.FirstName,
    p.LastName,
    ts.TypeOfShift,
    po.PostName,
    s.SiteID
FROM RegularShiftsAssignments rsa
INNER JOIN Guards g
    ON rsa.GuardID = g.GuardID
INNER JOIN Persons p
    ON g.PersonID = p.PersonID
INNER JOIN RosterDays rd
    ON rsa.RosterDayID = rd.RosterDayID
INNER JOIN RegularShifts rs
    ON rsa.RegularShiftID = rs.RegularShiftID
INNER JOIN TypeOfShifts ts
    ON rs.TypeShiftID = ts.TypeShiftID
INNER JOIN Posts po
    ON rs.PostID = po.PostID
INNER JOIN Sites s
    ON po.SiteID = s.SiteID;
GO

CREATE OR ALTER VIEW RegularShiftsRosterr
AS
SELECT
    r.RosterID,
    r.StartDate,
    r.EndDate,
    rs.NameOfShift,
    ts.TypeOfShift,
    p.PostName,
    ts.StartTime,
    ts.EndTime,
    rs.RegularShiftID,
    ts.TypeShiftID,
    p.PostID,
    s.SiteID
FROM RosterDays rd
INNER JOIN Rosters r
    ON rd.Roster_ID = r.RosterID
INNER JOIN RegularShiftsAssignments rsa
    ON rd.RosterDayID = rsa.RosterDayID
INNER JOIN RegularShifts rs
    ON rsa.RegularShiftID = rs.RegularShiftID
INNER JOIN TypeOfShifts ts
    ON rs.TypeShiftID = ts.TypeShiftID
INNER JOIN Posts p
    ON rs.PostID = p.PostID
INNER JOIN Sites s
    ON p.SiteID = s.SiteID;
GO

CREATE OR ALTER VIEW SupervisorCaptureAttendance
AS
SELECT
    rd.ShiftDate,
    p.FirstName,
    p.LastName,
    rs.NameOfShift,
    po.PostName,
    ts.StartTime,
    a.CheckInTime,
    ts.EndTime,
    a.CheckOutTime,
    a.AttendanceStatus
FROM Attendances a
INNER JOIN RegularShiftsAssignments rsa
    ON a.AssignmentID = rsa.AssignmentID
INNER JOIN Guards g
    ON rsa.GuardID = g.GuardID
INNER JOIN Persons p
    ON g.PersonID = p.PersonID
INNER JOIN RosterDays rd
    ON rsa.RosterDayID = rd.RosterDayID
INNER JOIN RegularShifts rs
    ON rsa.RegularShiftID = rs.RegularShiftID
INNER JOIN TypeOfShifts ts
    ON rs.TypeShiftID = ts.TypeShiftID
INNER JOIN Posts po
    ON rs.PostID = po.PostID;
GO



CREATE OR ALTER VIEW SupervisorCaptureAttendanceE
AS
SELECT
    a.AttendanceID       AS ATTENDANCE_ID, 
    rd.ShiftDate,
    p.FirstName,
    p.LastName,
    rs.NameOfShift,
    po.PostName,
    ts.StartTime,
    a.CheckInTime,
    ts.EndTime,
    a.CheckOutTime,
    a.AttendanceStatus,
    s.SiteID
FROM Attendances a
INNER JOIN RegularShiftsAssignments rsa ON a.AssignmentID = rsa.AssignmentID
INNER JOIN Guards g    ON rsa.GuardID = g.GuardID
INNER JOIN Persons p   ON g.PersonID = p.PersonID
INNER JOIN RosterDays rd ON rsa.RosterDayID = rd.RosterDayID
INNER JOIN RegularShifts rs ON rsa.RegularShiftID = rs.RegularShiftID
INNER JOIN Posts po    ON rs.PostID = po.PostID
INNER JOIN Sites s     ON po.SiteID = s.SiteID
INNER JOIN TypeOfShifts ts ON rs.TypeShiftID = ts.TypeShiftID;
GO


CREATE OR ALTER VIEW SupervisorsProfile
AS
SELECT
    sp.SupervisorID,
    p.Username,
    p.FirstName,
    p.LastName,
    p.Email,
    p.Gender,
    p.CellNumber,
    p.ID_Number AS IDNumber,
    s.NameOfSite,
    c.CompanyName
FROM Supervisors sp
INNER JOIN Persons p
    ON sp.PersonID = p.PersonID
INNER JOIN Sites s
    ON sp.SiteID = s.SiteID
INNER JOIN SecurityCompanies sc
    ON s.SecurityCompID = sc.SecurityCompID
INNER JOIN Companies c
    ON sc.CompanyID = c.CompanyID;
GO

CREATE OR ALTER VIEW SecurityCompaniesView
AS
SELECT
    c.CompanyID AS COMPANY_ID,
    c.CompanyName AS COMPANYNAME,
    c.CompanyCell AS COMPANYCELL,
    c.CompanyEmail AS COMPANYEMAIL,

    sc.SuburbID AS SUBURB_ID,
    sc.SecurityCompID AS SECURITYCOMP_ID,

    sb.SuburbName AS SUBURBNAME,
    sb.TownID AS TOWN_ID,

    t.TownName AS TOWNNAME,
    t.CityID AS CITY_ID,

    ci.CityName AS CITYNAME,
    ci.MunicipalityID AS MUNICIPALITY_ID,

    m.MunicipalityName AS MUNICIPALITYNAME,

    m.ProvinceID AS PROVINCE_ID,
    p.ProvinceName AS PROVINCENAME

FROM SecurityCompanies sc
INNER JOIN Companies c
    ON sc.CompanyID = c.CompanyID
INNER JOIN Suburbs sb
    ON sc.SuburbID = sb.SuburbID
INNER JOIN Towns t
    ON sb.TownID = t.TownID
INNER JOIN Cities ci
    ON t.CityID = ci.CityID
INNER JOIN Municipalities m
    ON ci.MunicipalityID = m.MunicipalityID
INNER JOIN Provinces p
    ON m.ProvinceID = p.ProvinceID;
GO

CREATE OR ALTER VIEW SitesView
AS
SELECT
    s.SiteID AS SITE_ID,
    s.NameOfSite AS NAMEOFSITE,
    s.ClientCompID AS CLIENTCOMP_ID,
    s.SecurityCompID AS SECURITYCOMP_ID,
    s.SuburbID AS SUBURB_ID,

    cc.CompanyName AS COMPANYNAME,
    scComp.CompanyName AS SECURITY_COMPANY_NAME,

    ci.CityName AS CITYNAME,
    t.TownName AS TOWNNAME,

    s.SiteCapacity AS SITECAPACITY,

    t.TownID AS TOWN_ID,

    m.MunicipalityName AS MUNICIPALITYNAME,

    sb.SuburbName AS SUBURBNAME,

    cc.CompanyID AS COMPANY_ID

FROM Sites s

INNER JOIN Suburbs sb
    ON s.SuburbID = sb.SuburbID

INNER JOIN Towns t
    ON sb.TownID = t.TownID

INNER JOIN Cities ci
    ON t.CityID = ci.CityID

INNER JOIN Municipalities m
    ON ci.MunicipalityID = m.MunicipalityID

INNER JOIN ClientCompanies client
    ON s.ClientCompID = client.ClientCompID

INNER JOIN Companies cc
    ON client.CompanyID = cc.CompanyID

INNER JOIN SecurityCompanies sc
    ON s.SecurityCompID = sc.SecurityCompID

INNER JOIN Companies scComp
    ON sc.CompanyID = scComp.CompanyID;
GO
USE SecureRoster;
GO

-- 1. Fix the Supervisor View so it has SITE_ID
ALTER VIEW SupervisorView
AS
SELECT
    p.Username,
    p.FirstName,
    p.LastName,
    p.CellNumber,
    p.Email,
    p.Gender,
    p.ID_Number AS ID_Number,   
    s.NameOfSite,
    p.PersonID,
    s.ClientCompID,
    s.SecurityCompID AS SECURITYCOMP_ID, 
    s.SiteID AS SITE_ID,                 -- Explicitly named SITE_ID
    cc.CompanyID,
    sp.SupervisorID,
    c.CompanyName
FROM Supervisors sp
INNER JOIN Persons p ON sp.PersonID = p.PersonID
INNER JOIN Sites s ON sp.SiteID = s.SiteID
INNER JOIN ClientCompanies cc ON s.ClientCompID = cc.ClientCompID
INNER JOIN Companies c ON cc.CompanyID = c.CompanyID;
GO

-- 2. Fix the Manager View so it has SecurityCompID
ALTER VIEW ManagersDetailsView
AS
SELECT
    p.PersonID,
    p.FirstName,
    p.LastName,
    p.Email,
    p.Gender,
    p.Username,
    p.CellNumber,
    p.ID_Number,
    p.Suburb_ID,
    s.SuburbName,
    s.TownID,
    t.TownName,
    t.CityID,
    c.CityName,
    m.ManagerID,
    sc.SecurityCompID,                  -- Explicitly named SecurityCompID
    co.CompanyID,
    co.CompanyName,
    co.CompanyCell,
    co.CompanyEmail
FROM Managers m
INNER JOIN Persons p ON m.PersonID = p.PersonID
INNER JOIN Suburbs s ON p.Suburb_ID = s.SuburbID
INNER JOIN Towns t ON s.TownID = t.TownID
INNER JOIN Cities c ON t.CityID = c.CityID
INNER JOIN SecurityCompanies sc ON m.CompanyID = sc.SecurityCompID
INNER JOIN Companies co ON sc.CompanyID = co.CompanyID;
GO
CREATE OR ALTER VIEW ManagerRegularShiftRoster
AS
SELECT
    g.GuardID AS GUARD_ID,
    pe.PersonID AS PERSON_ID,
    rsa.AssignmentID AS ASSIGNMENT_ID,
    rs.RegularShiftID AS REGULARSHIFT_ID,
    ts.TypeShiftID AS TYPESHIFT_ID,
    rd.RosterDayID AS ROSTERDAY_ID,
    r.RosterID AS ROSTER_ID,
    po.PostID AS POST_ID,
    si.SiteID AS SITE_ID,
    sc.SecurityCompID AS SECURITYCOMP_ID,
    co.CompanyID AS COMPANY_ID,

    pe.Username AS USERNAME,
    pe.FirstName AS FIRSTNAME,
    pe.LastName AS LASTNAME,

    ts.TypeOfShift AS TYPEOFSHIFT,
    ts.StartTime AS STARTTIME,
    ts.EndTime AS ENDTIME,

    po.PostName AS POSTNAME,
    rd.ShiftDate AS SHIFTDATE,

    DATENAME(WEEKDAY, rd.ShiftDate) AS DAYNAME,

    r.RosterName AS ROSTERNAME,
    si.NameOfSite AS NAMEOFSITE,
    co.CompanyName AS COMPANYNAME

FROM RegularShiftsAssignments rsa

INNER JOIN Guards g
    ON rsa.GuardID = g.GuardID

INNER JOIN Persons pe
    ON g.PersonID = pe.PersonID

INNER JOIN RegularShifts rs
    ON rsa.RegularShiftID = rs.RegularShiftID

INNER JOIN TypeOfShifts ts
    ON rs.TypeShiftID = ts.TypeShiftID

INNER JOIN RosterDays rd
    ON rsa.RosterDayID = rd.RosterDayID

INNER JOIN Rosters r
    ON rd.Roster_ID = r.RosterID

INNER JOIN Posts po
    ON rs.PostID = po.PostID

INNER JOIN Sites si
    ON po.SiteID = si.SiteID

INNER JOIN SecurityCompanies sc
    ON si.SecurityCompID = sc.SecurityCompID

INNER JOIN Companies co
    ON sc.CompanyID = co.CompanyID;
GO
--ORDER BY SHIFTDATE, STARTTIME;

CREATE OR ALTER VIEW SupervisorTypeofShiftDetails
AS
SELECT DISTINCT
    ts.TypeShiftID      AS TYPESHIFT_ID,
    s.SiteID            AS SITE_ID,
    ts.TypeOfShift      AS TYPEOFSHIFT,
    ts.StartTime        AS STARTTIME,
    ts.EndTime          AS ENDTIME,
    s.NameOfSite        AS NAMEOFSITE
FROM TypeOfShifts ts
LEFT JOIN RegularShifts rs ON rs.TypeShiftID = ts.TypeShiftID
LEFT JOIN Posts p          ON rs.PostID = p.PostID
LEFT JOIN Sites s          ON p.SiteID = s.SiteID;
GO

CREATE OR ALTER VIEW SupervisorRegularShiftDetails
AS
SELECT
    rs.RegularShiftID   AS REGULARSHIFT_ID,
    ts.TypeShiftID      AS TYPESHIFTID,
    p.PostID            AS POST_ID,
    s.SiteID            AS SITE_ID,
    sc.SecurityCompID   AS SECURITYCOMP_ID,
    c.CompanyID         AS COMPANY_ID,
    rs.NameOfShift      AS NAMEOFSHIFT,
    ts.TypeOfShift      AS TYPEOFSHIFT,
    ts.StartTime        AS STARTTIME,
    ts.EndTime          AS ENDTIME,
    p.PostName          AS POSTNAME,
    p.NumberPerPost     AS NUMBERPERPOST,
    s.NameOfSite        AS NAMEOFSITE,
    c.CompanyName       AS COMPANYNAME
FROM RegularShifts rs
INNER JOIN TypeOfShifts ts
    ON rs.TypeShiftID = ts.TypeShiftID
INNER JOIN Posts p
    ON rs.PostID = p.PostID
INNER JOIN Sites s
    ON p.SiteID = s.SiteID
INNER JOIN SecurityCompanies sc
    ON s.SecurityCompID = sc.SecurityCompID
INNER JOIN Companies c
    ON sc.CompanyID = c.CompanyID;
GO


CREATE OR ALTER VIEW SupervisorSpecialShiftDetails
AS
SELECT
    ss.SpecialShiftID   AS SPECIALSHIFT_ID,
    p.PostID            AS POST_ID,
    s.SiteID            AS SITE_ID,
    sc.SecurityCompID   AS SECURITYCOMP_ID,
    c.CompanyID         AS COMPANY_ID,
    ss.SpecialShiftDate AS SPECIALSHIFTDATE,
    ss.NameOfShift      AS NAMEOFSHIFT,
    ss.StartTime        AS STARTTIME,
    ss.EndTime          AS ENDTIME,
    p.PostName          AS POSTNAME,
    p.NumberPerPost     AS NUMBERPERPOST,
    s.NameOfSite        AS NAMEOFSITE,
    c.CompanyName       AS COMPANYNAME
FROM SpecialShifts ss
INNER JOIN Posts p
    ON ss.PostID = p.PostID
INNER JOIN Sites s
    ON p.SiteID = s.SiteID
INNER JOIN SecurityCompanies sc
    ON s.SecurityCompID = sc.SecurityCompID
INNER JOIN Companies c
    ON sc.CompanyID = c.CompanyID;
GO



CREATE OR ALTER VIEW RostersDetails
AS
SELECT
    r.RosterID          AS ROSTER_ID,
    r.StartDate         AS STARTDATE,
    r.EndDate           AS ENDDATE,
    r.RosterName        AS ROSTERNAME,
    r.SiteID            AS SITE_ID,
    r.SupervisorID      AS SUPERVISOR_ID,
    r.CreatedDate       AS CREATEDDATE,
    r.RosterStatus      AS ROSTERSTATUS,
    s.NameOfSite        AS NAMEOFSITE,
    p.FirstName         AS FIRSTNAME,
    p.LastName          AS LASTNAME,
    p.PersonID          AS PERSON_ID
FROM Rosters r
INNER JOIN Sites s
    ON r.SiteID = s.SiteID
INNER JOIN Supervisors sp
    ON r.SupervisorID = sp.SupervisorID
INNER JOIN Persons p
    ON sp.PersonID = p.PersonID;
GO


CREATE OR ALTER VIEW GuardRegularShiftView
AS
SELECT
    rd.ShiftDate         AS SHIFTDATE,
    p.Username           AS USERNAME,
    p.FirstName          AS FIRSTNAME,
    p.LastName           AS LASTNAME,
    rs.NameOfShift       AS NAMEOFSHIFT,
    s.NameOfSite         AS NAMEOFSITE,
    po.PostName          AS POSTNAME,
    r.RosterName         AS ROSTERNAME,
    ts.StartTime         AS STARTTIME,
    ts.EndTime           AS ENDTIME
FROM RegularShiftsAssignments rsa
INNER JOIN Guards g
    ON rsa.GuardID = g.GuardID
INNER JOIN Persons p
    ON g.PersonID = p.PersonID
INNER JOIN RegularShifts rs
    ON rsa.RegularShiftID = rs.RegularShiftID
INNER JOIN RosterDays rd
    ON rsa.RosterDayID = rd.RosterDayID
INNER JOIN Rosters r
    ON rd.Roster_ID = r.RosterID
INNER JOIN Posts po
    ON rs.PostID = po.PostID
INNER JOIN Sites s
    ON po.SiteID = s.SiteID
INNER JOIN TypeOfShifts ts
    ON rs.TypeShiftID = ts.TypeShiftID;
GO

CREATE OR ALTER VIEW SupervisorPostDetails
AS
SELECT
    s.SiteID        AS SITE_ID,
    p.PostID        AS POST_ID,
    p.PostName      AS POSTNAME,
    p.NumberPerPost AS NUMBERPERPOST,
    s.NameOfSite    AS NAMEOFSITE
FROM Sites s
INNER JOIN Posts p
    ON p.SiteID = s.SiteID;
GO

--Accounts
CREATE TABLE Accounts (
    AccountID     INT PRIMARY KEY,
    PersonID      INT NOT NULL,
    Username      VARCHAR(50) NOT NULL UNIQUE,
    PasswordSalt  VARCHAR(200) NOT NULL,
    PasswordHash  VARCHAR(200) NOT NULL,
    Role_         VARCHAR(20) NOT NULL,
    CreatedDate   DATE DEFAULT GETDATE(),

    CONSTRAINT FK_Accounts_Persons
        FOREIGN KEY (PersonID)
        REFERENCES Persons(PersonID)
        ON DELETE CASCADE -- Deleting a Person removes their Accounts row.
);
GO

SELECT * from Accounts;

-- This will show you the exact name of the constraint on Rosters
SELECT name 
FROM sys.foreign_keys 
WHERE parent_object_id = OBJECT_ID('Rosters') AND referenced_object_id = OBJECT_ID('Supervisors');


SELECT 
    DATENAME(WEEKDAY, CAST(ShiftDate AS DATE)) + ', ' + CAST(ShiftDate AS VARCHAR) AS SHIFTDATE,
    FirstName + ' ' + LastName AS GUARD,
    NameOfShift,
    PostName,
    StartTime,
    CheckInTime,
    AttendanceStatus,
    EndTime,
    CheckOutTime,
    SiteID
FROM SupervisorCaptureAttendanceE
WHERE SiteID IN (
    SELECT SiteID FROM Supervisors WHERE PersonID = (SELECT PersonID FROM Persons WHERE UPPER(Username) = 'johnbrown')
)
ORDER BY NameOfShift ASC;

USE SecureRoster;
GO

UPDATE Leaves 
SET StartDate = '01/11/2026', EndDate = '14/11/2026' 
WHERE LeaveID = 245;
USE SecureRoster;
GO

-- 1. Add temporary date columns
ALTER TABLE Leaves ADD TempStartDate DATE;
ALTER TABLE Leaves ADD TempEndDate DATE;
GO

-- 2. Convert the text to real dates. TRY_CONVERT stops it from crashing on bad text like 'Nov 1 202'
UPDATE Leaves 
SET TempStartDate = TRY_CONVERT(DATE, StartDate),
    TempEndDate = TRY_CONVERT(DATE, EndDate);
GO

-- 3. Drop the old text columns
ALTER TABLE Leaves DROP COLUMN StartDate;
ALTER TABLE Leaves DROP COLUMN EndDate;
GO

-- 4. Rename the new date columns
EXEC sp_rename 'Leaves.TempStartDate', 'StartDate', 'COLUMN';
EXEC sp_rename 'Leaves.TempEndDate', 'EndDate', 'COLUMN';
GO

-- 5. Fix the specific corrupted record manually so it shows correctly
UPDATE Leaves 
SET StartDate = '2026-11-06', EndDate = '2026-11-14' 
WHERE LeaveID = 245;
GO

-- 6. Update the View to match
DROP VIEW IF EXISTS ManagerLeaveApplicationDetails;
GO
CREATE VIEW ManagerLeaveApplicationDetails
AS
SELECT
    l.LeaveID AS LEAVE_ID,
    p.Username AS USERNAME,
    p.FirstName AS FIRSTNAME,
    p.LastName AS LASTNAME,
    tol.TypeOfLeave AS TYPEOFLEAVE,
    l.StartDate AS STARTDATE,
    l.EndDate AS ENDDATE,
    l.LeaveReason AS LEAVEREASON,
    tol.MaxDuration AS MAXDAYS,
    p.CellNumber AS CELLNUMBER,
    l.LeaveStatus AS LEAVESTATUS
FROM Leaves l
INNER JOIN Guards g ON l.GuardID = g.GuardID
INNER JOIN Persons p ON g.PersonID = p.PersonID
INNER JOIN TypeOfLeaves tol ON l.LeaveTypeID = tol.TypeOfLeaveID;
GO

select*from TypeOfShifts   ;